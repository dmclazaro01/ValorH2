--
-- PostgreSQL database dump
--

-- Dumped from database version 12.22
-- Dumped by pg_dump version 15.13 (Debian 15.13-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_organisation DROP CONSTRAINT IF EXISTS user_organisation_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_organisation DROP CONSTRAINT IF EXISTS user_organisation_org_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_group DROP CONSTRAINT IF EXISTS user_group_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_group DROP CONSTRAINT IF EXISTS user_group_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_client DROP CONSTRAINT IF EXISTS user_client_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_client DROP CONSTRAINT IF EXISTS user_client_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_case_effective_access DROP CONSTRAINT IF EXISTS user_case_effective_access_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_case_effective_access DROP CONSTRAINT IF EXISTS user_case_effective_access_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_case_access DROP CONSTRAINT IF EXISTS user_case_access_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_case_access DROP CONSTRAINT IF EXISTS user_case_access_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_activity DROP CONSTRAINT IF EXISTS user_activity_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_activity DROP CONSTRAINT IF EXISTS user_activity_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_comments DROP CONSTRAINT IF EXISTS task_comments_comment_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_comments DROP CONSTRAINT IF EXISTS task_comments_comment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_assignee DROP CONSTRAINT IF EXISTS task_assignee_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_assignee DROP CONSTRAINT IF EXISTS task_assignee_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.similar_alerts_cache DROP CONSTRAINT IF EXISTS similar_alerts_cache_ioc_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.similar_alerts_cache DROP CONSTRAINT IF EXISTS similar_alerts_cache_customer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.similar_alerts_cache DROP CONSTRAINT IF EXISTS similar_alerts_cache_asset_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.similar_alerts_cache DROP CONSTRAINT IF EXISTS similar_alerts_cache_alert_id_fkey;
ALTER TABLE IF EXISTS ONLY public.saved_filters DROP CONSTRAINT IF EXISTS saved_filters_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.organisation_case_access DROP CONSTRAINT IF EXISTS organisation_case_access_org_id_fkey;
ALTER TABLE IF EXISTS ONLY public.organisation_case_access DROP CONSTRAINT IF EXISTS organisation_case_access_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.object_state DROP CONSTRAINT IF EXISTS object_state_object_updated_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.object_state DROP CONSTRAINT IF EXISTS object_state_object_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_note_user_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_note_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes_group_link DROP CONSTRAINT IF EXISTS notes_group_link_note_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes_group_link DROP CONSTRAINT IF EXISTS notes_group_link_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes_group_link DROP CONSTRAINT IF EXISTS notes_group_link_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes_group DROP CONSTRAINT IF EXISTS notes_group_group_user_fkey;
ALTER TABLE IF EXISTS ONLY public.notes_group DROP CONSTRAINT IF EXISTS notes_group_group_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_directory_id_fkey;
ALTER TABLE IF EXISTS ONLY public.note_revisions DROP CONSTRAINT IF EXISTS note_revisions_note_user_fkey;
ALTER TABLE IF EXISTS ONLY public.note_revisions DROP CONSTRAINT IF EXISTS note_revisions_note_id_fkey;
ALTER TABLE IF EXISTS ONLY public.note_directory DROP CONSTRAINT IF EXISTS note_directory_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.note_directory DROP CONSTRAINT IF EXISTS note_directory_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.note_comments DROP CONSTRAINT IF EXISTS note_comments_comment_note_id_fkey;
ALTER TABLE IF EXISTS ONLY public.note_comments DROP CONSTRAINT IF EXISTS note_comments_comment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.iris_reports DROP CONSTRAINT IF EXISTS iris_reports_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.iris_reports DROP CONSTRAINT IF EXISTS iris_reports_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.iris_module_hooks DROP CONSTRAINT IF EXISTS iris_module_hooks_module_id_fkey;
ALTER TABLE IF EXISTS ONLY public.iris_module_hooks DROP CONSTRAINT IF EXISTS iris_module_hooks_hook_id_fkey;
ALTER TABLE IF EXISTS ONLY public.iris_module DROP CONSTRAINT IF EXISTS iris_module_added_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ioc DROP CONSTRAINT IF EXISTS ioc_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ioc_link DROP CONSTRAINT IF EXISTS ioc_link_ioc_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ioc_link DROP CONSTRAINT IF EXISTS ioc_link_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ioc DROP CONSTRAINT IF EXISTS ioc_ioc_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ioc DROP CONSTRAINT IF EXISTS ioc_ioc_tlp_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ioc_comments DROP CONSTRAINT IF EXISTS ioc_comments_comment_ioc_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ioc_comments DROP CONSTRAINT IF EXISTS ioc_comments_comment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ioc_asset_link DROP CONSTRAINT IF EXISTS ioc_asset_link_ioc_id_fkey;
ALTER TABLE IF EXISTS ONLY public.ioc_asset_link DROP CONSTRAINT IF EXISTS ioc_asset_link_asset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_case_access DROP CONSTRAINT IF EXISTS group_case_access_group_id_fkey;
ALTER TABLE IF EXISTS ONLY public.group_case_access DROP CONSTRAINT IF EXISTS group_case_access_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.global_tasks DROP CONSTRAINT IF EXISTS global_tasks_task_userid_update_fkey;
ALTER TABLE IF EXISTS ONLY public.global_tasks DROP CONSTRAINT IF EXISTS global_tasks_task_userid_open_fkey;
ALTER TABLE IF EXISTS ONLY public.global_tasks DROP CONSTRAINT IF EXISTS global_tasks_task_userid_close_fkey;
ALTER TABLE IF EXISTS ONLY public.global_tasks DROP CONSTRAINT IF EXISTS global_tasks_task_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.global_tasks DROP CONSTRAINT IF EXISTS global_tasks_task_assignee_id_fkey;
ALTER TABLE IF EXISTS ONLY public.evidence_type DROP CONSTRAINT IF EXISTS evidence_type_created_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.evidence_comments DROP CONSTRAINT IF EXISTS evidence_comments_comment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.evidence_comments DROP CONSTRAINT IF EXISTS evidence_comments_comment_evidence_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_comments DROP CONSTRAINT IF EXISTS event_comments_comment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.event_comments DROP CONSTRAINT IF EXISTS event_comments_comment_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.data_store_path DROP CONSTRAINT IF EXISTS data_store_path_path_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.data_store_file DROP CONSTRAINT IF EXISTS data_store_file_file_parent_id_fkey;
ALTER TABLE IF EXISTS ONLY public.data_store_file DROP CONSTRAINT IF EXISTS data_store_file_file_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.data_store_file DROP CONSTRAINT IF EXISTS data_store_file_added_by_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contact DROP CONSTRAINT IF EXISTS contact_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_comment_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_comment_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_comment_alert_id_fkey;
ALTER TABLE IF EXISTS ONLY public.client DROP CONSTRAINT IF EXISTS client_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_state_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_severity_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_reviewer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_review_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases_events DROP CONSTRAINT IF EXISTS cases_events_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases_events DROP CONSTRAINT IF EXISTS cases_events_parent_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases_events DROP CONSTRAINT IF EXISTS cases_events_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_classification_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases_assets_ext DROP CONSTRAINT IF EXISTS cases_assets_ext_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cases_assets_ext DROP CONSTRAINT IF EXISTS cases_assets_ext_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_template_report DROP CONSTRAINT IF EXISTS case_template_report_report_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_template_report DROP CONSTRAINT IF EXISTS case_template_report_language_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_template_report DROP CONSTRAINT IF EXISTS case_template_report_created_by_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_template DROP CONSTRAINT IF EXISTS case_template_created_by_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_tasks DROP CONSTRAINT IF EXISTS case_tasks_task_userid_update_fkey;
ALTER TABLE IF EXISTS ONLY public.case_tasks DROP CONSTRAINT IF EXISTS case_tasks_task_userid_open_fkey;
ALTER TABLE IF EXISTS ONLY public.case_tasks DROP CONSTRAINT IF EXISTS case_tasks_task_userid_close_fkey;
ALTER TABLE IF EXISTS ONLY public.case_tasks DROP CONSTRAINT IF EXISTS case_tasks_task_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_tasks DROP CONSTRAINT IF EXISTS case_tasks_task_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_tags DROP CONSTRAINT IF EXISTS case_tags_tag_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_tags DROP CONSTRAINT IF EXISTS case_tags_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_received_file DROP CONSTRAINT IF EXISTS case_received_file_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_received_file DROP CONSTRAINT IF EXISTS case_received_file_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_received_file DROP CONSTRAINT IF EXISTS case_received_file_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_protagonist DROP CONSTRAINT IF EXISTS case_protagonist_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_protagonist DROP CONSTRAINT IF EXISTS case_protagonist_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_kanban DROP CONSTRAINT IF EXISTS case_kanban_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_graph_links DROP CONSTRAINT IF EXISTS case_graph_links_source_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_graph_links DROP CONSTRAINT IF EXISTS case_graph_links_dest_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_graph_links DROP CONSTRAINT IF EXISTS case_graph_links_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_graph_assets DROP CONSTRAINT IF EXISTS case_graph_assets_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_graph_assets DROP CONSTRAINT IF EXISTS case_graph_assets_asset_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_events_ioc DROP CONSTRAINT IF EXISTS case_events_ioc_ioc_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_events_ioc DROP CONSTRAINT IF EXISTS case_events_ioc_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_events_ioc DROP CONSTRAINT IF EXISTS case_events_ioc_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_events_category DROP CONSTRAINT IF EXISTS case_events_category_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_events_category DROP CONSTRAINT IF EXISTS case_events_category_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_events_assets DROP CONSTRAINT IF EXISTS case_events_assets_event_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_events_assets DROP CONSTRAINT IF EXISTS case_events_assets_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_events_assets DROP CONSTRAINT IF EXISTS case_events_assets_asset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_classification DROP CONSTRAINT IF EXISTS case_classification_created_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_assets DROP CONSTRAINT IF EXISTS case_assets_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_assets DROP CONSTRAINT IF EXISTS case_assets_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_assets DROP CONSTRAINT IF EXISTS case_assets_asset_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.case_assets DROP CONSTRAINT IF EXISTS case_assets_analysis_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.asset_comments DROP CONSTRAINT IF EXISTS asset_comments_comment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.asset_comments DROP CONSTRAINT IF EXISTS asset_comments_comment_asset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_alert_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_alert_severity_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_alert_resolution_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_alert_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_alert_customer_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_alert_classification_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_similarity DROP CONSTRAINT IF EXISTS alert_similarity_similar_alert_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_similarity DROP CONSTRAINT IF EXISTS alert_similarity_matching_ioc_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_similarity DROP CONSTRAINT IF EXISTS alert_similarity_matching_asset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_similarity DROP CONSTRAINT IF EXISTS alert_similarity_alert_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_iocs_association DROP CONSTRAINT IF EXISTS alert_iocs_association_ioc_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_iocs_association DROP CONSTRAINT IF EXISTS alert_iocs_association_alert_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_case_association DROP CONSTRAINT IF EXISTS alert_case_association_case_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_case_association DROP CONSTRAINT IF EXISTS alert_case_association_alert_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_assets_association DROP CONSTRAINT IF EXISTS alert_assets_association_asset_id_fkey;
ALTER TABLE IF EXISTS ONLY public.alert_assets_association DROP CONSTRAINT IF EXISTS alert_assets_association_alert_id_fkey;
DROP INDEX IF EXISTS public.ix_case_tags_tag_id;
DROP INDEX IF EXISTS public.ix_alert_case_association_case_id;
DROP INDEX IF EXISTS public.idx_ioc_value_hash;
DROP INDEX IF EXISTS public.idx_ioc_tags;
DROP INDEX IF EXISTS public.idx_case_assets_name;
DROP INDEX IF EXISTS public.idx_case_assets_date_update;
DROP INDEX IF EXISTS public.idx_case_assets_date_added;
DROP INDEX IF EXISTS public.idx_case_assets_case_id;
DROP INDEX IF EXISTS public.idx_alerts_title;
DROP INDEX IF EXISTS public.idx_alerts_source_event_time;
DROP INDEX IF EXISTS public.idx_alerts_customer_id;
DROP INDEX IF EXISTS public.idx_alerts_creation_time;
DROP INDEX IF EXISTS public.idx_alert_source_ref;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_uuid_key;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_user_key;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_pkey;
ALTER TABLE IF EXISTS ONLY public.user_organisation DROP CONSTRAINT IF EXISTS user_organisation_pkey;
ALTER TABLE IF EXISTS ONLY public.user_group DROP CONSTRAINT IF EXISTS user_group_pkey;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_external_id_key;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_email_key;
ALTER TABLE IF EXISTS ONLY public.user_client DROP CONSTRAINT IF EXISTS user_client_pkey;
ALTER TABLE IF EXISTS ONLY public.user_case_effective_access DROP CONSTRAINT IF EXISTS user_case_effective_access_pkey;
ALTER TABLE IF EXISTS ONLY public.user_case_access DROP CONSTRAINT IF EXISTS user_case_access_pkey;
ALTER TABLE IF EXISTS ONLY public."user" DROP CONSTRAINT IF EXISTS user_api_key_key;
ALTER TABLE IF EXISTS ONLY public.user_activity DROP CONSTRAINT IF EXISTS user_activity_pkey;
ALTER TABLE IF EXISTS ONLY public.tlp DROP CONSTRAINT IF EXISTS tlp_pkey;
ALTER TABLE IF EXISTS ONLY public.task_status DROP CONSTRAINT IF EXISTS task_status_pkey;
ALTER TABLE IF EXISTS ONLY public.task_comments DROP CONSTRAINT IF EXISTS task_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.task_assignee DROP CONSTRAINT IF EXISTS task_assignee_pkey;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_tag_title_key1;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_tag_title_key;
ALTER TABLE IF EXISTS ONLY public.tags DROP CONSTRAINT IF EXISTS tags_pkey;
ALTER TABLE IF EXISTS ONLY public.similar_alerts_cache DROP CONSTRAINT IF EXISTS similar_alerts_cache_pkey;
ALTER TABLE IF EXISTS ONLY public.severities DROP CONSTRAINT IF EXISTS severities_severity_name_key;
ALTER TABLE IF EXISTS ONLY public.severities DROP CONSTRAINT IF EXISTS severities_pkey;
ALTER TABLE IF EXISTS ONLY public.server_settings DROP CONSTRAINT IF EXISTS server_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.saved_filters DROP CONSTRAINT IF EXISTS saved_filters_pkey;
ALTER TABLE IF EXISTS ONLY public.review_status DROP CONSTRAINT IF EXISTS review_status_pkey;
ALTER TABLE IF EXISTS ONLY public.report_type DROP CONSTRAINT IF EXISTS report_type_pkey;
ALTER TABLE IF EXISTS ONLY public.report_type DROP CONSTRAINT IF EXISTS report_type_name_key;
ALTER TABLE IF EXISTS ONLY public.os_type DROP CONSTRAINT IF EXISTS os_type_pkey;
ALTER TABLE IF EXISTS ONLY public.organisations DROP CONSTRAINT IF EXISTS organisations_pkey;
ALTER TABLE IF EXISTS ONLY public.organisations DROP CONSTRAINT IF EXISTS organisations_org_uuid_key;
ALTER TABLE IF EXISTS ONLY public.organisations DROP CONSTRAINT IF EXISTS organisations_org_name_key;
ALTER TABLE IF EXISTS ONLY public.organisation_case_access DROP CONSTRAINT IF EXISTS organisation_case_access_pkey;
ALTER TABLE IF EXISTS ONLY public.object_state DROP CONSTRAINT IF EXISTS object_state_pkey;
ALTER TABLE IF EXISTS ONLY public.notes DROP CONSTRAINT IF EXISTS notes_pkey;
ALTER TABLE IF EXISTS ONLY public.notes_group DROP CONSTRAINT IF EXISTS notes_group_pkey;
ALTER TABLE IF EXISTS ONLY public.notes_group_link DROP CONSTRAINT IF EXISTS notes_group_link_pkey;
ALTER TABLE IF EXISTS ONLY public.note_revisions DROP CONSTRAINT IF EXISTS note_revisions_pkey;
ALTER TABLE IF EXISTS ONLY public.note_directory DROP CONSTRAINT IF EXISTS note_directory_pkey;
ALTER TABLE IF EXISTS ONLY public.note_comments DROP CONSTRAINT IF EXISTS note_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.languages DROP CONSTRAINT IF EXISTS languages_pkey;
ALTER TABLE IF EXISTS ONLY public.languages DROP CONSTRAINT IF EXISTS languages_name_key;
ALTER TABLE IF EXISTS ONLY public.languages DROP CONSTRAINT IF EXISTS languages_code_key;
ALTER TABLE IF EXISTS ONLY public.iris_reports DROP CONSTRAINT IF EXISTS iris_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.iris_module DROP CONSTRAINT IF EXISTS iris_module_pkey;
ALTER TABLE IF EXISTS ONLY public.iris_module_hooks DROP CONSTRAINT IF EXISTS iris_module_hooks_pkey;
ALTER TABLE IF EXISTS ONLY public.iris_hooks DROP CONSTRAINT IF EXISTS iris_hooks_pkey;
ALTER TABLE IF EXISTS ONLY public.ioc_type DROP CONSTRAINT IF EXISTS ioc_type_pkey;
ALTER TABLE IF EXISTS ONLY public.ioc DROP CONSTRAINT IF EXISTS ioc_pkey;
ALTER TABLE IF EXISTS ONLY public.ioc_link DROP CONSTRAINT IF EXISTS ioc_link_pkey;
ALTER TABLE IF EXISTS ONLY public.ioc_comments DROP CONSTRAINT IF EXISTS ioc_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.ioc_asset_link DROP CONSTRAINT IF EXISTS ioc_asset_link_pkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_pkey;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_group_uuid_key;
ALTER TABLE IF EXISTS ONLY public.groups DROP CONSTRAINT IF EXISTS groups_group_name_key;
ALTER TABLE IF EXISTS ONLY public.group_case_access DROP CONSTRAINT IF EXISTS group_case_access_pkey;
ALTER TABLE IF EXISTS ONLY public.global_tasks DROP CONSTRAINT IF EXISTS global_tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.evidence_type DROP CONSTRAINT IF EXISTS evidence_type_pkey;
ALTER TABLE IF EXISTS ONLY public.evidence_comments DROP CONSTRAINT IF EXISTS evidence_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.event_comments DROP CONSTRAINT IF EXISTS event_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.event_category DROP CONSTRAINT IF EXISTS event_category_pkey;
ALTER TABLE IF EXISTS ONLY public.data_store_path DROP CONSTRAINT IF EXISTS data_store_path_pkey;
ALTER TABLE IF EXISTS ONLY public.data_store_file DROP CONSTRAINT IF EXISTS data_store_file_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_attribute DROP CONSTRAINT IF EXISTS custom_attribute_pkey;
ALTER TABLE IF EXISTS ONLY public.contact DROP CONSTRAINT IF EXISTS contact_pkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_pkey;
ALTER TABLE IF EXISTS ONLY public.client DROP CONSTRAINT IF EXISTS client_pkey;
ALTER TABLE IF EXISTS ONLY public.client DROP CONSTRAINT IF EXISTS client_name_key;
ALTER TABLE IF EXISTS ONLY public.cases DROP CONSTRAINT IF EXISTS cases_pkey;
ALTER TABLE IF EXISTS ONLY public.cases_events DROP CONSTRAINT IF EXISTS cases_events_pkey;
ALTER TABLE IF EXISTS ONLY public.cases_assets_ext DROP CONSTRAINT IF EXISTS cases_assets_ext_pkey;
ALTER TABLE IF EXISTS ONLY public.case_template_report DROP CONSTRAINT IF EXISTS case_template_report_pkey;
ALTER TABLE IF EXISTS ONLY public.case_template_report DROP CONSTRAINT IF EXISTS case_template_report_internal_reference_key;
ALTER TABLE IF EXISTS ONLY public.case_template DROP CONSTRAINT IF EXISTS case_template_pkey;
ALTER TABLE IF EXISTS ONLY public.case_tasks DROP CONSTRAINT IF EXISTS case_tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.case_tags DROP CONSTRAINT IF EXISTS case_tags_case_id_tag_id_key;
ALTER TABLE IF EXISTS ONLY public.case_state DROP CONSTRAINT IF EXISTS case_state_pkey;
ALTER TABLE IF EXISTS ONLY public.case_received_file DROP CONSTRAINT IF EXISTS case_received_file_pkey;
ALTER TABLE IF EXISTS ONLY public.case_protagonist DROP CONSTRAINT IF EXISTS case_protagonist_pkey;
ALTER TABLE IF EXISTS ONLY public.case_kanban DROP CONSTRAINT IF EXISTS case_kanban_pkey;
ALTER TABLE IF EXISTS ONLY public.case_graph_links DROP CONSTRAINT IF EXISTS case_graph_links_pkey;
ALTER TABLE IF EXISTS ONLY public.case_graph_assets DROP CONSTRAINT IF EXISTS case_graph_assets_pkey;
ALTER TABLE IF EXISTS ONLY public.case_events_ioc DROP CONSTRAINT IF EXISTS case_events_ioc_pkey;
ALTER TABLE IF EXISTS ONLY public.case_events_category DROP CONSTRAINT IF EXISTS case_events_category_pkey;
ALTER TABLE IF EXISTS ONLY public.case_events_category DROP CONSTRAINT IF EXISTS case_events_category_event_id_key;
ALTER TABLE IF EXISTS ONLY public.case_events_assets DROP CONSTRAINT IF EXISTS case_events_assets_pkey;
ALTER TABLE IF EXISTS ONLY public.case_classification DROP CONSTRAINT IF EXISTS case_classification_pkey;
ALTER TABLE IF EXISTS ONLY public.case_assets DROP CONSTRAINT IF EXISTS case_assets_pkey;
ALTER TABLE IF EXISTS ONLY public.assets_type DROP CONSTRAINT IF EXISTS assets_type_pkey;
ALTER TABLE IF EXISTS ONLY public.asset_comments DROP CONSTRAINT IF EXISTS asset_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.analysis_status DROP CONSTRAINT IF EXISTS analysis_status_pkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_pkey;
ALTER TABLE IF EXISTS ONLY public.alerts DROP CONSTRAINT IF EXISTS alerts_alert_uuid_key;
ALTER TABLE IF EXISTS ONLY public.alert_status DROP CONSTRAINT IF EXISTS alert_status_status_name_key;
ALTER TABLE IF EXISTS ONLY public.alert_status DROP CONSTRAINT IF EXISTS alert_status_pkey;
ALTER TABLE IF EXISTS ONLY public.alert_similarity DROP CONSTRAINT IF EXISTS alert_similarity_pkey;
ALTER TABLE IF EXISTS ONLY public.alert_resolution_status DROP CONSTRAINT IF EXISTS alert_resolution_status_resolution_status_name_key;
ALTER TABLE IF EXISTS ONLY public.alert_resolution_status DROP CONSTRAINT IF EXISTS alert_resolution_status_pkey;
ALTER TABLE IF EXISTS ONLY public.alert_iocs_association DROP CONSTRAINT IF EXISTS alert_iocs_association_pkey;
ALTER TABLE IF EXISTS ONLY public.alert_case_association DROP CONSTRAINT IF EXISTS alert_case_association_pkey;
ALTER TABLE IF EXISTS ONLY public.alert_assets_association DROP CONSTRAINT IF EXISTS alert_assets_association_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.user_organisation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_group ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_client ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_case_effective_access ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_case_access ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_activity ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public."user" ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tlp ALTER COLUMN tlp_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.task_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.task_comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.task_assignee ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.similar_alerts_cache ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.severities ALTER COLUMN severity_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.server_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.saved_filters ALTER COLUMN filter_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.review_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.report_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.os_type ALTER COLUMN type_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.organisations ALTER COLUMN org_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.organisation_case_access ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.object_state ALTER COLUMN object_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notes_group_link ALTER COLUMN link_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notes_group ALTER COLUMN group_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notes ALTER COLUMN note_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.note_revisions ALTER COLUMN revision_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.note_directory ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.note_comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.languages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.iris_module_hooks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.iris_module ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.iris_hooks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ioc_type ALTER COLUMN type_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ioc_link ALTER COLUMN ioc_link_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ioc_comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ioc_asset_link ALTER COLUMN ioc_asset_link_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ioc ALTER COLUMN ioc_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.groups ALTER COLUMN group_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.group_case_access ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.global_tasks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.evidence_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.evidence_comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.event_comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.event_category ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.data_store_path ALTER COLUMN path_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.data_store_file ALTER COLUMN file_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_attribute ALTER COLUMN attribute_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contact ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.comments ALTER COLUMN comment_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.client ALTER COLUMN client_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cases_events ALTER COLUMN event_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cases_assets_ext ALTER COLUMN asset_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cases ALTER COLUMN case_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_template_report ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_template ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_tasks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_state ALTER COLUMN state_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_received_file ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_protagonist ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_graph_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_graph_assets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_events_ioc ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_events_category ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_events_assets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_classification ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.case_assets ALTER COLUMN asset_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assets_type ALTER COLUMN asset_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.asset_comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.analysis_status ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.alerts ALTER COLUMN alert_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.alert_status ALTER COLUMN status_id DROP DEFAULT;
ALTER TABLE IF EXISTS public.alert_similarity ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.alert_resolution_status ALTER COLUMN resolution_status_id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.user_organisation_id_seq;
DROP TABLE IF EXISTS public.user_organisation;
DROP SEQUENCE IF EXISTS public.user_id_seq;
DROP SEQUENCE IF EXISTS public.user_group_id_seq;
DROP TABLE IF EXISTS public.user_group;
DROP SEQUENCE IF EXISTS public.user_client_id_seq;
DROP TABLE IF EXISTS public.user_client;
DROP SEQUENCE IF EXISTS public.user_case_effective_access_id_seq;
DROP TABLE IF EXISTS public.user_case_effective_access;
DROP SEQUENCE IF EXISTS public.user_case_access_id_seq;
DROP TABLE IF EXISTS public.user_case_access;
DROP SEQUENCE IF EXISTS public.user_activity_id_seq;
DROP TABLE IF EXISTS public.user_activity;
DROP TABLE IF EXISTS public."user";
DROP SEQUENCE IF EXISTS public.tlp_tlp_id_seq;
DROP TABLE IF EXISTS public.tlp;
DROP SEQUENCE IF EXISTS public.task_status_id_seq;
DROP TABLE IF EXISTS public.task_status;
DROP SEQUENCE IF EXISTS public.task_comments_id_seq;
DROP TABLE IF EXISTS public.task_comments;
DROP SEQUENCE IF EXISTS public.task_assignee_id_seq;
DROP TABLE IF EXISTS public.task_assignee;
DROP SEQUENCE IF EXISTS public.tags_id_seq;
DROP TABLE IF EXISTS public.tags;
DROP SEQUENCE IF EXISTS public.similar_alerts_cache_id_seq;
DROP TABLE IF EXISTS public.similar_alerts_cache;
DROP SEQUENCE IF EXISTS public.severities_severity_id_seq;
DROP TABLE IF EXISTS public.severities;
DROP SEQUENCE IF EXISTS public.server_settings_id_seq;
DROP TABLE IF EXISTS public.server_settings;
DROP SEQUENCE IF EXISTS public.saved_filters_filter_id_seq;
DROP TABLE IF EXISTS public.saved_filters;
DROP SEQUENCE IF EXISTS public.review_status_id_seq;
DROP TABLE IF EXISTS public.review_status;
DROP SEQUENCE IF EXISTS public.report_type_id_seq;
DROP TABLE IF EXISTS public.report_type;
DROP SEQUENCE IF EXISTS public.os_type_type_id_seq;
DROP TABLE IF EXISTS public.os_type;
DROP SEQUENCE IF EXISTS public.organisations_org_id_seq;
DROP TABLE IF EXISTS public.organisations;
DROP SEQUENCE IF EXISTS public.organisation_case_access_id_seq;
DROP TABLE IF EXISTS public.organisation_case_access;
DROP SEQUENCE IF EXISTS public.object_state_object_id_seq;
DROP TABLE IF EXISTS public.object_state;
DROP SEQUENCE IF EXISTS public.notes_note_id_seq;
DROP SEQUENCE IF EXISTS public.notes_group_link_link_id_seq;
DROP TABLE IF EXISTS public.notes_group_link;
DROP SEQUENCE IF EXISTS public.notes_group_group_id_seq;
DROP TABLE IF EXISTS public.notes_group;
DROP TABLE IF EXISTS public.notes;
DROP SEQUENCE IF EXISTS public.note_revisions_revision_id_seq;
DROP TABLE IF EXISTS public.note_revisions;
DROP SEQUENCE IF EXISTS public.note_directory_id_seq;
DROP TABLE IF EXISTS public.note_directory;
DROP SEQUENCE IF EXISTS public.note_comments_id_seq;
DROP TABLE IF EXISTS public.note_comments;
DROP SEQUENCE IF EXISTS public.languages_id_seq;
DROP TABLE IF EXISTS public.languages;
DROP SEQUENCE IF EXISTS public.iris_reports_id_seq;
DROP TABLE IF EXISTS public.iris_reports;
DROP SEQUENCE IF EXISTS public.iris_module_id_seq;
DROP SEQUENCE IF EXISTS public.iris_module_hooks_id_seq;
DROP TABLE IF EXISTS public.iris_module_hooks;
DROP TABLE IF EXISTS public.iris_module;
DROP SEQUENCE IF EXISTS public.iris_hooks_id_seq;
DROP TABLE IF EXISTS public.iris_hooks;
DROP SEQUENCE IF EXISTS public.ioc_type_type_id_seq;
DROP TABLE IF EXISTS public.ioc_type;
DROP SEQUENCE IF EXISTS public.ioc_link_ioc_link_id_seq;
DROP TABLE IF EXISTS public.ioc_link;
DROP SEQUENCE IF EXISTS public.ioc_ioc_id_seq;
DROP SEQUENCE IF EXISTS public.ioc_comments_id_seq;
DROP TABLE IF EXISTS public.ioc_comments;
DROP SEQUENCE IF EXISTS public.ioc_asset_link_ioc_asset_link_id_seq;
DROP TABLE IF EXISTS public.ioc_asset_link;
DROP TABLE IF EXISTS public.ioc;
DROP SEQUENCE IF EXISTS public.groups_group_id_seq;
DROP TABLE IF EXISTS public.groups;
DROP SEQUENCE IF EXISTS public.group_case_access_id_seq;
DROP TABLE IF EXISTS public.group_case_access;
DROP SEQUENCE IF EXISTS public.global_tasks_id_seq;
DROP TABLE IF EXISTS public.global_tasks;
DROP SEQUENCE IF EXISTS public.evidence_type_id_seq;
DROP TABLE IF EXISTS public.evidence_type;
DROP SEQUENCE IF EXISTS public.evidence_comments_id_seq;
DROP TABLE IF EXISTS public.evidence_comments;
DROP SEQUENCE IF EXISTS public.event_comments_id_seq;
DROP TABLE IF EXISTS public.event_comments;
DROP SEQUENCE IF EXISTS public.event_category_id_seq;
DROP TABLE IF EXISTS public.event_category;
DROP SEQUENCE IF EXISTS public.data_store_path_path_id_seq;
DROP TABLE IF EXISTS public.data_store_path;
DROP SEQUENCE IF EXISTS public.data_store_file_file_id_seq;
DROP TABLE IF EXISTS public.data_store_file;
DROP SEQUENCE IF EXISTS public.custom_attribute_attribute_id_seq;
DROP TABLE IF EXISTS public.custom_attribute;
DROP SEQUENCE IF EXISTS public.contact_id_seq;
DROP TABLE IF EXISTS public.contact;
DROP SEQUENCE IF EXISTS public.comments_comment_id_seq;
DROP TABLE IF EXISTS public.comments;
DROP SEQUENCE IF EXISTS public.client_client_id_seq;
DROP TABLE IF EXISTS public.client;
DROP SEQUENCE IF EXISTS public.cases_events_event_id_seq;
DROP TABLE IF EXISTS public.cases_events;
DROP SEQUENCE IF EXISTS public.cases_case_id_seq;
DROP SEQUENCE IF EXISTS public.cases_assets_ext_asset_id_seq;
DROP TABLE IF EXISTS public.cases_assets_ext;
DROP TABLE IF EXISTS public.cases;
DROP SEQUENCE IF EXISTS public.case_template_report_id_seq;
DROP TABLE IF EXISTS public.case_template_report;
DROP SEQUENCE IF EXISTS public.case_template_id_seq;
DROP TABLE IF EXISTS public.case_template;
DROP SEQUENCE IF EXISTS public.case_tasks_id_seq;
DROP TABLE IF EXISTS public.case_tasks;
DROP TABLE IF EXISTS public.case_tags;
DROP SEQUENCE IF EXISTS public.case_state_state_id_seq;
DROP TABLE IF EXISTS public.case_state;
DROP SEQUENCE IF EXISTS public.case_received_file_id_seq;
DROP TABLE IF EXISTS public.case_received_file;
DROP SEQUENCE IF EXISTS public.case_protagonist_id_seq;
DROP TABLE IF EXISTS public.case_protagonist;
DROP TABLE IF EXISTS public.case_kanban;
DROP SEQUENCE IF EXISTS public.case_graph_links_id_seq;
DROP TABLE IF EXISTS public.case_graph_links;
DROP SEQUENCE IF EXISTS public.case_graph_assets_id_seq;
DROP TABLE IF EXISTS public.case_graph_assets;
DROP SEQUENCE IF EXISTS public.case_events_ioc_id_seq;
DROP TABLE IF EXISTS public.case_events_ioc;
DROP SEQUENCE IF EXISTS public.case_events_category_id_seq;
DROP TABLE IF EXISTS public.case_events_category;
DROP SEQUENCE IF EXISTS public.case_events_assets_id_seq;
DROP TABLE IF EXISTS public.case_events_assets;
DROP SEQUENCE IF EXISTS public.case_classification_id_seq;
DROP TABLE IF EXISTS public.case_classification;
DROP SEQUENCE IF EXISTS public.case_assets_asset_id_seq;
DROP TABLE IF EXISTS public.case_assets;
DROP SEQUENCE IF EXISTS public.assets_type_asset_id_seq;
DROP TABLE IF EXISTS public.assets_type;
DROP SEQUENCE IF EXISTS public.asset_comments_id_seq;
DROP TABLE IF EXISTS public.asset_comments;
DROP SEQUENCE IF EXISTS public.analysis_status_id_seq;
DROP TABLE IF EXISTS public.analysis_status;
DROP SEQUENCE IF EXISTS public.alerts_alert_id_seq;
DROP TABLE IF EXISTS public.alerts;
DROP SEQUENCE IF EXISTS public.alert_status_status_id_seq;
DROP TABLE IF EXISTS public.alert_status;
DROP SEQUENCE IF EXISTS public.alert_similarity_id_seq;
DROP TABLE IF EXISTS public.alert_similarity;
DROP SEQUENCE IF EXISTS public.alert_resolution_status_resolution_status_id_seq;
DROP TABLE IF EXISTS public.alert_resolution_status;
DROP TABLE IF EXISTS public.alert_iocs_association;
DROP TABLE IF EXISTS public.alert_case_association;
DROP TABLE IF EXISTS public.alert_assets_association;
DROP TABLE IF EXISTS public.alembic_version;
DROP EXTENSION IF EXISTS pgcrypto;
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: alert_assets_association; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_assets_association (
    alert_id bigint NOT NULL,
    asset_id bigint NOT NULL
);


--
-- Name: alert_case_association; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_case_association (
    alert_id bigint NOT NULL,
    case_id bigint NOT NULL
);


--
-- Name: alert_iocs_association; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_iocs_association (
    alert_id bigint NOT NULL,
    ioc_id bigint NOT NULL
);


--
-- Name: alert_resolution_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_resolution_status (
    resolution_status_id integer NOT NULL,
    resolution_status_name text NOT NULL,
    resolution_status_description text
);


--
-- Name: alert_resolution_status_resolution_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alert_resolution_status_resolution_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alert_resolution_status_resolution_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alert_resolution_status_resolution_status_id_seq OWNED BY public.alert_resolution_status.resolution_status_id;


--
-- Name: alert_similarity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_similarity (
    id bigint NOT NULL,
    alert_id bigint NOT NULL,
    similar_alert_id bigint NOT NULL,
    similarity_type character varying(255),
    matching_asset_id bigint,
    matching_ioc_id bigint
);


--
-- Name: alert_similarity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alert_similarity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alert_similarity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alert_similarity_id_seq OWNED BY public.alert_similarity.id;


--
-- Name: alert_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_status (
    status_id integer NOT NULL,
    status_name text NOT NULL,
    status_description text
);


--
-- Name: alert_status_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alert_status_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alert_status_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alert_status_status_id_seq OWNED BY public.alert_status.status_id;


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    alert_id bigint NOT NULL,
    alert_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    alert_title text NOT NULL,
    alert_description text,
    alert_source text,
    alert_source_ref text,
    alert_source_link text,
    alert_source_content json,
    alert_severity_id integer NOT NULL,
    alert_status_id integer NOT NULL,
    alert_context json,
    alert_source_event_time timestamp without time zone DEFAULT now() NOT NULL,
    alert_creation_time timestamp without time zone DEFAULT now() NOT NULL,
    alert_note text,
    alert_tags text,
    alert_owner_id bigint,
    modification_history json,
    alert_customer_id bigint NOT NULL,
    alert_classification_id integer,
    alert_resolution_status_id integer
);


--
-- Name: alerts_alert_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.alerts_alert_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alerts_alert_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.alerts_alert_id_seq OWNED BY public.alerts.alert_id;


--
-- Name: analysis_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analysis_status (
    id integer NOT NULL,
    name text
);


--
-- Name: analysis_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.analysis_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: analysis_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.analysis_status_id_seq OWNED BY public.analysis_status.id;


--
-- Name: asset_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asset_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_asset_id bigint
);


--
-- Name: asset_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.asset_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asset_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.asset_comments_id_seq OWNED BY public.asset_comments.id;


--
-- Name: assets_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets_type (
    asset_id integer NOT NULL,
    asset_name character varying(155),
    asset_description character varying(255),
    asset_icon_not_compromised character varying(255),
    asset_icon_compromised character varying(255)
);


--
-- Name: assets_type_asset_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assets_type_asset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assets_type_asset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assets_type_asset_id_seq OWNED BY public.assets_type.asset_id;


--
-- Name: case_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_assets (
    asset_id bigint NOT NULL,
    asset_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    asset_name text,
    asset_description text,
    asset_domain text,
    asset_ip text,
    asset_info text,
    asset_compromise_status_id integer,
    asset_type_id integer,
    asset_tags text,
    case_id bigint,
    date_added timestamp without time zone,
    date_update timestamp without time zone,
    user_id bigint,
    analysis_status_id integer,
    custom_attributes json,
    asset_enrichment jsonb,
    modification_history json
);


--
-- Name: case_assets_asset_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_assets_asset_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_assets_asset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_assets_asset_id_seq OWNED BY public.case_assets.asset_id;


--
-- Name: case_classification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_classification (
    id integer NOT NULL,
    name text,
    name_expanded text,
    description text,
    creation_date timestamp without time zone DEFAULT now(),
    created_by_id bigint
);


--
-- Name: case_classification_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_classification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_classification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_classification_id_seq OWNED BY public.case_classification.id;


--
-- Name: case_events_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_events_assets (
    id bigint NOT NULL,
    event_id bigint,
    asset_id bigint,
    case_id bigint
);


--
-- Name: case_events_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_events_assets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_events_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_events_assets_id_seq OWNED BY public.case_events_assets.id;


--
-- Name: case_events_category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_events_category (
    id integer NOT NULL,
    event_id bigint,
    category_id integer
);


--
-- Name: case_events_category_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_events_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_events_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_events_category_id_seq OWNED BY public.case_events_category.id;


--
-- Name: case_events_ioc; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_events_ioc (
    id bigint NOT NULL,
    event_id bigint,
    ioc_id bigint,
    case_id bigint
);


--
-- Name: case_events_ioc_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_events_ioc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_events_ioc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_events_ioc_id_seq OWNED BY public.case_events_ioc.id;


--
-- Name: case_graph_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_graph_assets (
    id integer NOT NULL,
    case_id bigint,
    asset_id integer,
    asset_type_id integer
);


--
-- Name: case_graph_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_graph_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_graph_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_graph_assets_id_seq OWNED BY public.case_graph_assets.id;


--
-- Name: case_graph_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_graph_links (
    id integer NOT NULL,
    case_id bigint,
    source_id integer,
    dest_id integer
);


--
-- Name: case_graph_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_graph_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_graph_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_graph_links_id_seq OWNED BY public.case_graph_links.id;


--
-- Name: case_kanban; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_kanban (
    case_id bigint NOT NULL,
    kanban_data text
);


--
-- Name: case_protagonist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_protagonist (
    id integer NOT NULL,
    case_id bigint,
    user_id bigint,
    name text,
    contact text,
    role text
);


--
-- Name: case_protagonist_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_protagonist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_protagonist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_protagonist_id_seq OWNED BY public.case_protagonist.id;


--
-- Name: case_received_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_received_file (
    id bigint NOT NULL,
    file_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    filename text,
    date_added timestamp without time zone,
    acquisition_date timestamp without time zone,
    file_hash text,
    file_description text,
    file_size bigint,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    case_id bigint,
    user_id bigint,
    type_id integer,
    custom_attributes json,
    chain_of_custody json,
    modification_history json
);


--
-- Name: case_received_file_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_received_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_received_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_received_file_id_seq OWNED BY public.case_received_file.id;


--
-- Name: case_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_state (
    state_id integer NOT NULL,
    state_name text NOT NULL,
    state_description text,
    protected boolean
);


--
-- Name: case_state_state_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_state_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_state_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_state_state_id_seq OWNED BY public.case_state.state_id;


--
-- Name: case_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_tags (
    case_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


--
-- Name: case_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_tasks (
    id bigint NOT NULL,
    task_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    task_title text,
    task_description text,
    task_tags text,
    task_open_date timestamp without time zone,
    task_close_date timestamp without time zone,
    task_last_update timestamp without time zone,
    task_userid_open bigint,
    task_userid_close bigint,
    task_userid_update bigint,
    task_status_id integer,
    task_case_id bigint,
    custom_attributes json,
    modification_history json
);


--
-- Name: case_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_tasks_id_seq OWNED BY public.case_tasks.id;


--
-- Name: case_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_template (
    id integer NOT NULL,
    created_by_user_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone,
    name character varying NOT NULL,
    display_name character varying,
    description text,
    author character varying,
    title_prefix character varying,
    summary character varying,
    tags json,
    tasks json,
    note_directories json,
    classification character varying
);


--
-- Name: case_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_template_id_seq OWNED BY public.case_template.id;


--
-- Name: case_template_report; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_template_report (
    id integer NOT NULL,
    name character varying,
    description character varying,
    internal_reference character varying,
    naming_format character varying,
    created_by_user_id integer,
    date_created timestamp without time zone,
    language_id integer,
    report_type_id integer
);


--
-- Name: case_template_report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.case_template_report_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_template_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.case_template_report_id_seq OWNED BY public.case_template_report.id;


--
-- Name: cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cases (
    case_id bigint NOT NULL,
    soc_id character varying(256),
    client_id bigint NOT NULL,
    name character varying(256),
    description text,
    open_date date,
    close_date date,
    initial_date timestamp without time zone DEFAULT now() NOT NULL,
    closing_note text,
    user_id bigint,
    owner_id bigint,
    status_id integer DEFAULT 0 NOT NULL,
    state_id integer,
    custom_attributes json,
    case_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    classification_id integer,
    reviewer_id bigint,
    review_status_id integer,
    severity_id integer,
    modification_history json
);


--
-- Name: cases_assets_ext; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cases_assets_ext (
    asset_id integer NOT NULL,
    type_id integer,
    case_id bigint,
    asset_content text
);


--
-- Name: cases_assets_ext_asset_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cases_assets_ext_asset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cases_assets_ext_asset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cases_assets_ext_asset_id_seq OWNED BY public.cases_assets_ext.asset_id;


--
-- Name: cases_case_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cases_case_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cases_case_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cases_case_id_seq OWNED BY public.cases.case_id;


--
-- Name: cases_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cases_events (
    event_id bigint NOT NULL,
    parent_event_id bigint,
    event_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    case_id bigint,
    event_title text,
    event_source text,
    event_content text,
    event_raw text,
    event_date timestamp without time zone,
    event_added timestamp without time zone,
    event_in_graph boolean,
    event_in_summary boolean,
    user_id bigint,
    modification_history jsonb,
    event_color text,
    event_tags text,
    event_tz text,
    event_date_wtz timestamp without time zone,
    event_is_flagged boolean,
    custom_attributes jsonb,
    CONSTRAINT check_different_ids CHECK ((event_id <> parent_event_id))
);


--
-- Name: cases_events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cases_events_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cases_events_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cases_events_event_id_seq OWNED BY public.cases_events.event_id;


--
-- Name: client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client (
    client_id bigint NOT NULL,
    client_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    name text,
    description text,
    sla text,
    creation_date timestamp without time zone DEFAULT now(),
    created_by bigint,
    last_update_date timestamp without time zone DEFAULT now(),
    custom_attributes json
);


--
-- Name: client_client_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.client_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: client_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.client_client_id_seq OWNED BY public.client.client_id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comments (
    comment_id bigint NOT NULL,
    comment_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    comment_text text,
    comment_date timestamp without time zone,
    comment_update_date timestamp without time zone,
    comment_user_id bigint,
    comment_case_id bigint,
    comment_alert_id bigint
);


--
-- Name: comments_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comments_comment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comments_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comments_comment_id_seq OWNED BY public.comments.comment_id;


--
-- Name: contact; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contact (
    id bigint NOT NULL,
    contact_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    contact_name text,
    contact_email text,
    contact_role text,
    contact_note text,
    contact_work_phone text,
    contact_mobile_phone text,
    custom_attributes json,
    client_id bigint
);


--
-- Name: contact_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contact_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contact_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contact_id_seq OWNED BY public.contact.id;


--
-- Name: custom_attribute; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_attribute (
    attribute_id integer NOT NULL,
    attribute_display_name text,
    attribute_description text,
    attribute_for text,
    attribute_content json
);


--
-- Name: custom_attribute_attribute_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_attribute_attribute_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_attribute_attribute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_attribute_attribute_id_seq OWNED BY public.custom_attribute.attribute_id;


--
-- Name: data_store_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_store_file (
    file_id bigint NOT NULL,
    file_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    file_original_name text NOT NULL,
    file_local_name text NOT NULL,
    file_description text,
    file_date_added timestamp without time zone,
    file_tags text,
    file_size bigint,
    file_is_ioc boolean,
    file_is_evidence boolean,
    file_password text,
    file_parent_id bigint NOT NULL,
    file_sha256 text,
    added_by_user_id bigint NOT NULL,
    modification_history json,
    file_case_id bigint NOT NULL
);


--
-- Name: data_store_file_file_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.data_store_file_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: data_store_file_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.data_store_file_file_id_seq OWNED BY public.data_store_file.file_id;


--
-- Name: data_store_path; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_store_path (
    path_id bigint NOT NULL,
    path_uuid uuid,
    path_name text NOT NULL,
    path_parent_id bigint,
    path_is_root boolean,
    path_case_id bigint NOT NULL
);


--
-- Name: data_store_path_path_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.data_store_path_path_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: data_store_path_path_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.data_store_path_path_id_seq OWNED BY public.data_store_path.path_id;


--
-- Name: event_category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_category (
    id integer NOT NULL,
    name text
);


--
-- Name: event_category_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.event_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.event_category_id_seq OWNED BY public.event_category.id;


--
-- Name: event_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_event_id bigint
);


--
-- Name: event_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.event_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: event_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.event_comments_id_seq OWNED BY public.event_comments.id;


--
-- Name: evidence_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evidence_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_evidence_id bigint
);


--
-- Name: evidence_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.evidence_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: evidence_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.evidence_comments_id_seq OWNED BY public.evidence_comments.id;


--
-- Name: evidence_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evidence_type (
    id integer NOT NULL,
    name text,
    description text,
    creation_date timestamp without time zone DEFAULT now(),
    created_by_id bigint
);


--
-- Name: evidence_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.evidence_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: evidence_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.evidence_type_id_seq OWNED BY public.evidence_type.id;


--
-- Name: global_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.global_tasks (
    id bigint NOT NULL,
    task_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    task_title text,
    task_description text,
    task_tags text,
    task_open_date timestamp without time zone,
    task_close_date timestamp without time zone,
    task_last_update timestamp without time zone,
    task_userid_open bigint,
    task_userid_close bigint,
    task_userid_update bigint,
    task_assignee_id bigint,
    task_status_id integer
);


--
-- Name: global_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.global_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: global_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.global_tasks_id_seq OWNED BY public.global_tasks.id;


--
-- Name: group_case_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_case_access (
    id bigint NOT NULL,
    group_id bigint NOT NULL,
    case_id bigint NOT NULL,
    access_level bigint NOT NULL
);


--
-- Name: group_case_access_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.group_case_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: group_case_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.group_case_access_id_seq OWNED BY public.group_case_access.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    group_id bigint NOT NULL,
    group_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    group_name text NOT NULL,
    group_description text,
    group_permissions bigint NOT NULL,
    group_auto_follow boolean NOT NULL,
    group_auto_follow_access_level bigint NOT NULL
);


--
-- Name: groups_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.groups_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: groups_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.groups_group_id_seq OWNED BY public.groups.group_id;


--
-- Name: ioc; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ioc (
    ioc_id bigint NOT NULL,
    ioc_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    ioc_value text,
    ioc_type_id integer,
    ioc_description text,
    ioc_tags character varying(512),
    user_id bigint,
    ioc_misp text,
    ioc_tlp_id integer,
    custom_attributes json,
    ioc_enrichment jsonb,
    modification_history json
);


--
-- Name: ioc_asset_link; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ioc_asset_link (
    ioc_asset_link_id integer NOT NULL,
    ioc_id bigint NOT NULL,
    asset_id bigint NOT NULL
);


--
-- Name: ioc_asset_link_ioc_asset_link_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ioc_asset_link_ioc_asset_link_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ioc_asset_link_ioc_asset_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ioc_asset_link_ioc_asset_link_id_seq OWNED BY public.ioc_asset_link.ioc_asset_link_id;


--
-- Name: ioc_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ioc_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_ioc_id bigint
);


--
-- Name: ioc_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ioc_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ioc_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ioc_comments_id_seq OWNED BY public.ioc_comments.id;


--
-- Name: ioc_ioc_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ioc_ioc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ioc_ioc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ioc_ioc_id_seq OWNED BY public.ioc.ioc_id;


--
-- Name: ioc_link; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ioc_link (
    ioc_link_id integer NOT NULL,
    ioc_id bigint,
    case_id bigint NOT NULL
);


--
-- Name: ioc_link_ioc_link_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ioc_link_ioc_link_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ioc_link_ioc_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ioc_link_ioc_link_id_seq OWNED BY public.ioc_link.ioc_link_id;


--
-- Name: ioc_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ioc_type (
    type_id integer NOT NULL,
    type_name text,
    type_description text,
    type_taxonomy text,
    type_validation_regex text,
    type_validation_expect text
);


--
-- Name: ioc_type_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ioc_type_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ioc_type_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ioc_type_type_id_seq OWNED BY public.ioc_type.type_id;


--
-- Name: iris_hooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iris_hooks (
    id integer NOT NULL,
    hook_name text,
    hook_description text
);


--
-- Name: iris_hooks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.iris_hooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: iris_hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.iris_hooks_id_seq OWNED BY public.iris_hooks.id;


--
-- Name: iris_module; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iris_module (
    id integer NOT NULL,
    added_by_id bigint NOT NULL,
    module_human_name text,
    module_name text,
    module_description text,
    module_version text,
    interface_version text,
    date_added timestamp without time zone,
    is_active boolean,
    has_pipeline boolean,
    pipeline_args json,
    module_config json,
    module_type text
);


--
-- Name: iris_module_hooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iris_module_hooks (
    id bigint NOT NULL,
    module_id integer NOT NULL,
    hook_id integer NOT NULL,
    is_manual_hook boolean,
    manual_hook_ui_name text,
    retry_on_fail boolean,
    max_retry integer,
    run_asynchronously boolean,
    wait_till_return boolean
);


--
-- Name: iris_module_hooks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.iris_module_hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: iris_module_hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.iris_module_hooks_id_seq OWNED BY public.iris_module_hooks.id;


--
-- Name: iris_module_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.iris_module_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: iris_module_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.iris_module_id_seq OWNED BY public.iris_module.id;


--
-- Name: iris_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.iris_reports (
    report_id integer NOT NULL,
    case_id bigint NOT NULL,
    report_title character varying(155),
    report_date timestamp without time zone,
    report_content json,
    user_id bigint
);


--
-- Name: iris_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.iris_reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: languages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.languages (
    id integer NOT NULL,
    name character varying,
    code character varying
);


--
-- Name: languages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.languages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.languages_id_seq OWNED BY public.languages.id;


--
-- Name: note_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_note_id bigint
);


--
-- Name: note_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.note_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: note_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.note_comments_id_seq OWNED BY public.note_comments.id;


--
-- Name: note_directory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note_directory (
    id bigint NOT NULL,
    name text NOT NULL,
    parent_id bigint,
    case_id bigint NOT NULL
);


--
-- Name: note_directory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.note_directory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: note_directory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.note_directory_id_seq OWNED BY public.note_directory.id;


--
-- Name: note_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note_revisions (
    revision_id bigint NOT NULL,
    note_id bigint NOT NULL,
    revision_number integer NOT NULL,
    note_title character varying(155),
    note_content text,
    note_user bigint,
    revision_timestamp timestamp without time zone
);


--
-- Name: note_revisions_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.note_revisions_revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: note_revisions_revision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.note_revisions_revision_id_seq OWNED BY public.note_revisions.revision_id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes (
    note_id bigint NOT NULL,
    note_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    note_title character varying(155),
    note_content text,
    note_user bigint,
    note_creationdate timestamp without time zone,
    note_lastupdate timestamp without time zone,
    note_case_id bigint,
    custom_attributes json,
    directory_id bigint,
    modification_history json
);


--
-- Name: notes_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes_group (
    group_id bigint NOT NULL,
    group_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    group_title character varying(155),
    group_user bigint,
    group_creationdate timestamp without time zone,
    group_lastupdate timestamp without time zone,
    group_case_id bigint
);


--
-- Name: notes_group_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notes_group_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notes_group_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notes_group_group_id_seq OWNED BY public.notes_group.group_id;


--
-- Name: notes_group_link; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notes_group_link (
    link_id bigint NOT NULL,
    group_id bigint,
    note_id bigint,
    case_id bigint
);


--
-- Name: notes_group_link_link_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notes_group_link_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notes_group_link_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notes_group_link_link_id_seq OWNED BY public.notes_group_link.link_id;


--
-- Name: notes_note_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notes_note_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notes_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notes_note_id_seq OWNED BY public.notes.note_id;


--
-- Name: object_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.object_state (
    object_id bigint NOT NULL,
    object_case_id bigint,
    object_updated_by_id integer,
    object_name text,
    object_state bigint,
    object_last_update timestamp without time zone
);


--
-- Name: object_state_object_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.object_state_object_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: object_state_object_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.object_state_object_id_seq OWNED BY public.object_state.object_id;


--
-- Name: organisation_case_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organisation_case_access (
    id bigint NOT NULL,
    org_id bigint NOT NULL,
    case_id bigint NOT NULL,
    access_level bigint NOT NULL
);


--
-- Name: organisation_case_access_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organisation_case_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organisation_case_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organisation_case_access_id_seq OWNED BY public.organisation_case_access.id;


--
-- Name: organisations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.organisations (
    org_id bigint NOT NULL,
    org_uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    org_name text NOT NULL,
    org_description text,
    org_url text,
    org_logo text,
    org_email text,
    org_nationality text,
    org_sector text,
    org_type text
);


--
-- Name: organisations_org_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.organisations_org_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organisations_org_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.organisations_org_id_seq OWNED BY public.organisations.org_id;


--
-- Name: os_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.os_type (
    type_id integer NOT NULL,
    type_name character varying(155)
);


--
-- Name: os_type_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.os_type_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: os_type_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.os_type_type_id_seq OWNED BY public.os_type.type_id;


--
-- Name: report_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_type (
    id integer NOT NULL,
    name text
);


--
-- Name: report_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.report_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: report_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.report_type_id_seq OWNED BY public.report_type.id;


--
-- Name: review_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.review_status (
    id integer NOT NULL,
    status_name text NOT NULL
);


--
-- Name: review_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.review_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: review_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.review_status_id_seq OWNED BY public.review_status.id;


--
-- Name: saved_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_filters (
    filter_id bigint NOT NULL,
    created_by bigint NOT NULL,
    filter_name text NOT NULL,
    filter_description text,
    filter_data json NOT NULL,
    filter_is_private boolean NOT NULL,
    filter_type text NOT NULL
);


--
-- Name: saved_filters_filter_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.saved_filters_filter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: saved_filters_filter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.saved_filters_filter_id_seq OWNED BY public.saved_filters.filter_id;


--
-- Name: server_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.server_settings (
    id integer NOT NULL,
    https_proxy text,
    http_proxy text,
    prevent_post_mod_repush boolean,
    prevent_post_objects_repush boolean,
    has_updates_available boolean,
    enable_updates_check boolean,
    password_policy_min_length integer,
    password_policy_upper_case boolean,
    password_policy_lower_case boolean,
    password_policy_digit boolean,
    password_policy_special_chars text,
    enforce_mfa boolean
);


--
-- Name: server_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.server_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: server_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.server_settings_id_seq OWNED BY public.server_settings.id;


--
-- Name: severities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.severities (
    severity_id integer NOT NULL,
    severity_name text NOT NULL,
    severity_description text
);


--
-- Name: severities_severity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.severities_severity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: severities_severity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.severities_severity_id_seq OWNED BY public.severities.severity_id;


--
-- Name: similar_alerts_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.similar_alerts_cache (
    id bigint NOT NULL,
    customer_id bigint NOT NULL,
    asset_name text,
    ioc_value text,
    alert_id bigint NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    asset_type_id integer,
    ioc_type_id integer
);


--
-- Name: similar_alerts_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.similar_alerts_cache_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: similar_alerts_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.similar_alerts_cache_id_seq OWNED BY public.similar_alerts_cache.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id bigint NOT NULL,
    tag_title text,
    tag_creation_date timestamp without time zone,
    tag_namespace text
);


--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: task_assignee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_assignee (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    task_id bigint NOT NULL
);


--
-- Name: task_assignee_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_assignee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_assignee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_assignee_id_seq OWNED BY public.task_assignee.id;


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_comments (
    id bigint NOT NULL,
    comment_id bigint,
    comment_task_id bigint
);


--
-- Name: task_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_comments_id_seq OWNED BY public.task_comments.id;


--
-- Name: task_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_status (
    id integer NOT NULL,
    status_name text,
    status_description text,
    status_bscolor text
);


--
-- Name: task_status_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_status_id_seq OWNED BY public.task_status.id;


--
-- Name: tlp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tlp (
    tlp_id integer NOT NULL,
    tlp_name text,
    tlp_bscolor text
);


--
-- Name: tlp_tlp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tlp_tlp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tlp_tlp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tlp_tlp_id_seq OWNED BY public.tlp.tlp_id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id bigint NOT NULL,
    "user" character varying(64),
    name character varying(64),
    email character varying(120),
    uuid uuid DEFAULT public.gen_random_uuid() NOT NULL,
    password character varying(500),
    ctx_case integer,
    ctx_human_case character varying(256),
    active boolean,
    api_key text,
    external_id text,
    in_dark_mode boolean,
    has_mini_sidebar boolean,
    has_deletion_confirmation boolean,
    is_service_account boolean,
    mfa_secrets text,
    webauthn_credentials json,
    mfa_setup_complete boolean
);


--
-- Name: user_activity; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_activity (
    id bigint NOT NULL,
    user_id bigint,
    case_id bigint,
    activity_date timestamp without time zone,
    activity_desc text,
    user_input boolean,
    is_from_api boolean,
    display_in_ui boolean
);


--
-- Name: user_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_activity_id_seq OWNED BY public.user_activity.id;


--
-- Name: user_case_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_case_access (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    case_id bigint NOT NULL,
    access_level bigint NOT NULL
);


--
-- Name: user_case_access_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_case_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_case_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_case_access_id_seq OWNED BY public.user_case_access.id;


--
-- Name: user_case_effective_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_case_effective_access (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    case_id bigint NOT NULL,
    access_level bigint NOT NULL
);


--
-- Name: user_case_effective_access_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_case_effective_access_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_case_effective_access_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_case_effective_access_id_seq OWNED BY public.user_case_effective_access.id;


--
-- Name: user_client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_client (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    client_id bigint NOT NULL,
    access_level bigint NOT NULL,
    allow_alerts boolean NOT NULL
);


--
-- Name: user_client_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_client_id_seq OWNED BY public.user_client.id;


--
-- Name: user_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_group (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id bigint NOT NULL
);


--
-- Name: user_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_group_id_seq OWNED BY public.user_group.id;


--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: user_organisation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_organisation (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    org_id bigint NOT NULL,
    is_primary_org boolean NOT NULL
);


--
-- Name: user_organisation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_organisation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_organisation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_organisation_id_seq OWNED BY public.user_organisation.id;


--
-- Name: alert_resolution_status resolution_status_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_resolution_status ALTER COLUMN resolution_status_id SET DEFAULT nextval('public.alert_resolution_status_resolution_status_id_seq'::regclass);


--
-- Name: alert_similarity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_similarity ALTER COLUMN id SET DEFAULT nextval('public.alert_similarity_id_seq'::regclass);


--
-- Name: alert_status status_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_status ALTER COLUMN status_id SET DEFAULT nextval('public.alert_status_status_id_seq'::regclass);


--
-- Name: alerts alert_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts ALTER COLUMN alert_id SET DEFAULT nextval('public.alerts_alert_id_seq'::regclass);


--
-- Name: analysis_status id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analysis_status ALTER COLUMN id SET DEFAULT nextval('public.analysis_status_id_seq'::regclass);


--
-- Name: asset_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_comments ALTER COLUMN id SET DEFAULT nextval('public.asset_comments_id_seq'::regclass);


--
-- Name: assets_type asset_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets_type ALTER COLUMN asset_id SET DEFAULT nextval('public.assets_type_asset_id_seq'::regclass);


--
-- Name: case_assets asset_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assets ALTER COLUMN asset_id SET DEFAULT nextval('public.case_assets_asset_id_seq'::regclass);


--
-- Name: case_classification id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_classification ALTER COLUMN id SET DEFAULT nextval('public.case_classification_id_seq'::regclass);


--
-- Name: case_events_assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_assets ALTER COLUMN id SET DEFAULT nextval('public.case_events_assets_id_seq'::regclass);


--
-- Name: case_events_category id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_category ALTER COLUMN id SET DEFAULT nextval('public.case_events_category_id_seq'::regclass);


--
-- Name: case_events_ioc id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_ioc ALTER COLUMN id SET DEFAULT nextval('public.case_events_ioc_id_seq'::regclass);


--
-- Name: case_graph_assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_graph_assets ALTER COLUMN id SET DEFAULT nextval('public.case_graph_assets_id_seq'::regclass);


--
-- Name: case_graph_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_graph_links ALTER COLUMN id SET DEFAULT nextval('public.case_graph_links_id_seq'::regclass);


--
-- Name: case_protagonist id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_protagonist ALTER COLUMN id SET DEFAULT nextval('public.case_protagonist_id_seq'::regclass);


--
-- Name: case_received_file id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_received_file ALTER COLUMN id SET DEFAULT nextval('public.case_received_file_id_seq'::regclass);


--
-- Name: case_state state_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_state ALTER COLUMN state_id SET DEFAULT nextval('public.case_state_state_id_seq'::regclass);


--
-- Name: case_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_tasks ALTER COLUMN id SET DEFAULT nextval('public.case_tasks_id_seq'::regclass);


--
-- Name: case_template id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_template ALTER COLUMN id SET DEFAULT nextval('public.case_template_id_seq'::regclass);


--
-- Name: case_template_report id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_template_report ALTER COLUMN id SET DEFAULT nextval('public.case_template_report_id_seq'::regclass);


--
-- Name: cases case_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases ALTER COLUMN case_id SET DEFAULT nextval('public.cases_case_id_seq'::regclass);


--
-- Name: cases_assets_ext asset_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases_assets_ext ALTER COLUMN asset_id SET DEFAULT nextval('public.cases_assets_ext_asset_id_seq'::regclass);


--
-- Name: cases_events event_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases_events ALTER COLUMN event_id SET DEFAULT nextval('public.cases_events_event_id_seq'::regclass);


--
-- Name: client client_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client ALTER COLUMN client_id SET DEFAULT nextval('public.client_client_id_seq'::regclass);


--
-- Name: comments comment_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments ALTER COLUMN comment_id SET DEFAULT nextval('public.comments_comment_id_seq'::regclass);


--
-- Name: contact id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact ALTER COLUMN id SET DEFAULT nextval('public.contact_id_seq'::regclass);


--
-- Name: custom_attribute attribute_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_attribute ALTER COLUMN attribute_id SET DEFAULT nextval('public.custom_attribute_attribute_id_seq'::regclass);


--
-- Name: data_store_file file_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_store_file ALTER COLUMN file_id SET DEFAULT nextval('public.data_store_file_file_id_seq'::regclass);


--
-- Name: data_store_path path_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_store_path ALTER COLUMN path_id SET DEFAULT nextval('public.data_store_path_path_id_seq'::regclass);


--
-- Name: event_category id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_category ALTER COLUMN id SET DEFAULT nextval('public.event_category_id_seq'::regclass);


--
-- Name: event_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_comments ALTER COLUMN id SET DEFAULT nextval('public.event_comments_id_seq'::regclass);


--
-- Name: evidence_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_comments ALTER COLUMN id SET DEFAULT nextval('public.evidence_comments_id_seq'::regclass);


--
-- Name: evidence_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_type ALTER COLUMN id SET DEFAULT nextval('public.evidence_type_id_seq'::regclass);


--
-- Name: global_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_tasks ALTER COLUMN id SET DEFAULT nextval('public.global_tasks_id_seq'::regclass);


--
-- Name: group_case_access id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_case_access ALTER COLUMN id SET DEFAULT nextval('public.group_case_access_id_seq'::regclass);


--
-- Name: groups group_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups ALTER COLUMN group_id SET DEFAULT nextval('public.groups_group_id_seq'::regclass);


--
-- Name: ioc ioc_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc ALTER COLUMN ioc_id SET DEFAULT nextval('public.ioc_ioc_id_seq'::regclass);


--
-- Name: ioc_asset_link ioc_asset_link_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_asset_link ALTER COLUMN ioc_asset_link_id SET DEFAULT nextval('public.ioc_asset_link_ioc_asset_link_id_seq'::regclass);


--
-- Name: ioc_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_comments ALTER COLUMN id SET DEFAULT nextval('public.ioc_comments_id_seq'::regclass);


--
-- Name: ioc_link ioc_link_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_link ALTER COLUMN ioc_link_id SET DEFAULT nextval('public.ioc_link_ioc_link_id_seq'::regclass);


--
-- Name: ioc_type type_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_type ALTER COLUMN type_id SET DEFAULT nextval('public.ioc_type_type_id_seq'::regclass);


--
-- Name: iris_hooks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_hooks ALTER COLUMN id SET DEFAULT nextval('public.iris_hooks_id_seq'::regclass);


--
-- Name: iris_module id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_module ALTER COLUMN id SET DEFAULT nextval('public.iris_module_id_seq'::regclass);


--
-- Name: iris_module_hooks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_module_hooks ALTER COLUMN id SET DEFAULT nextval('public.iris_module_hooks_id_seq'::regclass);


--
-- Name: languages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages ALTER COLUMN id SET DEFAULT nextval('public.languages_id_seq'::regclass);


--
-- Name: note_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_comments ALTER COLUMN id SET DEFAULT nextval('public.note_comments_id_seq'::regclass);


--
-- Name: note_directory id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_directory ALTER COLUMN id SET DEFAULT nextval('public.note_directory_id_seq'::regclass);


--
-- Name: note_revisions revision_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_revisions ALTER COLUMN revision_id SET DEFAULT nextval('public.note_revisions_revision_id_seq'::regclass);


--
-- Name: notes note_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes ALTER COLUMN note_id SET DEFAULT nextval('public.notes_note_id_seq'::regclass);


--
-- Name: notes_group group_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes_group ALTER COLUMN group_id SET DEFAULT nextval('public.notes_group_group_id_seq'::regclass);


--
-- Name: notes_group_link link_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes_group_link ALTER COLUMN link_id SET DEFAULT nextval('public.notes_group_link_link_id_seq'::regclass);


--
-- Name: object_state object_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.object_state ALTER COLUMN object_id SET DEFAULT nextval('public.object_state_object_id_seq'::regclass);


--
-- Name: organisation_case_access id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisation_case_access ALTER COLUMN id SET DEFAULT nextval('public.organisation_case_access_id_seq'::regclass);


--
-- Name: organisations org_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisations ALTER COLUMN org_id SET DEFAULT nextval('public.organisations_org_id_seq'::regclass);


--
-- Name: os_type type_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.os_type ALTER COLUMN type_id SET DEFAULT nextval('public.os_type_type_id_seq'::regclass);


--
-- Name: report_type id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_type ALTER COLUMN id SET DEFAULT nextval('public.report_type_id_seq'::regclass);


--
-- Name: review_status id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_status ALTER COLUMN id SET DEFAULT nextval('public.review_status_id_seq'::regclass);


--
-- Name: saved_filters filter_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_filters ALTER COLUMN filter_id SET DEFAULT nextval('public.saved_filters_filter_id_seq'::regclass);


--
-- Name: server_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_settings ALTER COLUMN id SET DEFAULT nextval('public.server_settings_id_seq'::regclass);


--
-- Name: severities severity_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.severities ALTER COLUMN severity_id SET DEFAULT nextval('public.severities_severity_id_seq'::regclass);


--
-- Name: similar_alerts_cache id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.similar_alerts_cache ALTER COLUMN id SET DEFAULT nextval('public.similar_alerts_cache_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: task_assignee id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_assignee ALTER COLUMN id SET DEFAULT nextval('public.task_assignee_id_seq'::regclass);


--
-- Name: task_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments ALTER COLUMN id SET DEFAULT nextval('public.task_comments_id_seq'::regclass);


--
-- Name: task_status id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_status ALTER COLUMN id SET DEFAULT nextval('public.task_status_id_seq'::regclass);


--
-- Name: tlp tlp_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tlp ALTER COLUMN tlp_id SET DEFAULT nextval('public.tlp_tlp_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: user_activity id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activity ALTER COLUMN id SET DEFAULT nextval('public.user_activity_id_seq'::regclass);


--
-- Name: user_case_access id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_case_access ALTER COLUMN id SET DEFAULT nextval('public.user_case_access_id_seq'::regclass);


--
-- Name: user_case_effective_access id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_case_effective_access ALTER COLUMN id SET DEFAULT nextval('public.user_case_effective_access_id_seq'::regclass);


--
-- Name: user_client id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_client ALTER COLUMN id SET DEFAULT nextval('public.user_client_id_seq'::regclass);


--
-- Name: user_group id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_group ALTER COLUMN id SET DEFAULT nextval('public.user_group_id_seq'::regclass);


--
-- Name: user_organisation id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_organisation ALTER COLUMN id SET DEFAULT nextval('public.user_organisation_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
d5a720d1b99b
\.


--
-- Data for Name: alert_assets_association; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_assets_association (alert_id, asset_id) FROM stdin;
\.


--
-- Data for Name: alert_case_association; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_case_association (alert_id, case_id) FROM stdin;
\.


--
-- Data for Name: alert_iocs_association; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_iocs_association (alert_id, ioc_id) FROM stdin;
\.


--
-- Data for Name: alert_resolution_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_resolution_status (resolution_status_id, resolution_status_name, resolution_status_description) FROM stdin;
1	False Positive	The alert was a false positive
2	True Positive With Impact	The alert was a true positive and had an impact
3	True Positive Without Impact	The alert was a true positive but had no impact
4	Not Applicable	The alert is not applicable
5	Unknown	Unknown resolution status
6	Legitimate	The alert is acceptable and expected
\.


--
-- Data for Name: alert_similarity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_similarity (id, alert_id, similar_alert_id, similarity_type, matching_asset_id, matching_ioc_id) FROM stdin;
\.


--
-- Data for Name: alert_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_status (status_id, status_name, status_description) FROM stdin;
1	Unspecified	Unspecified
2	New	Alert is new and unassigned
3	Assigned	Alert is assigned to a user and pending investigation
4	In progress	Alert is being investigated
5	Pending	Alert is in a pending state
6	Closed	Alert closed, no action taken
7	Merged	Alert merged into an existing case
8	Escalated	Alert converted to a new case
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (alert_id, alert_uuid, alert_title, alert_description, alert_source, alert_source_ref, alert_source_link, alert_source_content, alert_severity_id, alert_status_id, alert_context, alert_source_event_time, alert_creation_time, alert_note, alert_tags, alert_owner_id, modification_history, alert_customer_id, alert_classification_id, alert_resolution_status_id) FROM stdin;
\.


--
-- Data for Name: analysis_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analysis_status (id, name) FROM stdin;
1	Unspecified
2	To be done
3	Started
4	Pending
5	Canceled
6	Done
\.


--
-- Data for Name: asset_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.asset_comments (id, comment_id, comment_asset_id) FROM stdin;
\.


--
-- Data for Name: assets_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assets_type (asset_id, asset_name, asset_description, asset_icon_not_compromised, asset_icon_compromised) FROM stdin;
1	Account	Generic Account	user.png	ioc_user.png
2	Firewall	Firewall	firewall.png	ioc_firewall.png
3	Linux - Server	Linux server	server.png	ioc_server.png
4	Linux - Computer	Linux computer	desktop.png	ioc_desktop.png
5	Linux Account	Linux Account	user.png	ioc_user.png
6	Mac - Computer	Mac computer	desktop.png	ioc_desktop.png
7	Phone - Android	Android Phone	phone.png	ioc_phone.png
8	Phone - IOS	Apple Phone	phone.png	ioc_phone.png
9	Windows - Computer	Standard Windows Computer	windows_desktop.png	ioc_windows_desktop.png
10	Windows - Server	Standard Windows Server	windows_server.png	ioc_windows_server.png
11	Windows - DC	Domain Controller	windows_server.png	ioc_windows_server.png
12	Router	Router	router.png	ioc_router.png
13	Switch	Switch	switch.png	ioc_switch.png
14	VPN	VPN	vpn.png	ioc_vpn.png
15	WAF	WAF	firewall.png	ioc_firewall.png
16	Windows Account - Local	Windows Account - Local	user.png	ioc_user.png
17	Windows Account - Local - Admin	Windows Account - Local - Admin	user.png	ioc_user.png
18	Windows Account - AD	Windows Account - AD	user.png	ioc_user.png
19	Windows Account - AD - Admin	Windows Account - AD - Admin	user.png	ioc_user.png
20	Windows Account - AD - krbtgt	Windows Account - AD - krbtgt	user.png	ioc_user.png
21	Windows Account - AD - Service	Windows Account - AD - krbtgt	user.png	ioc_user.png
\.


--
-- Data for Name: case_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_assets (asset_id, asset_uuid, asset_name, asset_description, asset_domain, asset_ip, asset_info, asset_compromise_status_id, asset_type_id, asset_tags, case_id, date_added, date_update, user_id, analysis_status_id, custom_attributes, asset_enrichment, modification_history) FROM stdin;
\.


--
-- Data for Name: case_classification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_classification (id, name, name_expanded, description, creation_date, created_by_id) FROM stdin;
1	abusive-content:spam	Abusive-Content: spam	Spam or ‘unsolicited bulk e-mail’, meaning that the recipient has not granted verifiable permission for the message to be sent and that the message is sent as part of a larger collection of messages, all having identical content.	2025-08-27 07:54:03.13346	\N
2	abusive-content:harmful-speech	Abusive-Content: Harmful Speech	Discretization or discrimination of somebody (e.g. cyber stalking, racism and threats against one or more individuals) May be found on a forum, email, tweet etc…	2025-08-27 07:54:03.142371	\N
3	abusive-content:violence	Abusive-Content: Child/Sexual/Violence/...	Any Child pornography, glorification of violence, may be found on a website, forum, email, tweet etc…	2025-08-27 07:54:03.146831	\N
4	malicious-code:virus	Malicious-Code: Virus	Malicious code that replicate itself and infects the computer and files;	2025-08-27 07:54:03.157643	\N
5	malicious-code:worm	Malicious-Code: Worm	Malware that self-replicates and spread itself to other computers in the network without any user interaction;	2025-08-27 07:54:03.162743	\N
6	malicious-code:ransomware	Malicious-Code: Ransomware	Ransomware is a type of malicious software from cryptovirology that blocks access to the victim's data or threatens to publish it until a ransom is paid.	2025-08-27 07:54:03.171581	\N
7	malicious-code:trojan-malware	Malicious-Code: Trojan/Malware	This category regroups many common malware types (Banking, POS, Mining malware).	2025-08-27 07:54:03.178885	\N
8	malicious-code:spyware-rat	Malicious-Code: Spyware/Rat	This category regroups malware types and tools that may have a bigger impact on the breached infrastructure and usually need further investigations (Common Spyware/Rat, State sponsored malwares, StealersHacking tool).	2025-08-27 07:54:03.185485	\N
9	malicious-code:dialer	Malicious-Code: Dialer	Computer program used to identify the phone numbers that can successfully make a connection with a computer modem. Use this category to classify overpriced SMS sent by malicious mobile application. 	2025-08-27 07:54:03.191059	\N
10	malicious-code:rootkit	Malicious-Code: Rootkit	Malware, which alter the standard functionality of an operating system in order to do its malicious actions in a stealthy way. In practice, Rootkits hijacks systems functions in order to alter the returning values to hide themselves from simple analysis tools.	2025-08-27 07:54:03.19566	\N
11	information-gathering:scanner	Information-Gathering: Scanning	Attacks that send requests to a system to discover weak points. This also includes some kinds of testing processes to gather information about hosts, services and accounts. Examples: fingerd, DNS querying, ICMP, SMTP (EXPN, RCPT,).	2025-08-27 07:54:03.200594	\N
12	information-gathering:sniffing	Information-Gathering: Sniffing	Observing and recording network traffic (wiretapping).	2025-08-27 07:54:03.20668	\N
13	information-gathering:social-engineering	Information-Gathering: Social Engineering	Gathering information from a human being in a non-technical way (eg, lies, tricks, bribes, or threats).	2025-08-27 07:54:03.211736	\N
14	intrusion-attempts:exploit-known-vuln	Intrusion-Attempts: Exploiting known vulnerabilities	An attempt to compromise a system or to disrupt any service by exploiting vulnerabilities with a standardised identifier such as CVE name (eg, buffer overflow, backdoors, cross side scripting, etc).	2025-08-27 07:54:03.216206	\N
15	intrusion-attempts:login-attempts	Intrusion-Attempts: Login attempts	Multiple login attempts (guessing / cracking of passwords, brute force).	2025-08-27 07:54:03.221796	\N
16	intrusion-attempts:new-attack-signature	Intrusion-Attempts: New attack signature	An attempt using an unknown exploit.	2025-08-27 07:54:03.226776	\N
17	intrusion:privileged-account-compromise	Intrusion: Privileged Account Compromise	A successful full compromise of a system or application (service). This can have been caused remotely by a known or new vulnerability, but also by an unauthorized local access.	2025-08-27 07:54:03.231795	\N
18	intrusion:unprivileged-account-compromise	Intrusion: Unprivileged Account Compromise	A successful compromise of a system or application (service). This can have been caused remotely by a known or new vulnerability, but also by an unauthorized local access. The intruded did not achieve to escale his privileges locally. 	2025-08-27 07:54:03.239607	\N
19	intrusion:botnet-member	Intrusion: Botnet member	The compromised asset is also being part of a botnet. This is reserved mainly for public web servers. See malicious code in priority for workstations or internal server’s compromise. For example, phpmailer, etc…	2025-08-27 07:54:03.244722	\N
20	intrusion:domain-compromise	Intrusion: Domain Compromise	The whole domain is compromised; this is commonly used for active directory and detected by a 'pass the ticket' attack or a discovery of 'ad dumps' files.	2025-08-27 07:54:03.249659	\N
21	intrusion:application-compromise	Intrusion: Application Compromise	An application is compromised; the attacker possess an uncontrolled access to data, server, and assets used by this application (CMDB, DB, Backend services, etc.).	2025-08-27 07:54:03.256396	\N
22	availability:dos	Availability: DoS	An attacker attempts to prevent legitimate users from accessing information or services.	2025-08-27 07:54:03.261049	\N
23	availability:ddos	Availability: DDoS	Form of electronic attack involving multiple computers, which send repeated requests (HTTP requests, pings, TCP or UDP Flood) to a server to load it down and render the service inaccessible for a period of time. 	2025-08-27 07:54:03.266647	\N
24	availability:sabotage	Availability: Sabotage	Deliberate and malicious acts that result in the disruption of the normal processes and functions or the destruction or damage of equipment or information.	2025-08-27 07:54:03.272486	\N
25	availability:outage	Availability: Outage (no malice)	Unavailability of the system but done with no malice.	2025-08-27 07:54:03.278207	\N
26	information-content-security:Unauthorised-information-access	Information-Content-Security: Unauthorised access to information	Any access to unauthorized data. It may be access of data on improperly restricted server share or database exfiltered by using a SQLi.	2025-08-27 07:54:03.282746	\N
27	information-content-security:Unauthorised-information-modification	Information-Content-Security: Unauthorised modification of information	Unauthorized tampering of data on files, documents or database.	2025-08-27 07:54:03.289695	\N
28	fraud:copyright	Fraud: Copyright	Selling or installing copies of unlicensed commercial software or other copyright protected materials (Warez).	2025-08-27 07:54:03.29454	\N
29	fraud:masquerade	Fraud: Masquerade	Types of attacks in which one entity illegitimately assumes the identity of another in order to benefit from it. This attack may be used for president fraud requesting transactions.	2025-08-27 07:54:03.298803	\N
30	fraud:phishing	Fraud: Phishing	Masquerading as another entity in order to persuade the user to reveal a private credential.	2025-08-27 07:54:03.304355	\N
31	vulnerable:vulnerable-service	Vulnerable: Open for abuse	Open resolvers, world readable printers, vulnerability apparent from Nessus etc scans, virus, signatures not up to date, etc. This includes for example default SNMP community or default password on any application.	2025-08-27 07:54:03.308402	\N
32	conformity:regulator	Conformity: Regulator	All lack about regulator rules (CSSF, GDPR, etc.).	2025-08-27 07:54:03.315812	\N
33	conformity:standard	Conformity: Standard	All lack about standards certification of the company (ISO27000, NIS, ISAE3402, etc.).	2025-08-27 07:54:03.32199	\N
34	conformity:security-policy	Conformity: Security policy	All lack about the internal security policy of the company.	2025-08-27 07:54:03.326832	\N
35	conformity:other-conformity	Conformity: Other	All lack that do not fit in one of previous categories should be put on this class.	2025-08-27 07:54:03.332005	\N
36	other:other	Other: other	All incidents that do not fit in one of the given categories should be put into this class. If the number of incidents in this category increases, it is an indicator that the classification scheme must be revised.	2025-08-27 07:54:03.341279	\N
\.


--
-- Data for Name: case_events_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_events_assets (id, event_id, asset_id, case_id) FROM stdin;
\.


--
-- Data for Name: case_events_category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_events_category (id, event_id, category_id) FROM stdin;
\.


--
-- Data for Name: case_events_ioc; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_events_ioc (id, event_id, ioc_id, case_id) FROM stdin;
\.


--
-- Data for Name: case_graph_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_graph_assets (id, case_id, asset_id, asset_type_id) FROM stdin;
\.


--
-- Data for Name: case_graph_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_graph_links (id, case_id, source_id, dest_id) FROM stdin;
\.


--
-- Data for Name: case_kanban; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_kanban (case_id, kanban_data) FROM stdin;
\.


--
-- Data for Name: case_protagonist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_protagonist (id, case_id, user_id, name, contact, role) FROM stdin;
\.


--
-- Data for Name: case_received_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_received_file (id, file_uuid, filename, date_added, acquisition_date, file_hash, file_description, file_size, start_date, end_date, case_id, user_id, type_id, custom_attributes, chain_of_custody, modification_history) FROM stdin;
\.


--
-- Data for Name: case_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_state (state_id, state_name, state_description, protected) FROM stdin;
1	Unspecified	Unspecified	t
2	In progress	Case is being investigated	f
3	Open	Case is open	t
4	Containment	Containment is in progress	f
5	Eradication	Eradication is in progress	f
6	Recovery	Recovery is in progress	f
7	Post-Incident	Post-incident phase	f
8	Reporting	Reporting is in progress	f
9	Closed	Case is closed	t
\.


--
-- Data for Name: case_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_tags (case_id, tag_id) FROM stdin;
\.


--
-- Data for Name: case_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_tasks (id, task_uuid, task_title, task_description, task_tags, task_open_date, task_close_date, task_last_update, task_userid_open, task_userid_close, task_userid_update, task_status_id, task_case_id, custom_attributes, modification_history) FROM stdin;
\.


--
-- Data for Name: case_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_template (id, created_by_user_id, created_at, updated_at, name, display_name, description, author, title_prefix, summary, tags, tasks, note_directories, classification) FROM stdin;
\.


--
-- Data for Name: case_template_report; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_template_report (id, name, description, internal_reference, naming_format, created_by_user_id, date_created, language_id, report_type_id) FROM stdin;
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cases (case_id, soc_id, client_id, name, description, open_date, close_date, initial_date, closing_note, user_id, owner_id, status_id, state_id, custom_attributes, case_uuid, classification_id, reviewer_id, review_status_id, severity_id, modification_history) FROM stdin;
1	soc_id_demo	1	#1 - Initial Demo	This is a demonstration.	2025-08-27	\N	2025-08-27 07:54:06.675249	\N	1	1	0	\N	null	789f7ed0-0dea-490f-bad9-bf299e3ba855	\N	\N	\N	\N	\N
4	SOC_4	2	#4 - Three failed attempts to run sudo	Rule ID: 5404<br>Rule Level: 10<br>Rule Description: Three failed attempts to run sudo<br>Agent ID: 001<br>Agent Name: VALORH2-M-Daniel<br>MITRE IDs: T1548.003<br>MITRE Tactics: Privilege Escalation, Defense Evasion<br>MITRE Techniques: Sudo and Sudo Caching<br>Location: N/A<br>Full_log: <br>2025-08-28T14:17:38.740934+02:00 Daniel sudo:      dmc : 3 incorrect password attempts ; TTY=pts/7 ; PWD=/mnt/c/Users/danie ; USER=root ; COMMAND=/usr/bin/su<br>------------------------<br>Analysis IoCs: <br>[<br>  {<br>    ioc_value: 127.0.0.1,<br>    category: Network activity,<br>    comment: we can tell that an exploited device will have a local root service listening on 127.0.0.1:500 that the malware will “ping” for / On port 500,<br>    event_id: 310,<br>    value: 127.0.0.1|500,<br>    event_info: Lookout Uncovers Android Spyware Deployed in Kazakhstan,<br>    event_uuid: 2e1474e1-1a53-4124-966f-b3bbface35df,<br>    event_org_id: 1,<br>    event_orgc_id: 2,<br>    event_publish_timestamp: 1756193104<br>  },<br>  {<br>    ioc_value: 127.0.0.1,<br>    category: Network activity,<br>    comment: RFC1918 addresses listed in the file. There is also a strange looking ip: 111.111.111.111,<br>    event_id: 1439,<br>    value: 127.0.0.1,<br>    event_info: OSINT - Operation SMN (Novetta),<br>    event_uuid: 544f8aa7-9224-46ad-a73f-30f9950d210b,<br>    event_org_id: 1,<br>    event_orgc_id: 4,<br>    event_publish_timestamp: 1756194346<br>  }<br>]<br>	2025-08-28	\N	2025-08-28 13:03:55.624609	\N	4	4	0	3	null	ed1f26ae-0bc2-4114-9b79-04d4afe7bfa5	\N	\N	\N	5	{"1756386235.687539": {"user": "apishuffle", "user_id": 2, "action": "created"}, "1756386240.914442": {"user": "apishuffle", "user_id": 2, "action": "case info updated"}}
2	SOC	2	#2 - Three failed attempts to run sudo	Rule ID: 5404<br>Rule Level: 10<br>Rule Description: Three failed attempts to run sudo<br>Agent ID: 001<br>Agent Name: VALORH2-M-Daniel<br>MITRE IDs: T1548.003<br>MITRE Tactics: Privilege Escalation, Defense Evasion<br>MITRE Techniques: Sudo and Sudo Caching<br>Location: N/A<br>Full_log: <br>2025-08-28T14:17:38.740934+02:00 Daniel sudo:      dmc : 3 incorrect password attempts ; TTY=pts/7 ; PWD=/mnt/c/Users/danie ; USER=root ; COMMAND=/usr/bin/su<br>------------------------<br>Analysis IoCs: <br>[<br>  {<br>    ioc_value: 127.0.0.1,<br>    category: Network activity,<br>    comment: we can tell that an exploited device will have a local root service listening on 127.0.0.1:500 that the malware will “ping” for / On port 500,<br>    event_id: 310,<br>    value: 127.0.0.1|500,<br>    event_info: Lookout Uncovers Android Spyware Deployed in Kazakhstan,<br>    event_uuid: 2e1474e1-1a53-4124-966f-b3bbface35df,<br>    event_org_id: 1,<br>    event_orgc_id: 2,<br>    event_publish_timestamp: 1756193104<br>  },<br>  {<br>    ioc_value: 127.0.0.1,<br>    category: Network activity,<br>    comment: RFC1918 addresses listed in the file. There is also a strange looking ip: 111.111.111.111,<br>    event_id: 1439,<br>    value: 127.0.0.1,<br>    event_info: OSINT - Operation SMN (Novetta),<br>    event_uuid: 544f8aa7-9224-46ad-a73f-30f9950d210b,<br>    event_org_id: 1,<br>    event_orgc_id: 4,<br>    event_publish_timestamp: 1756194346<br>  }<br>]<br>	2025-08-28	\N	2025-08-28 12:49:34.122841	\N	2	2	0	3	null	ff096c2e-b902-4574-9079-0846208ab24a	\N	\N	\N	4	{"1756385374.225739": {"user": "apishuffle", "user_id": 2, "action": "created"}}
3	SOC_3	2	#3 - Three failed attempts to run sudo	Rule ID: 5404<br>Rule Level: 10<br>Rule Description: Three failed attempts to run sudo<br>Agent ID: 001<br>Agent Name: VALORH2-M-Daniel<br>MITRE IDs: T1548.003<br>MITRE Tactics: Privilege Escalation, Defense Evasion<br>MITRE Techniques: Sudo and Sudo Caching<br>Location: N/A<br>Full_log: <br>2025-08-28T14:17:38.740934+02:00 Daniel sudo:      dmc : 3 incorrect password attempts ; TTY=pts/7 ; PWD=/mnt/c/Users/danie ; USER=root ; COMMAND=/usr/bin/su<br>------------------------<br>Analysis IoCs: <br>[<br>  {<br>    ioc_value: 127.0.0.1,<br>    category: Network activity,<br>    comment: we can tell that an exploited device will have a local root service listening on 127.0.0.1:500 that the malware will “ping” for / On port 500,<br>    event_id: 310,<br>    value: 127.0.0.1|500,<br>    event_info: Lookout Uncovers Android Spyware Deployed in Kazakhstan,<br>    event_uuid: 2e1474e1-1a53-4124-966f-b3bbface35df,<br>    event_org_id: 1,<br>    event_orgc_id: 2,<br>    event_publish_timestamp: 1756193104<br>  },<br>  {<br>    ioc_value: 127.0.0.1,<br>    category: Network activity,<br>    comment: RFC1918 addresses listed in the file. There is also a strange looking ip: 111.111.111.111,<br>    event_id: 1439,<br>    value: 127.0.0.1,<br>    event_info: OSINT - Operation SMN (Novetta),<br>    event_uuid: 544f8aa7-9224-46ad-a73f-30f9950d210b,<br>    event_org_id: 1,<br>    event_orgc_id: 4,<br>    event_publish_timestamp: 1756194346<br>  }<br>]<br>	2025-08-28	\N	2025-08-28 12:54:07.154598	\N	3	3	0	3	null	6ebcf949-84e9-4d44-b68c-85a91bb78693	\N	\N	\N	5	{"1756385647.213686": {"user": "apishuffle", "user_id": 2, "action": "created"}, "1756385652.484819": {"user": "apishuffle", "user_id": 2, "action": "case info updated"}}
\.


--
-- Data for Name: cases_assets_ext; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cases_assets_ext (asset_id, type_id, case_id, asset_content) FROM stdin;
\.


--
-- Data for Name: cases_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cases_events (event_id, parent_event_id, event_uuid, case_id, event_title, event_source, event_content, event_raw, event_date, event_added, event_in_graph, event_in_summary, user_id, modification_history, event_color, event_tags, event_tz, event_date_wtz, event_is_flagged, custom_attributes) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client (client_id, client_uuid, name, description, sla, creation_date, created_by, last_update_date, custom_attributes) FROM stdin;
1	e91148f5-adc9-46f8-964f-32279e184fa5	IrisInitialClient	\N	\N	2025-08-27 07:54:06.64253	\N	2025-08-27 07:54:06.64253	\N
2	375c3d9f-1f06-4742-a5e1-e17991d416f5	VALORH2			2025-08-28 11:56:17.165353	\N	2025-08-28 11:56:17.165353	{}
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comments (comment_id, comment_uuid, comment_text, comment_date, comment_update_date, comment_user_id, comment_case_id, comment_alert_id) FROM stdin;
\.


--
-- Data for Name: contact; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contact (id, contact_uuid, contact_name, contact_email, contact_role, contact_note, contact_work_phone, contact_mobile_phone, custom_attributes, client_id) FROM stdin;
\.


--
-- Data for Name: custom_attribute; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_attribute (attribute_id, attribute_display_name, attribute_description, attribute_for, attribute_content) FROM stdin;
1	IOC	Defines default attributes for IOCs	ioc	{}
2	Events	Defines default attributes for Events	event	{}
3	Assets	Defines default attributes for Assets	asset	{}
4	Tasks	Defines default attributes for Tasks	task	{}
5	Notes	Defines default attributes for Notes	note	{}
6	Evidences	Defines default attributes for Evidences	evidence	{}
7	Cases	Defines default attributes for Cases	case	{}
8	Customers	Defines default attributes for Customers	client	{}
\.


--
-- Data for Name: data_store_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_store_file (file_id, file_uuid, file_original_name, file_local_name, file_description, file_date_added, file_tags, file_size, file_is_ioc, file_is_evidence, file_password, file_parent_id, file_sha256, added_by_user_id, modification_history, file_case_id) FROM stdin;
\.


--
-- Data for Name: data_store_path; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_store_path (path_id, path_uuid, path_name, path_parent_id, path_is_root, path_case_id) FROM stdin;
1	bd5a4ea0-1fbc-46fe-bde7-79055e4f21f6	Case 1	0	t	1
2	2b53ad3d-bf16-42bc-b717-7cd68babe0cc	Evidences	1	f	1
3	5f6e6cf7-1d93-43f6-9ea8-852f804bd33f	IOCs	1	f	1
4	2186b450-b907-444f-aa0f-ffaad456f400	Images	1	f	1
\.


--
-- Data for Name: event_category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_category (id, name) FROM stdin;
1	Unspecified
2	Legitimate
3	Remediation
4	Initial Access
5	Execution
6	Persistence
7	Privilege Escalation
8	Defense Evasion
9	Credential Access
10	Discovery
11	Lateral Movement
12	Collection
13	Command and Control
14	Exfiltration
15	Impact
\.


--
-- Data for Name: event_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_comments (id, comment_id, comment_event_id) FROM stdin;
\.


--
-- Data for Name: evidence_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evidence_comments (id, comment_id, comment_evidence_id) FROM stdin;
\.


--
-- Data for Name: evidence_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evidence_type (id, name, description, creation_date, created_by_id) FROM stdin;
1	Unspecified	Unspecified	2025-08-27 07:54:03.465127	\N
2	HDD image - Generic	Generic copy of an hard drive	2025-08-27 07:54:03.471315	\N
3	HDD image - DD - Other	DD copy of an hard drive	2025-08-27 07:54:03.476728	\N
4	HDD image - DD - Windows	DD copy of an hard drive	2025-08-27 07:54:03.481271	\N
5	HDD image - DD - Unix	DD copy of an hard drive	2025-08-27 07:54:03.488166	\N
6	HDD image - DD - MacOS	DD copy of an hard drive	2025-08-27 07:54:03.493776	\N
7	HDD image - E01 - Other	E01 acquisition of an hard drive	2025-08-27 07:54:03.500066	\N
8	HDD image - E01 - Windows	E01 acquisition of an hard drive	2025-08-27 07:54:03.526103	\N
9	HDD image - E01 - Unix	E01 acquisition of an hard drive	2025-08-27 07:54:03.543887	\N
10	HDD image - E01 - MacOS	E01 acquisition of an hard drive	2025-08-27 07:54:03.552087	\N
11	HDD image - AFF4 - Other	AFF4 acquisition of an hard drive	2025-08-27 07:54:03.558839	\N
12	HDD image - AFF4 - Windows	AFF4 acquisition of an hard drive	2025-08-27 07:54:03.562913	\N
13	HDD image - AFF4 - Unix	AFF4 acquisition of an hard drive	2025-08-27 07:54:03.567736	\N
14	HDD image - AFF4 - MacOS	AFF4 acquisition of an hard drive	2025-08-27 07:54:03.574935	\N
15	SSD image - Generic	Generic copy of an solid state drive	2025-08-27 07:54:03.580699	\N
16	SSD image - DD - Other	DD copy of an solid state drive	2025-08-27 07:54:03.587517	\N
17	SSD image - DD - Windows	DD copy of an solid state drive	2025-08-27 07:54:03.594388	\N
18	SSD image - DD - Unix	DD copy of an solid state drive	2025-08-27 07:54:03.603295	\N
19	SSD image - DD - MacOS	DD copy of an solid state drive	2025-08-27 07:54:03.625507	\N
20	SSD image - E01 - Other	EO1 copy of a solid state drive	2025-08-27 07:54:03.644486	\N
21	SSD image - E01 - Windows	EO1 copy of a solid state drive	2025-08-27 07:54:03.664642	\N
22	SSD image - E01 - Unix	EO1 copy of a solid state drive	2025-08-27 07:54:03.673619	\N
23	SSD image - E01 - MacOS	EO1 copy of MacOS on a solid state drive	2025-08-27 07:54:03.680751	\N
24	SSD image - AFF4 - Other	AFF4 copy of an solid state drive	2025-08-27 07:54:03.690289	\N
25	SSD image - AFF4 - Windows	AFF4 copy of an solid state drive	2025-08-27 07:54:03.697725	\N
26	SSD image - AFF4 - Unix	AFF4 copy of an solid state drive	2025-08-27 07:54:03.706756	\N
27	SSD image - AFF4 - MacOS	AFF4 copy of an solid state drive	2025-08-27 07:54:03.712292	\N
28	VM image - Generic	Generic copy of a VM 	2025-08-27 07:54:03.721944	\N
29	VM image - Linux Server	Copy of a Linux Server VM	2025-08-27 07:54:03.728446	\N
30	VM image - Windows Server	Copy of a Windows Server VM	2025-08-27 07:54:03.741934	\N
31	Phone Image - Android	Copy of an Android phone	2025-08-27 07:54:03.747072	\N
32	Phone Image - iPhone	Copy of an iPhone	2025-08-27 07:54:03.756315	\N
33	Phone backup - Android (adb)	adb backup of an Android	2025-08-27 07:54:03.761088	\N
34	Phone backup - iPhone (iTunes)	iTunes backup of an iPhone	2025-08-27 07:54:03.76539	\N
35	Tablet Image - Android	Copy of an Android tablet	2025-08-27 07:54:03.772778	\N
36	Tablet Image - iPad	Copy of an iPad tablet	2025-08-27 07:54:03.777951	\N
37	Tablet backup - Android (adb)	adb backup of an Android tablet	2025-08-27 07:54:03.783099	\N
38	Tablet backup - iPad (iTunes)	iTunes backup of an iPad	2025-08-27 07:54:03.793665	\N
39	Collection - Velociraptor	Velociraptor collection	2025-08-27 07:54:03.812048	\N
40	Collection - ORC	ORC collection	2025-08-27 07:54:03.817152	\N
41	Collection - KAPE	KAPE collection	2025-08-27 07:54:03.846726	\N
42	Memory acquisition - Physical RAM	Physical RAM acquisition	2025-08-27 07:54:03.852005	\N
43	Memory acquisition - VMEM	vmem file	2025-08-27 07:54:03.858613	\N
44	Logs - Linux	Standard Linux logs	2025-08-27 07:54:03.878088	\N
45	Logs - Windows EVTX	Standard Windows EVTX logs	2025-08-27 07:54:03.886908	\N
46	Logs - Windows EVT	Standard Windows EVT logs	2025-08-27 07:54:03.892017	\N
47	Logs - MacOS	Standard MacOS logs	2025-08-27 07:54:03.898453	\N
48	Logs - Generic	Generic logs	2025-08-27 07:54:03.908146	\N
49	Logs - Firewall	Firewall logs	2025-08-27 07:54:03.913745	\N
50	Logs - Proxy	Proxy logs	2025-08-27 07:54:03.918692	\N
51	Logs - DNS	DNS logs	2025-08-27 07:54:03.924451	\N
52	Logs - Email	Email logs	2025-08-27 07:54:03.941724	\N
53	Executable - Windows (PE)	Generic Windows executable	2025-08-27 07:54:03.946263	\N
54	Executable - Linux (ELF)	Generic Linux executable	2025-08-27 07:54:03.95355	\N
55	Executable - MacOS (Mach-O)	Generic MacOS executable	2025-08-27 07:54:03.959524	\N
56	Executable - Generic	Generic executable	2025-08-27 07:54:03.964377	\N
57	Script - Generic	Generic script	2025-08-27 07:54:03.973721	\N
58	Generic - Data blob	Generic blob of data	2025-08-27 07:54:03.981016	\N
\.


--
-- Data for Name: global_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.global_tasks (id, task_uuid, task_title, task_description, task_tags, task_open_date, task_close_date, task_last_update, task_userid_open, task_userid_close, task_userid_update, task_assignee_id, task_status_id) FROM stdin;
\.


--
-- Data for Name: group_case_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_case_access (id, group_id, case_id, access_level) FROM stdin;
49	1	1	4
50	2	1	4
51	1	2	4
52	1	3	4
53	1	4	4
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (group_id, group_uuid, group_name, group_description, group_permissions, group_auto_follow, group_auto_follow_access_level) FROM stdin;
1	d2d240ad-a27b-427b-ae10-ee69b8e6fe6a	Administrators	Administrators	4095	t	4
2	fb7f379a-2880-47ec-afd5-6263ae1025e6	Analysts	Standard Analysts	1133	f	4
\.


--
-- Data for Name: ioc; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ioc (ioc_id, ioc_uuid, ioc_value, ioc_type_id, ioc_description, ioc_tags, user_id, ioc_misp, ioc_tlp_id, custom_attributes, ioc_enrichment, modification_history) FROM stdin;
1	6df8d4f4-efc3-49d5-9125-9a59d896e793	1756383459.2586015	96	Extracted from Wazuh alert (type: Linux syslog)	data-id	2	\N	2	\N	\N	\N
2	4f018fbc-24e2-4bdf-8b90-4b33b0ac8ecd	/var/log/auth.log	97	Extracted from Wazuh alert (type: Linux syslog)	path	2	\N	2	\N	\N	\N
3	44d8ed28-3fae-4735-b539-9512b46993aa	127.0.0.1	79	Extracted from Wazuh alert (type: Linux syslog)	ip-agent	2	\N	2	\N	\N	\N
4	3ef3bad0-923f-4b99-93c8-9496c99fcb52	sudo	96	Extracted from Wazuh alert (type: Linux syslog)	process-name	2	\N	2	\N	\N	\N
5	2546ce4f-1a88-4bf1-8b3b-2c2c6479848a	root	133	Extracted from Wazuh alert (type: Linux syslog)	target-user	2	\N	2	\N	\N	\N
\.


--
-- Data for Name: ioc_asset_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ioc_asset_link (ioc_asset_link_id, ioc_id, asset_id) FROM stdin;
\.


--
-- Data for Name: ioc_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ioc_comments (id, comment_id, comment_ioc_id) FROM stdin;
\.


--
-- Data for Name: ioc_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ioc_link (ioc_link_id, ioc_id, case_id) FROM stdin;
1	1	4
2	2	4
3	3	4
4	4	4
5	5	4
\.


--
-- Data for Name: ioc_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ioc_type (type_id, type_name, type_description, type_taxonomy, type_validation_regex, type_validation_expect) FROM stdin;
1	AS	Autonomous system	\N	\N	\N
2	aba-rtn	ABA routing transit number	\N	\N	\N
3	account	Account of any type	\N	\N	\N
4	anonymised	Anonymised value - described with the anonymisation object via a relationship	\N	\N	\N
5	attachment	Attachment with external information	\N	\N	\N
6	authentihash	Authenticode executable signature hash	\N	\N	\N
7	boolean	Boolean value - to be used in objects	\N	\N	\N
8	btc	Bitcoin Address	\N	\N	\N
9	campaign-id	Associated campaign ID	\N	\N	\N
10	campaign-name	Associated campaign name	\N	\N	\N
11	cdhash	An Apple Code Directory Hash, identifying a code-signed Mach-O executable file	\N	\N	\N
12	chrome-extension-id	Chrome extension id	\N	\N	\N
13	community-id	a community ID flow hashing algorithm to map multiple traffic monitors into common flow id	\N	\N	\N
14	cookie	HTTP cookie as often stored on the user web client. This can include authentication cookie or session cookie.	\N	\N	\N
15	dash	Dash Address	\N	\N	\N
16	datetime	Datetime in the ISO 8601 format	\N	\N	\N
17	dkim	DKIM public key	\N	\N	\N
18	dkim-signature	DKIM signature	\N	\N	\N
19	dns-soa-email	RFC1035 mandates that DNS zones should have a SOA (Statement Of Authority) record that contains an email address where a PoC for the domain could be contacted. This can sometimes be used for attribution/linkage between different domains even if protected by whois privacy	\N	\N	\N
20	domain	A domain name used in the malware	\N	\N	\N
21	domain|ip	A domain name and its IP address (as found in DNS lookup) separated by a |	\N	\N	\N
22	email	An e-mail address	\N	\N	\N
23	email-attachment	File name of the email attachment.	\N	\N	\N
24	email-body	Email body	\N	\N	\N
25	email-dst	The destination email address. Used to describe the recipient when describing an e-mail.	\N	\N	\N
26	email-dst-display-name	Email destination display name	\N	\N	\N
27	email-header	Email header	\N	\N	\N
28	email-message-id	The email message ID	\N	\N	\N
29	email-mime-boundary	The email mime boundary separating parts in a multipart email	\N	\N	\N
30	email-reply-to	Email reply to header	\N	\N	\N
31	email-src	The source email address. Used to describe the sender when describing an e-mail.	\N	\N	\N
32	email-src-display-name	Email source display name	\N	\N	\N
33	email-subject	The subject of the email	\N	\N	\N
34	email-thread-index	The email thread index header	\N	\N	\N
35	email-x-mailer	Email x-mailer header	\N	\N	\N
36	favicon-mmh3	favicon-mmh3 is the murmur3 hash of a favicon as used in Shodan.	\N	\N	\N
37	filename	Filename	\N	\N	\N
38	filename-pattern	A pattern in the name of a file	\N	\N	\N
39	filename|authentihash	A checksum in md5 format	\N	\N	\N
40	filename|impfuzzy	Import fuzzy hash - a fuzzy hash created based on the imports in the sample.	\N	\N	\N
41	filename|imphash	Import hash - a hash created based on the imports in the sample.	\N	\N	\N
42	filename|md5	A filename and an md5 hash separated by a |	\N	\N	\N
43	filename|pehash	A filename and a PEhash separated by a |	\N	\N	\N
44	filename|sha1	A filename and an sha1 hash separated by a |	\N	\N	\N
45	filename|sha224	A filename and a sha-224 hash separated by a |	\N	\N	\N
46	filename|sha256	A filename and an sha256 hash separated by a |	\N	\N	\N
47	filename|sha3-224	A filename and an sha3-224 hash separated by a |	\N	\N	\N
48	filename|sha3-256	A filename and an sha3-256 hash separated by a |	\N	\N	\N
49	filename|sha3-384	A filename and an sha3-384 hash separated by a |	\N	\N	\N
50	filename|sha3-512	A filename and an sha3-512 hash separated by a |	\N	\N	\N
51	filename|sha384	A filename and a sha-384 hash separated by a |	\N	\N	\N
52	filename|sha512	A filename and a sha-512 hash separated by a |	\N	\N	\N
53	filename|sha512/224	A filename and a sha-512/224 hash separated by a |	\N	\N	\N
54	filename|sha512/256	A filename and a sha-512/256 hash separated by a |	\N	\N	\N
55	filename|ssdeep	A checksum in ssdeep format	\N	\N	\N
56	filename|tlsh	A filename and a Trend Micro Locality Sensitive Hash separated by a |	\N	\N	\N
57	filename|vhash	A filename and a VirusTotal hash separated by a |	\N	\N	\N
58	first-name	First name of a natural person	\N	\N	\N
59	float	A floating point value.	\N	\N	\N
60	full-name	Full name of a natural person	\N	\N	\N
61	gene	GENE - Go Evtx sigNature Engine	\N	\N	\N
62	git-commit-id	A git commit ID.	\N	\N	\N
63	github-organisation	A github organisation	\N	\N	\N
64	github-repository	A github repository	\N	\N	\N
65	github-username	A github user name	\N	\N	\N
66	hassh-md5	hassh is a network fingerprinting standard which can be used to identify specific Client SSH implementations. The fingerprints can be easily stored, searched and shared in the form of an MD5 fingerprint.	\N	\N	\N
67	hasshserver-md5	hasshServer is a network fingerprinting standard which can be used to identify specific Server SSH implementations. The fingerprints can be easily stored, searched and shared in the form of an MD5 fingerprint.	\N	\N	\N
68	hex	A value in hexadecimal format	\N	\N	\N
69	hostname	A full host/dnsname of an attacker	\N	\N	\N
70	hostname|port	Hostname and port number separated by a |	\N	\N	\N
71	http-method	HTTP method used by the malware (e.g. POST, GET, …).	\N	\N	\N
72	iban	International Bank Account Number	\N	\N	\N
73	identity-card-number	Identity card number	\N	\N	\N
74	impfuzzy	A fuzzy hash of import table of Portable Executable format	\N	\N	\N
75	imphash	Import hash - a hash created based on the imports in the sample.	\N	\N	\N
76	ip-any	A source or destination IP address of the attacker or C&C server	\N	\N	\N
77	ip-dst	A destination IP address of the attacker or C&C server	\N	\N	\N
78	ip-dst|port	IP destination and port number separated by a |	\N	\N	\N
79	ip-src	A source IP address of the attacker	\N	\N	\N
80	ip-src|port	IP source and port number separated by a |	\N	\N	\N
81	ja3-fingerprint-md5	JA3 is a method for creating SSL/TLS client fingerprints that should be easy to produce on any platform and can be easily shared for threat intelligence.	\N	\N	\N
82	jabber-id	Jabber ID	\N	\N	\N
83	jarm-fingerprint	JARM is a method for creating SSL/TLS server fingerprints.	\N	\N	\N
84	kusto-query	Kusto query - Kusto from Microsoft Azure is a service for storing and running interactive analytics over Big Data.	\N	\N	\N
85	link	Link to an external information	\N	\N	\N
86	mac-address	Mac address	\N	\N	\N
87	mac-eui-64	Mac EUI-64 address	\N	\N	\N
88	malware-sample	Attachment containing encrypted malware sample	\N	\N	\N
89	malware-type	Malware type	\N	\N	\N
90	md5	A checksum in md5 format	\N	\N	\N
91	middle-name	Middle name of a natural person	\N	\N	\N
92	mime-type	A media type (also MIME type and content type) is a two-part identifier for file formats and format contents transmitted on the Internet	\N	\N	\N
93	mobile-application-id	The application id of a mobile application	\N	\N	\N
94	mutex	Mutex, use the format \\BaseNamedObjects<Mutex>	\N	\N	\N
95	named pipe	Named pipe, use the format .\\pipe<PipeName>	\N	\N	\N
96	other	Other attribute	\N	\N	\N
97	file-path	Path of file	\N	\N	\N
98	pattern-in-file	Pattern in file that identifies the malware	\N	\N	\N
99	pattern-in-memory	Pattern in memory dump that identifies the malware	\N	\N	\N
100	pattern-in-traffic	Pattern in network traffic that identifies the malware	\N	\N	\N
101	pdb	Microsoft Program database (PDB) path information	\N	\N	\N
102	pehash	PEhash - a hash calculated based of certain pieces of a PE executable file	\N	\N	\N
103	pgp-private-key	A PGP private key	\N	\N	\N
104	pgp-public-key	A PGP public key	\N	\N	\N
105	phone-number	Telephone Number	\N	\N	\N
106	port	Port number	\N	\N	\N
107	process-state	State of a process	\N	\N	\N
108	prtn	Premium-Rate Telephone Number	\N	\N	\N
109	regkey	Registry key or value	\N	\N	\N
110	regkey|value	Registry value + data separated by |	\N	\N	\N
111	sha1	A checksum in sha1 format	\N	\N	\N
112	sha224	A checksum in sha-224 format	\N	\N	\N
113	sha256	A checksum in sha256 format	\N	\N	\N
114	sha3-224	A checksum in sha3-224 format	\N	\N	\N
115	sha3-256	A checksum in sha3-256 format	\N	\N	\N
116	sha3-384	A checksum in sha3-384 format	\N	\N	\N
117	sha3-512	A checksum in sha3-512 format	\N	\N	\N
118	sha384	A checksum in sha-384 format	\N	\N	\N
119	sha512	A checksum in sha-512 format	\N	\N	\N
120	sha512/224	A checksum in the sha-512/224 format	\N	\N	\N
121	sha512/256	A checksum in the sha-512/256 format	\N	\N	\N
122	sigma	Sigma - Generic Signature Format for SIEM Systems	\N	\N	\N
123	size-in-bytes	Size expressed in bytes	\N	\N	\N
124	snort	An IDS rule in Snort rule-format	\N	\N	\N
125	ssdeep	A checksum in ssdeep format	\N	\N	\N
126	ssh-fingerprint	A fingerprint of SSH key material	\N	\N	\N
127	stix2-pattern	STIX 2 pattern	\N	\N	\N
128	target-email	Attack Targets Email(s)	\N	\N	\N
129	target-external	External Target Organizations Affected by this Attack	\N	\N	\N
130	target-location	Attack Targets Physical Location(s)	\N	\N	\N
131	target-machine	Attack Targets Machine Name(s)	\N	\N	\N
132	target-org	Attack Targets Department or Organization(s)	\N	\N	\N
133	target-user	Attack Targets Username(s)	\N	\N	\N
134	telfhash	telfhash is symbol hash for ELF files, just like imphash is imports hash for PE files.	\N	\N	\N
135	text	Name, ID or a reference	\N	\N	\N
136	threat-actor	A string identifying the threat actor	\N	\N	\N
137	tlsh	A checksum in the Trend Micro Locality Sensitive Hash format	\N	\N	\N
138	travel-details	Travel details	\N	\N	\N
139	twitter-id	Twitter ID	\N	\N	\N
140	uri	Uniform Resource Identifier	\N	\N	\N
141	url	url	\N	\N	\N
142	user-agent	The user-agent used by the malware in the HTTP request.	\N	\N	\N
143	vhash	A VirusTotal checksum	\N	\N	\N
144	vulnerability	A reference to the vulnerability used in the exploit	\N	\N	\N
145	weakness	A reference to the weakness used in the exploit	\N	\N	\N
146	whois-creation-date	The date of domain’s creation, obtained from the WHOIS information.	\N	\N	\N
147	whois-registrant-email	The e-mail of a domain’s registrant, obtained from the WHOIS information.	\N	\N	\N
148	whois-registrant-name	The name of a domain’s registrant, obtained from the WHOIS information.	\N	\N	\N
149	whois-registrant-org	The org of a domain’s registrant, obtained from the WHOIS information.	\N	\N	\N
150	whois-registrant-phone	The phone number of a domain’s registrant, obtained from the WHOIS information.	\N	\N	\N
151	whois-registrar	The registrar of the domain, obtained from the WHOIS information.	\N	\N	\N
152	windows-scheduled-task	A scheduled task in windows	\N	\N	\N
153	windows-service-displayname	A windows service’s displayname, not to be confused with the windows-service-name. This is the name that applications will generally display as the service’s name in applications.	\N	\N	\N
154	windows-service-name	A windows service name. This is the name used internally by windows. Not to be confused with the windows-service-displayname.	\N	\N	\N
155	x509-fingerprint-md5	X509 fingerprint in MD5 format	\N	\N	\N
156	x509-fingerprint-sha1	X509 fingerprint in SHA-1 format	\N	\N	\N
157	x509-fingerprint-sha256	X509 fingerprint in SHA-256 format	\N	\N	\N
158	xmr	Monero Address	\N	\N	\N
159	yara	Yara signature	\N	\N	\N
160	zeek	An NIDS rule in the Zeek rule-format	\N	\N	\N
\.


--
-- Data for Name: iris_hooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.iris_hooks (id, hook_name, hook_description) FROM stdin;
1	on_postload_alert_create	Triggered on alert creation, after commit in DB
2	on_postload_alert_delete	Triggered on alert deletion, after commit in DB
3	on_postload_alert_update	Triggered on alert update, after commit in DB
4	on_postload_alert_resolution_update	Triggered on alert resolution update, after commit in DB
5	on_postload_alert_status_update	Triggered on alert status update, after commit in DB
6	on_postload_alert_escalate	Triggered on alert escalation, after commit in DB
7	on_postload_alert_merge	Triggered on alert merge, after commit in DB
8	on_postload_alert_unmerge	Triggered on alert unmerge, after commit in DB
9	on_manual_trigger_alert	Triggered upon user action
10	on_preload_case_create	Triggered on case creation, before commit in DB
11	on_postload_case_create	Triggered on case creation, after commit in DB
12	on_preload_case_delete	Triggered on case deletion, before commit in DB
13	on_postload_case_delete	Triggered on case deletion, after commit in DB
14	on_postload_case_update	Triggered on case update, after commit in DB
15	on_manual_trigger_case	Triggered upon user action
16	on_preload_asset_create	Triggered on asset creation, before commit in DB
17	on_postload_asset_create	Triggered on asset creation, after commit in DB
18	on_preload_asset_update	Triggered on asset update, before commit in DB
19	on_postload_asset_update	Triggered on asset update, after commit in DB
20	on_preload_asset_delete	Triggered on asset deletion, before commit in DB
21	on_postload_asset_delete	Triggered on asset deletion, after commit in DB
22	on_manual_trigger_asset	Triggered upon user action
23	on_preload_note_create	Triggered on note creation, before commit in DB
24	on_postload_note_create	Triggered on note creation, after commit in DB
25	on_preload_note_update	Triggered on note update, before commit in DB
26	on_postload_note_update	Triggered on note update, after commit in DB
27	on_preload_note_delete	Triggered on note deletion, before commit in DB
28	on_postload_note_delete	Triggered on note deletion, after commit in DB
29	on_manual_trigger_note	Triggered upon user action
30	on_preload_ioc_create	Triggered on ioc creation, before commit in DB
31	on_postload_ioc_create	Triggered on ioc creation, after commit in DB
32	on_preload_ioc_update	Triggered on ioc update, before commit in DB
33	on_postload_ioc_update	Triggered on ioc update, after commit in DB
34	on_preload_ioc_delete	Triggered on ioc deletion, before commit in DB
35	on_postload_ioc_delete	Triggered on ioc deletion, after commit in DB
36	on_manual_trigger_ioc	Triggered upon user action
37	on_preload_event_create	Triggered on event creation, before commit in DB
38	on_postload_event_create	Triggered on event creation, after commit in DB
39	on_preload_event_duplicate	Triggered on event duplication, before commit in DB
40	on_preload_event_update	Triggered on event update, before commit in DB
41	on_postload_event_update	Triggered on event update, after commit in DB
42	on_preload_event_delete	Triggered on event deletion, before commit in DB
43	on_postload_event_delete	Triggered on event deletion, after commit in DB
44	on_manual_trigger_event	Triggered upon user action
45	on_preload_evidence_create	Triggered on evidence creation, before commit in DB
46	on_postload_evidence_create	Triggered on evidence creation, after commit in DB
47	on_preload_evidence_update	Triggered on evidence update, before commit in DB
48	on_postload_evidence_update	Triggered on evidence update, after commit in DB
49	on_preload_evidence_delete	Triggered on evidence deletion, before commit in DB
50	on_postload_evidence_delete	Triggered on evidence deletion, after commit in DB
51	on_manual_trigger_evidence	Triggered upon user action
52	on_preload_task_create	Triggered on task creation, before commit in DB
53	on_postload_task_create	Triggered on task creation, after commit in DB
54	on_preload_task_update	Triggered on task update, before commit in DB
55	on_postload_task_update	Triggered on task update, after commit in DB
56	on_preload_task_delete	Triggered on task deletion, before commit in DB
57	on_postload_task_delete	Triggered on task deletion, after commit in DB
58	on_manual_trigger_task	Triggered upon user action
59	on_preload_global_task_create	Triggered on global task creation, before commit in DB
60	on_postload_global_task_create	Triggered on global task creation, after commit in DB
61	on_preload_global_task_update	Triggered on task update, before commit in DB
62	on_postload_global_task_update	Triggered on global task update, after commit in DB
63	on_preload_global_task_delete	Triggered on task deletion, before commit in DB
64	on_postload_global_task_delete	Triggered on global task deletion, after commit in DB
65	on_manual_trigger_global_task	Triggered upon user action
66	on_preload_report_create	Triggered on report creation, before generation in DB
67	on_postload_report_create	Triggered on report creation, before download of the document
68	on_preload_activities_report_create	Triggered on activities report creation, before generation in DB
69	on_postload_activities_report_create	Triggered on activities report creation, before download of the document
70	on_postload_asset_commented	Triggered on event commented, after commit in DB
71	on_postload_asset_comment_update	Triggered on event comment update, after commit in DB
72	on_postload_asset_comment_delete	Triggered on event comment deletion, after commit in DB
73	on_postload_evidence_commented	Triggered on evidence commented, after commit in DB
74	on_postload_evidence_comment_update	Triggered on evidence comment update, after commit in DB
75	on_postload_evidence_comment_delete	Triggered on evidence comment deletion, after commit in DB
76	on_postload_task_commented	Triggered on task commented, after commit in DB
77	on_postload_task_comment_update	Triggered on task comment update, after commit in DB
78	on_postload_task_comment_delete	Triggered on task comment deletion, after commit in DB
79	on_postload_ioc_commented	Triggered on IOC commented, after commit in DB
80	on_postload_ioc_comment_update	Triggered on IOC comment update, after commit in DB
81	on_postload_ioc_comment_delete	Triggered on IOC comment deletion, after commit in DB
82	on_postload_event_commented	Triggered on event commented, after commit in DB
83	on_postload_event_comment_update	Triggered on event comment update, after commit in DB
84	on_postload_event_comment_delete	Triggered on event comment deletion, after commit in DB
85	on_postload_note_commented	Triggered on note commented, after commit in DB
86	on_postload_note_comment_update	Triggered on note comment update, after commit in DB
87	on_postload_note_comment_delete	Triggered on note comment deletion, after commit in DB
88	on_postload_alert_commented	Triggered on alert commented, after commit in DB
89	on_postload_alert_comment_update	Triggered on alert comment update, after commit in DB
90	on_postload_alert_comment_delete	Triggered on alert comment deletion, after commit in DB
\.


--
-- Data for Name: iris_module; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.iris_module (id, added_by_id, module_human_name, module_name, module_description, module_version, interface_version, date_added, is_active, has_pipeline, pipeline_args, module_config, module_type) FROM stdin;
1	1	IrisVT	iris_vt_module	Provides an interface between VirusTotal and IRIS	1.2.1	1.2.0	2025-08-27 07:54:05.206636	f	f	{}	[{"param_name": "vt_api_key", "param_human_name": "VT API Key", "param_description": "API key to use to communicate with VT", "default": null, "mandatory": true, "type": "sensitive_string"}, {"param_name": "vt_key_is_premium", "param_human_name": "VT Key is premium", "param_description": "Set to True if the VT key is premium", "default": false, "mandatory": true, "type": "bool", "value": false}, {"param_name": "vt_manual_hook_enabled", "param_human_name": "Manual triggers on IOCs", "param_description": "Set to True to offers possibility to manually triggers the module via the UI", "default": true, "mandatory": true, "type": "bool", "section": "Triggers", "value": true}, {"param_name": "vt_on_update_hook_enabled", "param_human_name": "Triggers automatically on IOC update", "param_description": "Set to True to automatically add a VT insight each time an IOC is updated", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}, {"param_name": "vt_on_create_hook_enabled", "param_human_name": "Triggers automatically on IOC create", "param_description": "Set to True to automatically add a VT insight each time an IOC is created", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}, {"param_name": "vt_ip_assign_asn_as_tag", "param_human_name": "Assign ASN tag to IP", "param_description": "Assign a new tag to IOC IPs with the ASN fetched from VT", "default": true, "mandatory": true, "type": "bool", "section": "Insights", "value": true}, {"param_name": "vt_tag_malicious_threshold", "param_human_name": "IOC tag malicious threshold", "param_description": "Tag the IOC has malicious if the percentage of detection is above the specified threshold", "default": "10", "mandatory": true, "type": "float", "section": "Insights", "value": "10"}, {"param_name": "vt_tag_suspicious_threshold", "param_human_name": "IOC tag suspicious threshold", "param_description": "Tag the IOC has suspicious if the percentage of detection is above the specified threshold", "default": "5", "mandatory": true, "type": "float", "section": "Insights", "value": "5"}, {"param_name": "vt_report_as_attribute", "param_human_name": "Add VT report as new IOC attribute", "param_description": "Creates a new attribute on the IOC, base on the VT report. Attributes are based on the templates of this configuration", "default": true, "mandatory": true, "type": "bool", "section": "Insights", "value": true}, {"param_name": "vt_domain_report_template", "param_human_name": "Domain report template", "param_description": "Domain reports template used to add a new custom attribute to the target IOC", "default": "{% if nb_detected_urls %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected URLS</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected URLs</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_urls }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_urls_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n{% if nb_detected_samples %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected samples</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected samples</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_samples }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_samples_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n            {% if whois %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_wh\\" data-toggle=\\"collapse\\" data-target=\\"#drop_whois\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-user-6\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        WHOIS\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_whois\\" class=\\"collapse\\" aria-labelledby=\\"drop_wh\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <blockquote class=\\"blockquote\\">\\n                            {% autoescape false %}\\n                            <p>{{ whois| replace(\\"\\\\n\\", \\"<br/>\\") }}</p>\\n                            {% endautoescape %}\\n                        </blockquote>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n    \\n            {% if resolutions %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_res\\" data-toggle=\\"collapse\\" data-target=\\"#drop_resolutions\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Resolutions history\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_resolutions\\" class=\\"collapse\\" aria-labelledby=\\"drop_res\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for resolution in resolutions %} \\n                            <li>{{resolution.ip_address}} ( Last resolved on {{resolution.last_resolved}} )</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n            {% if subdomains %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_sub\\" data-toggle=\\"collapse\\" data-target=\\"#drop_subdomains\\" aria-expanded=\\"false\\" aria-controls=\\"drop_subdomains\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-diagram\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Subdomains\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_subdomains\\" class=\\"collapse\\" aria-labelledby=\\"drop_sub\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for subdomain in subdomains %} \\n                            <li>{{subdomain}}</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n</script>", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "{% if nb_detected_urls %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected URLS</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected URLs</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_urls }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_urls_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n{% if nb_detected_samples %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected samples</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected samples</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_samples }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_samples_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n            {% if whois %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_wh\\" data-toggle=\\"collapse\\" data-target=\\"#drop_whois\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-user-6\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        WHOIS\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_whois\\" class=\\"collapse\\" aria-labelledby=\\"drop_wh\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <blockquote class=\\"blockquote\\">\\n                            {% autoescape false %}\\n                            <p>{{ whois| replace(\\"\\\\n\\", \\"<br/>\\") }}</p>\\n                            {% endautoescape %}\\n                        </blockquote>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n    \\n            {% if resolutions %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_res\\" data-toggle=\\"collapse\\" data-target=\\"#drop_resolutions\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Resolutions history\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_resolutions\\" class=\\"collapse\\" aria-labelledby=\\"drop_res\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for resolution in resolutions %} \\n                            <li>{{resolution.ip_address}} ( Last resolved on {{resolution.last_resolved}} )</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n            {% if subdomains %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_sub\\" data-toggle=\\"collapse\\" data-target=\\"#drop_subdomains\\" aria-expanded=\\"false\\" aria-controls=\\"drop_subdomains\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-diagram\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Subdomains\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_subdomains\\" class=\\"collapse\\" aria-labelledby=\\"drop_sub\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for subdomain in subdomains %} \\n                            <li>{{subdomain}}</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n</script>"}, {"param_name": "vt_ip_report_template", "param_human_name": "IP report template", "param_description": "IP report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Basic information</h3>\\n        <dl class=\\"row\\">\\n            {% if results.as_owner %}\\n            <dt class=\\"col-sm-3\\">AS owner</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.as_owner }}</dd>\\n            {% endif %}\\n            \\n            {% if country %}\\n            <dt class=\\"col-sm-3\\">Country</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.country }}</dd>\\n            {% endif %}\\n        </dl>\\n    </div>\\n</div>    \\n\\n{% if nb_detected_urls %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected URLS</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected URLs</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_urls }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_urls_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n{% if nb_detected_samples %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected communicating samples</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected samples</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_samples }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_samples_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.resolutions %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_res\\" data-toggle=\\"collapse\\" data-target=\\"#drop_resolutions\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Resolutions history\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_resolutions\\" class=\\"collapse\\" aria-labelledby=\\"drop_res\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for resolution in results.resolutions %} \\n                            <li>{{ resolution.hostname }} ( Last resolved on {{resolution.last_resolved}} )</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n</script>", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Basic information</h3>\\n        <dl class=\\"row\\">\\n            {% if results.as_owner %}\\n            <dt class=\\"col-sm-3\\">AS owner</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.as_owner }}</dd>\\n            {% endif %}\\n            \\n            {% if country %}\\n            <dt class=\\"col-sm-3\\">Country</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.country }}</dd>\\n            {% endif %}\\n        </dl>\\n    </div>\\n</div>    \\n\\n{% if nb_detected_urls %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected URLS</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected URLs</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_urls }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_urls_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n{% if nb_detected_samples %}\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Detected communicating samples</h3>\\n        <dl class=\\"row\\">\\n            <dt class=\\"col-sm-3\\">Total detected samples</dt>\\n            <dd class=\\"col-sm-9\\">{{ nb_detected_samples }}</dd>\\n            \\n            <dt class=\\"col-sm-3\\">Average detection ratio</dt>\\n            <dd class=\\"col-sm-9\\">{{ avg_samples_detect_ratio }}</dd>\\n        </dl>\\n    </div>\\n</div>    \\n{% endif %}\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.resolutions %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_res\\" data-toggle=\\"collapse\\" data-target=\\"#drop_resolutions\\" aria-expanded=\\"false\\" aria-controls=\\"drop_resolutions\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Resolutions history\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_resolutions\\" class=\\"collapse\\" aria-labelledby=\\"drop_res\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <ul>\\n                            {% for resolution in results.resolutions %} \\n                            <li>{{ resolution.hostname }} ( Last resolved on {{resolution.last_resolved}} )</li>\\n                            {% endfor %}\\n                        </ul>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n</script>"}, {"param_name": "vt_hash_report_template", "param_human_name": "Hash report template", "param_description": "Hash report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Basic information</h3>\\n        <dl class=\\"row\\">\\n            {% if results.total %}\\n            <dt class=\\"col-sm-3\\">Detection</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.positives }} / {{ results.total }}</dd>\\n            {% endif %}\\n            \\n            {% if results.permalink %}\\n            <dt class=\\"col-sm-3\\">Permalink</dt>\\n            <dd class=\\"col-sm-9\\"><a href='{{ results.permalink }}'>{{ results.permalink }}</a></dd>\\n            {% endif %}\\n            \\n            \\n            {% if results.scan_date %}\\n            <dt class=\\"col-sm-3\\">Scan date</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.scan_date }}</dd>\\n            {% endif %}\\n            \\n            {% if results.md5 %}\\n            <dt class=\\"col-sm-3\\">MD5</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.md5 }}</dd>\\n            {% endif %}\\n            \\n            {% if results.sha256 %}\\n            <dt class=\\"col-sm-3\\">SHA256</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.sha256 }}</dd>\\n            {% endif %}\\n        \\n        </dl>\\n    </div>\\n</div>    \\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.scans %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_sc\\" data-toggle=\\"collapse\\" data-target=\\"#drop_scans\\" aria-expanded=\\"false\\" aria-controls=\\"drop_scans\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Scans results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_scans\\" class=\\"collapse\\" aria-labelledby=\\"drop_sc\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"vt_in_scans\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Engine</th>\\n                                      <th>Detected</th>\\n                                      <th>Result</th>\\n                                      <th>Update</th>\\n                                      <th>Version</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for scan in results.scans %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ scan }}</td>\\n                                        <td>{{ results.scans[scan].detected }}</td>\\n                                        <td>{{ results.scans[scan].result }}</td>\\n                                        <td>{{ results.scans[scan].update }}</td>\\n                                        <td>{{ results.scans[scan].version }}</td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n\\n{% if results.scans %}\\n$(\\"#vt_in_scans\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n    \\n{% endif %}\\n\\n</script>", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <h3>Basic information</h3>\\n        <dl class=\\"row\\">\\n            {% if results.total %}\\n            <dt class=\\"col-sm-3\\">Detection</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.positives }} / {{ results.total }}</dd>\\n            {% endif %}\\n            \\n            {% if results.permalink %}\\n            <dt class=\\"col-sm-3\\">Permalink</dt>\\n            <dd class=\\"col-sm-9\\"><a href='{{ results.permalink }}'>{{ results.permalink }}</a></dd>\\n            {% endif %}\\n            \\n            \\n            {% if results.scan_date %}\\n            <dt class=\\"col-sm-3\\">Scan date</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.scan_date }}</dd>\\n            {% endif %}\\n            \\n            {% if results.md5 %}\\n            <dt class=\\"col-sm-3\\">MD5</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.md5 }}</dd>\\n            {% endif %}\\n            \\n            {% if results.sha256 %}\\n            <dt class=\\"col-sm-3\\">SHA256</dt>\\n            <dd class=\\"col-sm-9\\">{{ results.sha256 }}</dd>\\n            {% endif %}\\n        \\n        </dl>\\n    </div>\\n</div>    \\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.scans %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_sc\\" data-toggle=\\"collapse\\" data-target=\\"#drop_scans\\" aria-expanded=\\"false\\" aria-controls=\\"drop_scans\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Scans results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_scans\\" class=\\"collapse\\" aria-labelledby=\\"drop_sc\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"vt_in_scans\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Engine</th>\\n                                      <th>Detected</th>\\n                                      <th>Result</th>\\n                                      <th>Update</th>\\n                                      <th>Version</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for scan in results.scans %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ scan }}</td>\\n                                        <td>{{ results.scans[scan].detected }}</td>\\n                                        <td>{{ results.scans[scan].result }}</td>\\n                                        <td>{{ results.scans[scan].update }}</td>\\n                                        <td>{{ results.scans[scan].version }}</td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n            \\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Raw report</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Raw report\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw\\" class=\\"collapse\\" aria-labelledby=\\"drop_r\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='vt_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar vt_in_raw = ace.edit(\\"vt_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nvt_in_raw.setReadOnly(true);\\nvt_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nvt_in_raw.session.setMode(\\"ace/mode/json\\");\\nvt_in_raw.renderer.setShowGutter(true);\\nvt_in_raw.setOption(\\"showLineNumbers\\", true);\\nvt_in_raw.setOption(\\"showPrintMargin\\", false);\\nvt_in_raw.setOption(\\"displayIndentGuides\\", true);\\nvt_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nvt_in_raw.session.setUseWrapMode(true);\\nvt_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nvt_in_raw.renderer.setScrollMargin(8, 5);\\n\\n{% if results.scans %}\\n$(\\"#vt_in_scans\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n    \\n{% endif %}\\n\\n</script>"}]	module_processor
2	1	IrisMISP	iris_misp_module	Provides an interface between MISP and IRIS	1.3.0	1.2.0	2025-08-27 07:54:05.534546	f	f	{}	[{"param_name": "misp_config", "param_human_name": "MISP configuration", "param_description": "Configure one or several MISP instances", "default": "{\\n   \\"name\\": \\"Public_MISP\\",\\n   \\"type\\":\\"public\\",\\n   \\"url\\":[\\"https://URL\\"],\\n   \\"key\\":[\\"APIKEY\\"],\\n   \\"ssl\\":[false]\\n}", "mandatory": true, "type": "textfield_json", "value": "{\\n   \\"name\\": \\"Public_MISP\\",\\n   \\"type\\":\\"public\\",\\n   \\"url\\":[\\"https://URL\\"],\\n   \\"key\\":[\\"APIKEY\\"],\\n   \\"ssl\\":[false]\\n}"}, {"param_name": "misp_http_proxy", "param_human_name": "MISP HTTP Proxy", "param_description": "HTTP Proxy parameter", "default": null, "mandatory": false, "type": "string"}, {"param_name": "misp_https_proxy", "param_human_name": "MISP HTTPS Proxy", "param_description": "HTTPS Proxy parameter", "default": null, "mandatory": false, "type": "string"}, {"param_name": "misp_report_as_attribute", "param_human_name": "Add MISP report as new IOC attribute", "param_description": "Creates a new attribute on the IOC, base on the MISP report. Attributes are based on the templates of this configuration", "default": true, "mandatory": true, "type": "bool", "section": "Insights", "value": true}, {"param_name": "misp_domain_report_template", "param_human_name": "Domain report template", "param_description": "Domain report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> "}, {"param_name": "misp_ip_report_template", "param_human_name": "IP report template", "param_description": "IP report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> "}, {"param_name": "misp_hash_report_template", "param_human_name": "Hash report template", "param_description": "Hash report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> "}, {"param_name": "misp_ja3_report_template", "param_human_name": "JA3 report template", "param_description": "JA3 report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>MISP raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_misp\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_misp\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_misp\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        MISP raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_misp\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_misp\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='misp_raw_ace'>{{ results| tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar misp_in_raw = ace.edit(\\"misp_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nmisp_in_raw.setReadOnly(true);\\nmisp_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nmisp_in_raw.session.setMode(\\"ace/mode/json\\");\\nmisp_in_raw.renderer.setShowGutter(true);\\nmisp_in_raw.setOption(\\"showLineNumbers\\", true);\\nmisp_in_raw.setOption(\\"showPrintMargin\\", false);\\nmisp_in_raw.setOption(\\"displayIndentGuides\\", true);\\nmisp_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nmisp_in_raw.session.setUseWrapMode(true);\\nmisp_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nmisp_in_raw.renderer.setScrollMargin(8, 5);\\n</script> "}, {"param_name": "misp_manual_hook_enabled", "param_human_name": "Manual triggers on IOCs", "param_description": "Set to True to offers possibility to manually triggers the module via the UI", "default": true, "mandatory": true, "type": "bool", "section": "Triggers", "value": true}, {"param_name": "misp_on_create_hook_enabled", "param_human_name": "Triggers automatically on IOC create", "param_description": "Set to True to automatically add a MISP insight each time an IOC is created", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}, {"param_name": "misp_on_update_hook_enabled", "param_human_name": "Triggers automatically on IOC update", "param_description": "Set to True to automatically add a MISP insight each time an IOC is updated", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}]	module_processor
3	1	IrisCheck	iris_check_module	Provides a simple check module that replies to every hooks	1.0.1	1.2.0	2025-08-27 07:54:05.568932	f	f	{}	[{"param_name": "check_log_received_hook", "param_human_name": "Log received hook", "param_description": "Logs every hook received if set to true. Otherwise do nothing.", "default": true, "mandatory": true, "type": "bool", "value": true}]	module_processor
4	1	IrisWebHooks	iris_webhooks_module	Provides webhooks for IRIS. See https://docs.dfir-iris.org/operations/modules/natives/IrisWebHooks/	1.0.8	1.2.0	2025-08-27 07:54:06.504397	f	f	{}	[{"param_name": "wh_configuration", "param_human_name": "Webhooks configuration", "param_description": "JSON Webhooks configuration", "default": "{}", "mandatory": true, "type": "textfield_json", "value": "{}"}]	module_processor
5	1	Iris IntelOwl	iris_intelowl_module	Provides a connector with IntelOwl - allows to pull insights from IntelOwl analyzers	0.1.0	1.2.0	2025-08-27 07:54:06.572004	f	f	{}	[{"param_name": "intelowl_url", "param_human_name": "IntelOwl URL", "param_description": "", "default": null, "mandatory": true, "type": "string"}, {"param_name": "intelowl_key", "param_human_name": "IntelOwl API key", "param_description": "IntelOwl API key", "default": null, "mandatory": true, "type": "sensitive_string"}, {"param_name": "intelowl_should_use_proxy", "param_human_name": "Set global proxy settings for IntelOwl module", "param_description": "Set true or false to decide whether or not the global proxy settings should be set for IntelOwl usage", "default": false, "mandatory": true, "type": "bool", "value": false}, {"param_name": "intelowl_maxtime", "param_human_name": "Maximum job time (minutes)", "param_description": "Set the maximum time the IRIS task should wait until the end of the IntelOwl job", "default": 15, "mandatory": false, "type": "integer", "value": 15}, {"param_name": "intelowl_manual_hook_enabled", "param_human_name": "Manual triggers on IOCs", "param_description": "Set to True to offers possibility to manually triggers the module via the UI", "default": true, "mandatory": true, "type": "bool", "section": "Triggers", "value": true}, {"param_name": "intelowl_on_create_hook_enabled", "param_human_name": "Triggers automatically on IOC create", "param_description": "Set to True to automatically add a IntelOwl insight each time an IOC is created", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}, {"param_name": "intelowl_on_update_hook_enabled", "param_human_name": "Triggers automatically on IOC update", "param_description": "Set to True to automatically add a IntelOwl insight each time an IOC is updated", "default": false, "mandatory": true, "type": "bool", "section": "Triggers", "value": false}, {"param_name": "intelowl_report_as_attribute", "param_human_name": "Add IntelOwl report as new IOC attribute", "param_description": "Creates a new attribute on the IOC, base on the IntelOwl report. Attributes are based on the templates of this configuration", "default": true, "mandatory": true, "type": "bool", "section": "Insights", "value": true}, {"param_name": "intelowl_domain_report_template", "param_human_name": "Domain report template", "param_description": "Domain report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> "}, {"param_name": "intelowl_ip_report_template", "param_human_name": "IP report template", "param_description": "IP report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> "}, {"param_name": "intelowl_url_report_template", "param_human_name": "URL report template", "param_description": "URL report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> "}, {"param_name": "intelowl_hash_report_template", "param_human_name": "Hash report template", "param_description": "Hash report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> "}, {"param_name": "intelowl_generic_report_template", "param_human_name": "Generic ioc report template", "param_description": "Generic ioc report template used to add a new custom attribute to the target IOC", "default": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> ", "mandatory": false, "type": "textfield_html", "section": "Templates", "value": "<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>General information</h3>\\n                <div class=\\"row\\">\\n                    <div class=\\"col-12\\">\\n                        <dl class=\\"row\\">\\n                            {% if external_link %}\\n                            <dt class=\\"col-sm-3\\">Report</dt>\\n                            <dd class=\\"col-sm-9\\">\\n                                {% autoescape false %}\\n                                <a href=\\"{{ external_link }}\\" target=\\"_blank\\">IntelOwl Report Link</a>\\n                                {% endautoescape %}\\n                            </dd>\\n                            {% endif %}\\n                            {% if nb_analyzer_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Analyzer Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_analyzer_reports }}</dd>\\n                            {% endif %}\\n                            {% if nb_connector_reports %}\\n                            <dt class=\\"col-sm-3\\">Total Connector Reports</dt>\\n                            <dd class=\\"col-sm-9\\">{{ nb_connector_reports }}</dd>\\n                            {% endif %}\\n                        </dl>\\n                    </div>\\n                </div>\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>Additional information</h3>\\n\\n            {% if results.analyzer_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_an\\" data-toggle=\\"collapse\\" data-target=\\"#drop_anrep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_anrep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Analyzer results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_anrep\\" class=\\"collapse\\" aria-labelledby=\\"drop_an\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_anrep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for analyzer_report in results.analyzer_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ analyzer_report.name }}</td>\\n                                        <td>{{ analyzer_report.status }}</td>\\n                                        <td>{{ analyzer_report.process_time }}</td>\\n                                        <td>{{ analyzer_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ analyzer_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ analyzer_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ analyzer_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ analyzer_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ analyzer_report.name }}_raw_ace'>{{ analyzer_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n            {% if results.connector_reports %}\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_co\\" data-toggle=\\"collapse\\" data-target=\\"#drop_corep\\" aria-expanded=\\"false\\" aria-controls=\\"drop_corep\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        Connector results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_corep\\" class=\\"collapse\\" aria-labelledby=\\"drop_co\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <table class=\\"table display table-bordered table-striped table-hover\\" width=\\"100%\\" cellspacing=\\"0\\" id=\\"il_in_corep\\" >\\n                                <thead>\\n                                  <tr>\\n                                      <th>Name</th>\\n                                      <th>Status</th>\\n                                      <th>ProcessTime</th>\\n                                      <th>StartTime</th>\\n                                      <th>Report</th>\\n                                  </tr>\\n                                </thead>\\n                                <tbody>\\n                                {% for connector_report in results.connector_reports %} \\n                                    <tr role=\\"row\\">\\n                                        <td>{{ connector_report.name }}</td>\\n                                        <td>{{ connector_report.status }}</td>\\n                                        <td>{{ connector_report.process_time }}</td>\\n                                        <td>{{ connector_report.start_time }}</td>\\n                                        <td>\\n                                            <div class=\\"card\\">\\n                                                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl_{{ connector_report.name }}\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl_{{ connector_report.name }}\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl_{{ connector_report.name }}\\" role=\\"button\\">\\n                                                    <div class=\\"span-title\\">\\n                                                        {{ connector_report.name }} raw report\\n                                                    </div>\\n                                                    <div class=\\"span-mode\\"></div>\\n                                                </div>\\n                                                <div id=\\"drop_raw_intelowl_{{ connector_report.name }}\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl_{{ connector_report.name }}\\" style=\\"\\">\\n                                                    <div class=\\"card-body\\">\\n                                                        <div id='intelowl__{{ connector_report.name }}_raw_ace'>{{ connector_report.report|tojson(indent=4) }}</div>\\n                                                    </div>\\n                                                </div>\\n                                            </div>\\n                                        </td>\\n                                    </tr>\\n                                {% endfor %}\\n                                </tbody>\\n                        </table>\\n                    </div>\\n                </div>\\n            </div>\\n            {% endif %}\\n\\n        </div>\\n    </div>\\n</div>\\n\\n<div class=\\"row\\">\\n    <div class=\\"col-12\\">\\n        <div class=\\"accordion\\">\\n            <h3>IntelOwl raw results</h3>\\n\\n            <div class=\\"card\\">\\n                <div class=\\"card-header collapsed\\" id=\\"drop_r_intelowl\\" data-toggle=\\"collapse\\" data-target=\\"#drop_raw_intelowl\\" aria-expanded=\\"false\\" aria-controls=\\"drop_raw_intelowl\\" role=\\"button\\">\\n                    <div class=\\"span-icon\\">\\n                        <div class=\\"flaticon-file\\"></div>\\n                    </div>\\n                    <div class=\\"span-title\\">\\n                        IntelOwl raw results\\n                    </div>\\n                    <div class=\\"span-mode\\"></div>\\n                </div>\\n                <div id=\\"drop_raw_intelowl\\" class=\\"collapse\\" aria-labelledby=\\"drop_r_intelowl\\" style=\\"\\">\\n                    <div class=\\"card-body\\">\\n                        <div id='intelowl_raw_ace'>{{ results|default(\\"\\")|tojson(indent=4) }}</div>\\n                    </div>\\n                </div>\\n            </div>\\n        </div>\\n    </div>\\n</div> \\n<script>\\nvar intelowl_in_raw = ace.edit(\\"intelowl_raw_ace\\",\\n{\\n    autoScrollEditorIntoView: true,\\n    minLines: 30,\\n});\\nintelowl_in_raw.setReadOnly(true);\\nintelowl_in_raw.setTheme(\\"ace/theme/tomorrow\\");\\nintelowl_in_raw.session.setMode(\\"ace/mode/json\\");\\nintelowl_in_raw.renderer.setShowGutter(true);\\nintelowl_in_raw.setOption(\\"showLineNumbers\\", true);\\nintelowl_in_raw.setOption(\\"showPrintMargin\\", false);\\nintelowl_in_raw.setOption(\\"displayIndentGuides\\", true);\\nintelowl_in_raw.setOption(\\"maxLines\\", \\"Infinity\\");\\nintelowl_in_raw.session.setUseWrapMode(true);\\nintelowl_in_raw.setOption(\\"indentedSoftWrap\\", true);\\nintelowl_in_raw.renderer.setScrollMargin(8, 5);\\n{% if results.analyzer_reports %}\\n$(\\"#il_in_anrep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n{% if results.connector_reports %}\\n$(\\"#il_in_corep\\").DataTable({\\n    filter: true,\\n    info: true,\\n    ordering: true,\\n    processing: true,\\n});\\n{% endif %}\\n</script> "}]	module_processor
\.


--
-- Data for Name: iris_module_hooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.iris_module_hooks (id, module_id, hook_id, is_manual_hook, manual_hook_ui_name, retry_on_fail, max_retry, run_asynchronously, wait_till_return) FROM stdin;
1	1	36	t	Get VT insight	\N	0	t	f
2	3	1	f	\N	\N	0	t	f
3	3	2	f	\N	\N	0	t	f
4	3	3	f	\N	\N	0	t	f
5	3	4	f	\N	\N	0	t	f
6	3	5	f	\N	\N	0	t	f
7	3	6	f	\N	\N	0	t	f
8	3	7	f	\N	\N	0	t	f
9	3	8	f	\N	\N	0	t	f
10	3	9	t	iris_check_module::on_manual_trigger_alert	\N	0	t	f
11	3	10	f	\N	\N	0	t	f
12	3	11	f	\N	\N	0	t	f
13	3	12	f	\N	\N	0	t	f
14	3	13	f	\N	\N	0	t	f
15	3	14	f	\N	\N	0	t	f
16	3	15	t	iris_check_module::on_manual_trigger_case	\N	0	t	f
17	3	16	f	\N	\N	0	t	f
18	3	17	f	\N	\N	0	t	f
19	3	18	f	\N	\N	0	t	f
20	3	19	f	\N	\N	0	t	f
21	3	20	f	\N	\N	0	t	f
22	3	21	f	\N	\N	0	t	f
23	3	22	t	iris_check_module::on_manual_trigger_asset	\N	0	t	f
24	3	23	f	\N	\N	0	t	f
25	3	24	f	\N	\N	0	t	f
26	3	25	f	\N	\N	0	t	f
27	3	26	f	\N	\N	0	t	f
28	3	27	f	\N	\N	0	t	f
29	3	28	f	\N	\N	0	t	f
30	3	29	t	iris_check_module::on_manual_trigger_note	\N	0	t	f
31	3	30	f	\N	\N	0	t	f
32	3	31	f	\N	\N	0	t	f
33	3	32	f	\N	\N	0	t	f
34	3	33	f	\N	\N	0	t	f
35	3	34	f	\N	\N	0	t	f
36	3	35	f	\N	\N	0	t	f
37	3	36	t	iris_check_module::on_manual_trigger_ioc	\N	0	t	f
38	3	37	f	\N	\N	0	t	f
39	3	38	f	\N	\N	0	t	f
40	3	39	f	\N	\N	0	t	f
41	3	40	f	\N	\N	0	t	f
42	3	41	f	\N	\N	0	t	f
43	3	42	f	\N	\N	0	t	f
44	3	43	f	\N	\N	0	t	f
45	3	44	t	iris_check_module::on_manual_trigger_event	\N	0	t	f
46	3	45	f	\N	\N	0	t	f
47	3	46	f	\N	\N	0	t	f
48	3	47	f	\N	\N	0	t	f
49	3	48	f	\N	\N	0	t	f
50	3	49	f	\N	\N	0	t	f
51	3	50	f	\N	\N	0	t	f
52	3	51	t	iris_check_module::on_manual_trigger_evidence	\N	0	t	f
53	3	52	f	\N	\N	0	t	f
54	3	53	f	\N	\N	0	t	f
55	3	54	f	\N	\N	0	t	f
56	3	55	f	\N	\N	0	t	f
57	3	56	f	\N	\N	0	t	f
58	3	57	f	\N	\N	0	t	f
59	3	58	t	iris_check_module::on_manual_trigger_task	\N	0	t	f
60	3	59	f	\N	\N	0	t	f
61	3	60	f	\N	\N	0	t	f
62	3	61	f	\N	\N	0	t	f
63	3	62	f	\N	\N	0	t	f
64	3	63	f	\N	\N	0	t	f
65	3	64	f	\N	\N	0	t	f
66	3	65	t	iris_check_module::on_manual_trigger_global_task	\N	0	t	f
67	3	66	f	\N	\N	0	t	f
68	3	67	f	\N	\N	0	t	f
69	3	68	f	\N	\N	0	t	f
70	3	69	f	\N	\N	0	t	f
71	3	70	f	\N	\N	0	t	f
72	3	71	f	\N	\N	0	t	f
73	3	72	f	\N	\N	0	t	f
74	3	73	f	\N	\N	0	t	f
75	3	74	f	\N	\N	0	t	f
76	3	75	f	\N	\N	0	t	f
77	3	76	f	\N	\N	0	t	f
78	3	77	f	\N	\N	0	t	f
79	3	78	f	\N	\N	0	t	f
80	3	79	f	\N	\N	0	t	f
81	3	80	f	\N	\N	0	t	f
82	3	81	f	\N	\N	0	t	f
83	3	82	f	\N	\N	0	t	f
84	3	83	f	\N	\N	0	t	f
85	3	84	f	\N	\N	0	t	f
86	3	85	f	\N	\N	0	t	f
87	3	86	f	\N	\N	0	t	f
88	3	87	f	\N	\N	0	t	f
89	3	88	f	\N	\N	0	t	f
90	3	89	f	\N	\N	0	t	f
91	3	90	f	\N	\N	0	t	f
\.


--
-- Data for Name: iris_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.iris_reports (report_id, case_id, report_title, report_date, report_content, user_id) FROM stdin;
\.


--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.languages (id, name, code) FROM stdin;
1	french	FR
2	english	EN
3	german	DE
4	bulgarian	BG
5	croatian	HR
6	danish	DK
7	dutch	NL
8	estonian	EE
9	finnish	FI
10	greek	GR
11	hungarian	HU
12	irish	IE
13	italian	IT
14	latvian	LV
15	lithuanian	LT
16	maltese	MT
17	polish	PL
18	portuguese	PT
19	romanian	RO
20	slovak	SK
21	slovenian	SI
22	spanish	ES
23	swedish	SE
24	indian	IN
25	chinese	CN
26	korean	KR
27	arabic	AR
28	japanese	JP
29	turkish	TR
30	vietnamese	VN
31	thai	TH
32	hebrew	IL
33	czech	CZ
34	norwegian	NO
35	brazilian	BR
36	ukrainian	UA
37	catalan	CA
38	serbian	RS
39	persian	IR
40	afrikaans	ZA
41	albanian	AL
42	armenian	AM
\.


--
-- Data for Name: note_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note_comments (id, comment_id, comment_note_id) FROM stdin;
\.


--
-- Data for Name: note_directory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note_directory (id, name, parent_id, case_id) FROM stdin;
\.


--
-- Data for Name: note_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note_revisions (revision_id, note_id, revision_number, note_title, note_content, note_user, revision_timestamp) FROM stdin;
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes (note_id, note_uuid, note_title, note_content, note_user, note_creationdate, note_lastupdate, note_case_id, custom_attributes, directory_id, modification_history) FROM stdin;
\.


--
-- Data for Name: notes_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes_group (group_id, group_uuid, group_title, group_user, group_creationdate, group_lastupdate, group_case_id) FROM stdin;
\.


--
-- Data for Name: notes_group_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notes_group_link (link_id, group_id, note_id, case_id) FROM stdin;
\.


--
-- Data for Name: object_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.object_state (object_id, object_case_id, object_updated_by_id, object_name, object_state, object_last_update) FROM stdin;
1	1	1	timeline	0	2025-08-27 07:54:06.702176
2	1	1	tasks	0	2025-08-27 07:54:06.707921
3	1	1	evidences	0	2025-08-27 07:54:06.711031
4	1	1	ioc	0	2025-08-27 07:54:06.714611
5	1	1	assets	0	2025-08-27 07:54:06.723883
6	1	1	notes	0	2025-08-27 07:54:06.730211
7	2	2	timeline	0	2025-08-28 12:49:34.165845
8	2	2	tasks	0	2025-08-28 12:49:34.173105
9	2	2	evidences	0	2025-08-28 12:49:34.175212
10	2	2	ioc	0	2025-08-28 12:49:34.177011
11	2	2	assets	0	2025-08-28 12:49:34.178662
12	2	2	notes	0	2025-08-28 12:49:34.180485
13	3	2	timeline	0	2025-08-28 12:54:07.167836
14	3	2	tasks	0	2025-08-28 12:54:07.17069
15	3	2	evidences	0	2025-08-28 12:54:07.172359
16	3	2	ioc	0	2025-08-28 12:54:07.174058
17	3	2	assets	0	2025-08-28 12:54:07.177031
18	3	2	notes	0	2025-08-28 12:54:07.179132
19	4	2	timeline	0	2025-08-28 13:03:55.634629
20	4	2	tasks	0	2025-08-28 13:03:55.636808
21	4	2	evidences	0	2025-08-28 13:03:55.638503
23	4	2	assets	0	2025-08-28 13:03:55.642327
24	4	2	notes	0	2025-08-28 13:03:55.644252
22	4	2	ioc	5	2025-08-28 13:04:06.97111
\.


--
-- Data for Name: organisation_case_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organisation_case_access (id, org_id, case_id, access_level) FROM stdin;
\.


--
-- Data for Name: organisations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.organisations (org_id, org_uuid, org_name, org_description, org_url, org_logo, org_email, org_nationality, org_sector, org_type) FROM stdin;
1	28448855-76b0-42cf-aff0-8e48cca9b9ff	Default Org	Default Organisation						
\.


--
-- Data for Name: os_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.os_type (type_id, type_name) FROM stdin;
1	Windows
2	Linux
3	AIX
4	MacOS
5	Apple iOS
6	Cisco iOS
7	Android
\.


--
-- Data for Name: report_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_type (id, name) FROM stdin;
1	Investigation
2	Activities
\.


--
-- Data for Name: review_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.review_status (id, status_name) FROM stdin;
1	No review required
2	Not reviewed
3	Pending review
4	Review in progress
5	Reviewed
\.


--
-- Data for Name: saved_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_filters (filter_id, created_by, filter_name, filter_description, filter_data, filter_is_private, filter_type) FROM stdin;
\.


--
-- Data for Name: server_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.server_settings (id, https_proxy, http_proxy, prevent_post_mod_repush, prevent_post_objects_repush, has_updates_available, enable_updates_check, password_policy_min_length, password_policy_upper_case, password_policy_lower_case, password_policy_digit, password_policy_special_chars, enforce_mfa) FROM stdin;
1			f	f	\N	\N	12	t	t	t		f
\.


--
-- Data for Name: severities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.severities (severity_id, severity_name, severity_description) FROM stdin;
1	Medium	Medium
2	Unspecified	Unspecified
3	Informational	Informational
4	Low	Low
5	High	High
6	Critical	Critical
\.


--
-- Data for Name: similar_alerts_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.similar_alerts_cache (id, customer_id, asset_name, ioc_value, alert_id, created_at, asset_type_id, ioc_type_id) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id, tag_title, tag_creation_date, tag_namespace) FROM stdin;
1	data-id	2025-08-28 13:04:06.70237	\N
2	path	2025-08-28 13:04:06.803948	\N
3	ip-agent	2025-08-28 13:04:06.854444	\N
4	process-name	2025-08-28 13:04:06.904362	\N
5	target-user	2025-08-28 13:04:06.955194	\N
\.


--
-- Data for Name: task_assignee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_assignee (id, user_id, task_id) FROM stdin;
\.


--
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_comments (id, comment_id, comment_task_id) FROM stdin;
\.


--
-- Data for Name: task_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_status (id, status_name, status_description, status_bscolor) FROM stdin;
1	To do		danger
2	In progress		warning
3	On hold		muted
4	Done		success
5	Canceled		muted
\.


--
-- Data for Name: tlp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tlp (tlp_id, tlp_name, tlp_bscolor) FROM stdin;
1	red	danger
2	amber	warning
3	green	success
4	clear	black
5	amber+strict	warning
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, "user", name, email, uuid, password, ctx_case, ctx_human_case, active, api_key, external_id, in_dark_mode, has_mini_sidebar, has_deletion_confirmation, is_service_account, mfa_secrets, webauthn_credentials, mfa_setup_complete) FROM stdin;
2	apishuffle	Apishuffle	apishuffle@valorh2.com	cdbf3d63-6c54-4b5a-ac3b-32ea0038e04e	\N	\N	\N	t	dNUqNqVOu1nOC8zVvMgS140a9nq3XpDdKYPxiDmLu4FJDTy5p4hesZiD7IcqAdIqxi0NQYqCnNDQR2ULBYH5nA	\N	\N	f	f	t	\N	[]	f
3	analyst_valorh2	Analyst Test	analyst@valorh2	bd01b48b-7639-4aa8-b0b4-e74cd273f581	$2b$12$SpOuxem/.gP5pzE5CK5tJegBv77xnF0jQJTU9A3PSIOU4m681rHG.	\N	\N	t	7Y_Rr2RWSaYmmwIFddjEUNcSoiaPeavF53g0ZXPXvEcFlM7YgaYMTzdPpFi3olxZSJYuQ9SlGNFwr5p47h0HCg	\N	\N	f	f	f	\N	[]	f
4	analyst2_valorh2	Analyst Test 2	analyst2@valorh2	796b27ba-e576-44c5-aa70-dfd06bba282b	$2b$12$yb/T0S/tO9gHuwxn1xzJV.Rn2OVe96GIl.ppfaF/mff./yRdtjd5y	\N	\N	t	GDAyphMulD_1GKnsWEr6jZ3Ru6kE3G6vbiVObAY0PBYoL7phamu_DAjEgv_86mfJXwdi5i10B3CQTFj3NQqJDA	\N	\N	f	f	f	\N	[]	f
1	administrator	administrator	administrator@localhost	882eb9fc-1cd2-46c9-af2b-50a8810978b3	$2b$12$howGuR97.YBeZWGaWDXRQ.B.pDOkwG2SO/7mTEXCwqdsszsBr7YGS	\N	\N	t	KduX02iRsnVFRzatKOr7P8JMK8YWeT28OJN7y2elIUX1ekAOJdw-9Z30GEF7_9zGXmSSd5FA1K45CAr2kwiWLQ	\N	\N	f	f	f	\N	[]	f
\.


--
-- Data for Name: user_activity; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_activity (id, user_id, case_id, activity_date, activity_desc, user_input, is_from_api, display_in_ui) FROM stdin;
1	1	\N	2025-08-28 06:51:23.121433	User 'administrator' successfully logged-in	f	f	f
2	1	\N	2025-08-28 11:56:17.386534	Added customer valorh2	f	f	t
3	1	\N	2025-08-28 11:56:52.858053	Created user apishuffle	f	f	t
4	1	\N	2025-08-28 11:59:30.001045	Groups membership of user 2 updated	f	f	t
5	1	\N	2025-08-28 12:01:21.120503	Created user analyst_valorh2	f	f	t
6	1	\N	2025-08-28 12:02:25.350975	Groups membership of user 3 updated	f	f	t
7	1	\N	2025-08-28 12:02:39.845716	Customers membership of user 3 updated	f	f	t
8	1	\N	2025-08-28 12:34:49.794113	Created user analyst2_valorh2	f	f	t
9	1	\N	2025-08-28 12:34:55.601815	Groups membership of user 4 updated	f	f	t
10	1	\N	2025-08-28 12:35:01.302327	Customers membership of user 4 updated	f	f	t
11	2	2	2025-08-28 12:49:34.226602	New case "#2 - three failed attempts to run sudo" created	f	t	t
12	2	3	2025-08-28 12:54:07.214548	New case "#3 - three failed attempts to run sudo" created	f	t	t
13	2	3	2025-08-28 12:54:12.486035	Case updated "#3 - three failed attempts to run sudo"	f	t	t
14	2	4	2025-08-28 13:03:55.688825	New case "#4 - three failed attempts to run sudo" created	f	t	t
15	2	4	2025-08-28 13:04:00.915253	Case updated "#4 - three failed attempts to run sudo"	f	t	t
16	2	4	2025-08-28 13:04:06.775088	Added ioc "1756383459.2586015"	f	t	t
17	2	4	2025-08-28 13:04:06.825152	Added ioc "/var/log/auth.log"	f	t	t
18	2	4	2025-08-28 13:04:06.875465	Added ioc "127.0.0.1"	f	t	t
19	2	4	2025-08-28 13:04:06.926692	Added ioc "sudo"	f	t	t
20	2	4	2025-08-28 13:04:06.985228	Added ioc "root"	f	t	t
21	2	\N	2025-08-28 13:04:12.131325	Case access level 1 for case(s) [4] set for user analyst_valorh2	f	t	t
22	2	\N	2025-08-28 13:04:12.175785	Case access level 4 for case(s) [4] set for user analyst2_valorh2	f	t	t
\.


--
-- Data for Name: user_case_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_case_access (id, user_id, case_id, access_level) FROM stdin;
1	2	2	4
2	2	3	4
3	2	4	4
4	3	4	1
5	4	4	4
\.


--
-- Data for Name: user_case_effective_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_case_effective_access (id, user_id, case_id, access_level) FROM stdin;
54	1	1	4
56	4	1	4
62	2	2	4
63	1	2	4
64	3	2	4
65	4	2	4
71	2	3	4
72	1	3	4
73	3	3	4
74	4	3	4
80	2	4	4
81	1	4	4
83	4	4	4
84	3	4	1
50	2	1	4
52	3	1	4
\.


--
-- Data for Name: user_client; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_client (id, user_id, client_id, access_level, allow_alerts) FROM stdin;
1	1	2	4	t
2	3	2	4	t
3	4	2	4	t
\.


--
-- Data for Name: user_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_group (id, user_id, group_id) FROM stdin;
1	1	1
2	2	1
3	3	2
4	4	2
\.


--
-- Data for Name: user_organisation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_organisation (id, user_id, org_id, is_primary_org) FROM stdin;
1	1	1	t
2	2	1	t
3	3	1	t
4	4	1	t
\.


--
-- Name: alert_resolution_status_resolution_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alert_resolution_status_resolution_status_id_seq', 6, true);


--
-- Name: alert_similarity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alert_similarity_id_seq', 1, false);


--
-- Name: alert_status_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alert_status_status_id_seq', 8, true);


--
-- Name: alerts_alert_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.alerts_alert_id_seq', 1, false);


--
-- Name: analysis_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.analysis_status_id_seq', 6, true);


--
-- Name: asset_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.asset_comments_id_seq', 1, false);


--
-- Name: assets_type_asset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assets_type_asset_id_seq', 21, true);


--
-- Name: case_assets_asset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_assets_asset_id_seq', 1, false);


--
-- Name: case_classification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_classification_id_seq', 36, true);


--
-- Name: case_events_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_events_assets_id_seq', 1, false);


--
-- Name: case_events_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_events_category_id_seq', 1, false);


--
-- Name: case_events_ioc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_events_ioc_id_seq', 1, false);


--
-- Name: case_graph_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_graph_assets_id_seq', 1, false);


--
-- Name: case_graph_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_graph_links_id_seq', 1, false);


--
-- Name: case_protagonist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_protagonist_id_seq', 1, false);


--
-- Name: case_received_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_received_file_id_seq', 1, false);


--
-- Name: case_state_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_state_state_id_seq', 9, true);


--
-- Name: case_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_tasks_id_seq', 1, false);


--
-- Name: case_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_template_id_seq', 1, false);


--
-- Name: case_template_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.case_template_report_id_seq', 1, false);


--
-- Name: cases_assets_ext_asset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cases_assets_ext_asset_id_seq', 1, false);


--
-- Name: cases_case_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cases_case_id_seq', 4, true);


--
-- Name: cases_events_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cases_events_event_id_seq', 1, false);


--
-- Name: client_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.client_client_id_seq', 2, true);


--
-- Name: comments_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comments_comment_id_seq', 1, false);


--
-- Name: contact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contact_id_seq', 1, false);


--
-- Name: custom_attribute_attribute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_attribute_attribute_id_seq', 8, true);


--
-- Name: data_store_file_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.data_store_file_file_id_seq', 1, false);


--
-- Name: data_store_path_path_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.data_store_path_path_id_seq', 4, true);


--
-- Name: event_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.event_category_id_seq', 15, true);


--
-- Name: event_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.event_comments_id_seq', 1, false);


--
-- Name: evidence_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.evidence_comments_id_seq', 1, false);


--
-- Name: evidence_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.evidence_type_id_seq', 58, true);


--
-- Name: global_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.global_tasks_id_seq', 1, false);


--
-- Name: group_case_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.group_case_access_id_seq', 53, true);


--
-- Name: groups_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.groups_group_id_seq', 3, true);


--
-- Name: ioc_asset_link_ioc_asset_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ioc_asset_link_ioc_asset_link_id_seq', 1, false);


--
-- Name: ioc_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ioc_comments_id_seq', 1, false);


--
-- Name: ioc_ioc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ioc_ioc_id_seq', 5, true);


--
-- Name: ioc_link_ioc_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ioc_link_ioc_link_id_seq', 5, true);


--
-- Name: ioc_type_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ioc_type_type_id_seq', 160, true);


--
-- Name: iris_hooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.iris_hooks_id_seq', 90, true);


--
-- Name: iris_module_hooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.iris_module_hooks_id_seq', 91, true);


--
-- Name: iris_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.iris_module_id_seq', 5, true);


--
-- Name: iris_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.iris_reports_id_seq', 1, false);


--
-- Name: languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.languages_id_seq', 42, true);


--
-- Name: note_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.note_comments_id_seq', 1, false);


--
-- Name: note_directory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.note_directory_id_seq', 1, false);


--
-- Name: note_revisions_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.note_revisions_revision_id_seq', 1, false);


--
-- Name: notes_group_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notes_group_group_id_seq', 1, false);


--
-- Name: notes_group_link_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notes_group_link_link_id_seq', 1, false);


--
-- Name: notes_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notes_note_id_seq', 1, false);


--
-- Name: object_state_object_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.object_state_object_id_seq', 24, true);


--
-- Name: organisation_case_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organisation_case_access_id_seq', 1, false);


--
-- Name: organisations_org_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.organisations_org_id_seq', 1, true);


--
-- Name: os_type_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.os_type_type_id_seq', 7, true);


--
-- Name: report_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.report_type_id_seq', 2, true);


--
-- Name: review_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.review_status_id_seq', 5, true);


--
-- Name: saved_filters_filter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.saved_filters_filter_id_seq', 1, false);


--
-- Name: server_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.server_settings_id_seq', 1, true);


--
-- Name: severities_severity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.severities_severity_id_seq', 6, true);


--
-- Name: similar_alerts_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.similar_alerts_cache_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tags_id_seq', 5, true);


--
-- Name: task_assignee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.task_assignee_id_seq', 1, false);


--
-- Name: task_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.task_comments_id_seq', 1, false);


--
-- Name: task_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.task_status_id_seq', 5, true);


--
-- Name: tlp_tlp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tlp_tlp_id_seq', 5, true);


--
-- Name: user_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_activity_id_seq', 22, true);


--
-- Name: user_case_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_case_access_id_seq', 5, true);


--
-- Name: user_case_effective_access_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_case_effective_access_id_seq', 84, true);


--
-- Name: user_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_client_id_seq', 3, true);


--
-- Name: user_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_group_id_seq', 4, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_id_seq', 4, true);


--
-- Name: user_organisation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_organisation_id_seq', 4, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alert_assets_association alert_assets_association_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_assets_association
    ADD CONSTRAINT alert_assets_association_pkey PRIMARY KEY (alert_id, asset_id);


--
-- Name: alert_case_association alert_case_association_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_case_association
    ADD CONSTRAINT alert_case_association_pkey PRIMARY KEY (alert_id, case_id);


--
-- Name: alert_iocs_association alert_iocs_association_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_iocs_association
    ADD CONSTRAINT alert_iocs_association_pkey PRIMARY KEY (alert_id, ioc_id);


--
-- Name: alert_resolution_status alert_resolution_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_resolution_status
    ADD CONSTRAINT alert_resolution_status_pkey PRIMARY KEY (resolution_status_id);


--
-- Name: alert_resolution_status alert_resolution_status_resolution_status_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_resolution_status
    ADD CONSTRAINT alert_resolution_status_resolution_status_name_key UNIQUE (resolution_status_name);


--
-- Name: alert_similarity alert_similarity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_similarity
    ADD CONSTRAINT alert_similarity_pkey PRIMARY KEY (id);


--
-- Name: alert_status alert_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_status
    ADD CONSTRAINT alert_status_pkey PRIMARY KEY (status_id);


--
-- Name: alert_status alert_status_status_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_status
    ADD CONSTRAINT alert_status_status_name_key UNIQUE (status_name);


--
-- Name: alerts alerts_alert_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_uuid_key UNIQUE (alert_uuid);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (alert_id);


--
-- Name: analysis_status analysis_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analysis_status
    ADD CONSTRAINT analysis_status_pkey PRIMARY KEY (id);


--
-- Name: asset_comments asset_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_comments
    ADD CONSTRAINT asset_comments_pkey PRIMARY KEY (id);


--
-- Name: assets_type assets_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets_type
    ADD CONSTRAINT assets_type_pkey PRIMARY KEY (asset_id);


--
-- Name: case_assets case_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assets
    ADD CONSTRAINT case_assets_pkey PRIMARY KEY (asset_id);


--
-- Name: case_classification case_classification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_classification
    ADD CONSTRAINT case_classification_pkey PRIMARY KEY (id);


--
-- Name: case_events_assets case_events_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_assets
    ADD CONSTRAINT case_events_assets_pkey PRIMARY KEY (id);


--
-- Name: case_events_category case_events_category_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_category
    ADD CONSTRAINT case_events_category_event_id_key UNIQUE (event_id);


--
-- Name: case_events_category case_events_category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_category
    ADD CONSTRAINT case_events_category_pkey PRIMARY KEY (id);


--
-- Name: case_events_ioc case_events_ioc_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_ioc
    ADD CONSTRAINT case_events_ioc_pkey PRIMARY KEY (id);


--
-- Name: case_graph_assets case_graph_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_graph_assets
    ADD CONSTRAINT case_graph_assets_pkey PRIMARY KEY (id);


--
-- Name: case_graph_links case_graph_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_graph_links
    ADD CONSTRAINT case_graph_links_pkey PRIMARY KEY (id);


--
-- Name: case_kanban case_kanban_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_kanban
    ADD CONSTRAINT case_kanban_pkey PRIMARY KEY (case_id);


--
-- Name: case_protagonist case_protagonist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_protagonist
    ADD CONSTRAINT case_protagonist_pkey PRIMARY KEY (id);


--
-- Name: case_received_file case_received_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_received_file
    ADD CONSTRAINT case_received_file_pkey PRIMARY KEY (id);


--
-- Name: case_state case_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_state
    ADD CONSTRAINT case_state_pkey PRIMARY KEY (state_id);


--
-- Name: case_tags case_tags_case_id_tag_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_tags
    ADD CONSTRAINT case_tags_case_id_tag_id_key PRIMARY KEY (case_id, tag_id);


--
-- Name: case_tasks case_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_pkey PRIMARY KEY (id);


--
-- Name: case_template case_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_template
    ADD CONSTRAINT case_template_pkey PRIMARY KEY (id);


--
-- Name: case_template_report case_template_report_internal_reference_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_template_report
    ADD CONSTRAINT case_template_report_internal_reference_key UNIQUE (internal_reference);


--
-- Name: case_template_report case_template_report_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_template_report
    ADD CONSTRAINT case_template_report_pkey PRIMARY KEY (id);


--
-- Name: cases_assets_ext cases_assets_ext_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases_assets_ext
    ADD CONSTRAINT cases_assets_ext_pkey PRIMARY KEY (asset_id);


--
-- Name: cases_events cases_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases_events
    ADD CONSTRAINT cases_events_pkey PRIMARY KEY (event_id);


--
-- Name: cases cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_pkey PRIMARY KEY (case_id);


--
-- Name: client client_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_name_key UNIQUE (name);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (client_id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (comment_id);


--
-- Name: contact contact_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (id);


--
-- Name: custom_attribute custom_attribute_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_attribute
    ADD CONSTRAINT custom_attribute_pkey PRIMARY KEY (attribute_id);


--
-- Name: data_store_file data_store_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_store_file
    ADD CONSTRAINT data_store_file_pkey PRIMARY KEY (file_id);


--
-- Name: data_store_path data_store_path_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_store_path
    ADD CONSTRAINT data_store_path_pkey PRIMARY KEY (path_id);


--
-- Name: event_category event_category_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_category
    ADD CONSTRAINT event_category_pkey PRIMARY KEY (id);


--
-- Name: event_comments event_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_comments
    ADD CONSTRAINT event_comments_pkey PRIMARY KEY (id);


--
-- Name: evidence_comments evidence_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_comments
    ADD CONSTRAINT evidence_comments_pkey PRIMARY KEY (id);


--
-- Name: evidence_type evidence_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_type
    ADD CONSTRAINT evidence_type_pkey PRIMARY KEY (id);


--
-- Name: global_tasks global_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_pkey PRIMARY KEY (id);


--
-- Name: group_case_access group_case_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_case_access
    ADD CONSTRAINT group_case_access_pkey PRIMARY KEY (id);


--
-- Name: groups groups_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_group_name_key UNIQUE (group_name);


--
-- Name: groups groups_group_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_group_uuid_key UNIQUE (group_uuid);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (group_id);


--
-- Name: ioc_asset_link ioc_asset_link_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_asset_link
    ADD CONSTRAINT ioc_asset_link_pkey PRIMARY KEY (ioc_asset_link_id);


--
-- Name: ioc_comments ioc_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_comments
    ADD CONSTRAINT ioc_comments_pkey PRIMARY KEY (id);


--
-- Name: ioc_link ioc_link_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_link
    ADD CONSTRAINT ioc_link_pkey PRIMARY KEY (ioc_link_id);


--
-- Name: ioc ioc_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc
    ADD CONSTRAINT ioc_pkey PRIMARY KEY (ioc_id);


--
-- Name: ioc_type ioc_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_type
    ADD CONSTRAINT ioc_type_pkey PRIMARY KEY (type_id);


--
-- Name: iris_hooks iris_hooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_hooks
    ADD CONSTRAINT iris_hooks_pkey PRIMARY KEY (id);


--
-- Name: iris_module_hooks iris_module_hooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_module_hooks
    ADD CONSTRAINT iris_module_hooks_pkey PRIMARY KEY (id);


--
-- Name: iris_module iris_module_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_module
    ADD CONSTRAINT iris_module_pkey PRIMARY KEY (id);


--
-- Name: iris_reports iris_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_reports
    ADD CONSTRAINT iris_reports_pkey PRIMARY KEY (report_id);


--
-- Name: languages languages_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_code_key UNIQUE (code);


--
-- Name: languages languages_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_name_key UNIQUE (name);


--
-- Name: languages languages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- Name: note_comments note_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_comments
    ADD CONSTRAINT note_comments_pkey PRIMARY KEY (id);


--
-- Name: note_directory note_directory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_directory
    ADD CONSTRAINT note_directory_pkey PRIMARY KEY (id);


--
-- Name: note_revisions note_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_revisions
    ADD CONSTRAINT note_revisions_pkey PRIMARY KEY (revision_id);


--
-- Name: notes_group_link notes_group_link_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes_group_link
    ADD CONSTRAINT notes_group_link_pkey PRIMARY KEY (link_id);


--
-- Name: notes_group notes_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes_group
    ADD CONSTRAINT notes_group_pkey PRIMARY KEY (group_id);


--
-- Name: notes notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (note_id);


--
-- Name: object_state object_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.object_state
    ADD CONSTRAINT object_state_pkey PRIMARY KEY (object_id);


--
-- Name: organisation_case_access organisation_case_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisation_case_access
    ADD CONSTRAINT organisation_case_access_pkey PRIMARY KEY (id);


--
-- Name: organisations organisations_org_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisations
    ADD CONSTRAINT organisations_org_name_key UNIQUE (org_name);


--
-- Name: organisations organisations_org_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisations
    ADD CONSTRAINT organisations_org_uuid_key UNIQUE (org_uuid);


--
-- Name: organisations organisations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisations
    ADD CONSTRAINT organisations_pkey PRIMARY KEY (org_id);


--
-- Name: os_type os_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.os_type
    ADD CONSTRAINT os_type_pkey PRIMARY KEY (type_id);


--
-- Name: report_type report_type_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_type
    ADD CONSTRAINT report_type_name_key UNIQUE (name);


--
-- Name: report_type report_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_type
    ADD CONSTRAINT report_type_pkey PRIMARY KEY (id);


--
-- Name: review_status review_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.review_status
    ADD CONSTRAINT review_status_pkey PRIMARY KEY (id);


--
-- Name: saved_filters saved_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_filters
    ADD CONSTRAINT saved_filters_pkey PRIMARY KEY (filter_id);


--
-- Name: server_settings server_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.server_settings
    ADD CONSTRAINT server_settings_pkey PRIMARY KEY (id);


--
-- Name: severities severities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.severities
    ADD CONSTRAINT severities_pkey PRIMARY KEY (severity_id);


--
-- Name: severities severities_severity_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.severities
    ADD CONSTRAINT severities_severity_name_key UNIQUE (severity_name);


--
-- Name: similar_alerts_cache similar_alerts_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.similar_alerts_cache
    ADD CONSTRAINT similar_alerts_cache_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_tag_title_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_tag_title_key UNIQUE (tag_title);


--
-- Name: tags tags_tag_title_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_tag_title_key1 UNIQUE (tag_title);


--
-- Name: task_assignee task_assignee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_assignee
    ADD CONSTRAINT task_assignee_pkey PRIMARY KEY (id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: task_status task_status_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_status
    ADD CONSTRAINT task_status_pkey PRIMARY KEY (id);


--
-- Name: tlp tlp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tlp
    ADD CONSTRAINT tlp_pkey PRIMARY KEY (tlp_id);


--
-- Name: user_activity user_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activity
    ADD CONSTRAINT user_activity_pkey PRIMARY KEY (id);


--
-- Name: user user_api_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_api_key_key UNIQUE (api_key);


--
-- Name: user_case_access user_case_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_case_access
    ADD CONSTRAINT user_case_access_pkey PRIMARY KEY (id);


--
-- Name: user_case_effective_access user_case_effective_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_case_effective_access
    ADD CONSTRAINT user_case_effective_access_pkey PRIMARY KEY (id);


--
-- Name: user_client user_client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_client
    ADD CONSTRAINT user_client_pkey PRIMARY KEY (id);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_external_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_external_id_key UNIQUE (external_id);


--
-- Name: user_group user_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_pkey PRIMARY KEY (id);


--
-- Name: user_organisation user_organisation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_organisation
    ADD CONSTRAINT user_organisation_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user user_user_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_user_key UNIQUE ("user");


--
-- Name: user user_uuid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_uuid_key UNIQUE (uuid);


--
-- Name: idx_alert_source_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_source_ref ON public.alerts USING btree (alert_source_ref);


--
-- Name: idx_alerts_creation_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_creation_time ON public.alerts USING btree (alert_creation_time);


--
-- Name: idx_alerts_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_customer_id ON public.alerts USING btree (alert_customer_id);


--
-- Name: idx_alerts_source_event_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_source_event_time ON public.alerts USING btree (alert_source_event_time);


--
-- Name: idx_alerts_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_title ON public.alerts USING btree (alert_title);


--
-- Name: idx_case_assets_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assets_case_id ON public.case_assets USING btree (case_id);


--
-- Name: idx_case_assets_date_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assets_date_added ON public.case_assets USING btree (date_added);


--
-- Name: idx_case_assets_date_update; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assets_date_update ON public.case_assets USING btree (date_update);


--
-- Name: idx_case_assets_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_assets_name ON public.case_assets USING btree (asset_name);


--
-- Name: idx_ioc_tags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ioc_tags ON public.ioc USING btree (ioc_tags);


--
-- Name: idx_ioc_value_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ioc_value_hash ON public.ioc USING btree (md5(ioc_value));


--
-- Name: ix_alert_case_association_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_alert_case_association_case_id ON public.alert_case_association USING btree (case_id);


--
-- Name: ix_case_tags_tag_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_case_tags_tag_id ON public.case_tags USING btree (tag_id);


--
-- Name: alert_assets_association alert_assets_association_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_assets_association
    ADD CONSTRAINT alert_assets_association_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: alert_assets_association alert_assets_association_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_assets_association
    ADD CONSTRAINT alert_assets_association_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.case_assets(asset_id);


--
-- Name: alert_case_association alert_case_association_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_case_association
    ADD CONSTRAINT alert_case_association_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: alert_case_association alert_case_association_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_case_association
    ADD CONSTRAINT alert_case_association_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: alert_iocs_association alert_iocs_association_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_iocs_association
    ADD CONSTRAINT alert_iocs_association_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: alert_iocs_association alert_iocs_association_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_iocs_association
    ADD CONSTRAINT alert_iocs_association_ioc_id_fkey FOREIGN KEY (ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: alert_similarity alert_similarity_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_similarity
    ADD CONSTRAINT alert_similarity_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: alert_similarity alert_similarity_matching_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_similarity
    ADD CONSTRAINT alert_similarity_matching_asset_id_fkey FOREIGN KEY (matching_asset_id) REFERENCES public.case_assets(asset_id);


--
-- Name: alert_similarity alert_similarity_matching_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_similarity
    ADD CONSTRAINT alert_similarity_matching_ioc_id_fkey FOREIGN KEY (matching_ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: alert_similarity alert_similarity_similar_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_similarity
    ADD CONSTRAINT alert_similarity_similar_alert_id_fkey FOREIGN KEY (similar_alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: alerts alerts_alert_classification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_classification_id_fkey FOREIGN KEY (alert_classification_id) REFERENCES public.case_classification(id);


--
-- Name: alerts alerts_alert_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_customer_id_fkey FOREIGN KEY (alert_customer_id) REFERENCES public.client(client_id);


--
-- Name: alerts alerts_alert_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_owner_id_fkey FOREIGN KEY (alert_owner_id) REFERENCES public."user"(id);


--
-- Name: alerts alerts_alert_resolution_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_resolution_status_id_fkey FOREIGN KEY (alert_resolution_status_id) REFERENCES public.alert_resolution_status(resolution_status_id);


--
-- Name: alerts alerts_alert_severity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_severity_id_fkey FOREIGN KEY (alert_severity_id) REFERENCES public.severities(severity_id);


--
-- Name: alerts alerts_alert_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_status_id_fkey FOREIGN KEY (alert_status_id) REFERENCES public.alert_status(status_id);


--
-- Name: asset_comments asset_comments_comment_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_comments
    ADD CONSTRAINT asset_comments_comment_asset_id_fkey FOREIGN KEY (comment_asset_id) REFERENCES public.case_assets(asset_id);


--
-- Name: asset_comments asset_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_comments
    ADD CONSTRAINT asset_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: case_assets case_assets_analysis_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assets
    ADD CONSTRAINT case_assets_analysis_status_id_fkey FOREIGN KEY (analysis_status_id) REFERENCES public.analysis_status(id);


--
-- Name: case_assets case_assets_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assets
    ADD CONSTRAINT case_assets_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES public.assets_type(asset_id);


--
-- Name: case_assets case_assets_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assets
    ADD CONSTRAINT case_assets_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_assets case_assets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_assets
    ADD CONSTRAINT case_assets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: case_classification case_classification_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_classification
    ADD CONSTRAINT case_classification_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public."user"(id);


--
-- Name: case_events_assets case_events_assets_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_assets
    ADD CONSTRAINT case_events_assets_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.case_assets(asset_id);


--
-- Name: case_events_assets case_events_assets_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_assets
    ADD CONSTRAINT case_events_assets_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_events_assets case_events_assets_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_assets
    ADD CONSTRAINT case_events_assets_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.cases_events(event_id);


--
-- Name: case_events_category case_events_category_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_category
    ADD CONSTRAINT case_events_category_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.event_category(id);


--
-- Name: case_events_category case_events_category_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_category
    ADD CONSTRAINT case_events_category_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.cases_events(event_id);


--
-- Name: case_events_ioc case_events_ioc_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_ioc
    ADD CONSTRAINT case_events_ioc_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_events_ioc case_events_ioc_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_ioc
    ADD CONSTRAINT case_events_ioc_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.cases_events(event_id);


--
-- Name: case_events_ioc case_events_ioc_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events_ioc
    ADD CONSTRAINT case_events_ioc_ioc_id_fkey FOREIGN KEY (ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: case_graph_assets case_graph_assets_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_graph_assets
    ADD CONSTRAINT case_graph_assets_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES public.assets_type(asset_id);


--
-- Name: case_graph_assets case_graph_assets_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_graph_assets
    ADD CONSTRAINT case_graph_assets_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_graph_links case_graph_links_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_graph_links
    ADD CONSTRAINT case_graph_links_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_graph_links case_graph_links_dest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_graph_links
    ADD CONSTRAINT case_graph_links_dest_id_fkey FOREIGN KEY (dest_id) REFERENCES public.case_graph_assets(id);


--
-- Name: case_graph_links case_graph_links_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_graph_links
    ADD CONSTRAINT case_graph_links_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.case_graph_assets(id);


--
-- Name: case_kanban case_kanban_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_kanban
    ADD CONSTRAINT case_kanban_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_protagonist case_protagonist_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_protagonist
    ADD CONSTRAINT case_protagonist_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_protagonist case_protagonist_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_protagonist
    ADD CONSTRAINT case_protagonist_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: case_received_file case_received_file_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_received_file
    ADD CONSTRAINT case_received_file_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_received_file case_received_file_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_received_file
    ADD CONSTRAINT case_received_file_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.evidence_type(id);


--
-- Name: case_received_file case_received_file_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_received_file
    ADD CONSTRAINT case_received_file_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: case_tags case_tags_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_tags
    ADD CONSTRAINT case_tags_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_tags case_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_tags
    ADD CONSTRAINT case_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id);


--
-- Name: case_tasks case_tasks_task_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_task_case_id_fkey FOREIGN KEY (task_case_id) REFERENCES public.cases(case_id);


--
-- Name: case_tasks case_tasks_task_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_task_status_id_fkey FOREIGN KEY (task_status_id) REFERENCES public.task_status(id);


--
-- Name: case_tasks case_tasks_task_userid_close_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_task_userid_close_fkey FOREIGN KEY (task_userid_close) REFERENCES public."user"(id);


--
-- Name: case_tasks case_tasks_task_userid_open_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_task_userid_open_fkey FOREIGN KEY (task_userid_open) REFERENCES public."user"(id);


--
-- Name: case_tasks case_tasks_task_userid_update_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_tasks
    ADD CONSTRAINT case_tasks_task_userid_update_fkey FOREIGN KEY (task_userid_update) REFERENCES public."user"(id);


--
-- Name: case_template case_template_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_template
    ADD CONSTRAINT case_template_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public."user"(id);


--
-- Name: case_template_report case_template_report_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_template_report
    ADD CONSTRAINT case_template_report_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public."user"(id);


--
-- Name: case_template_report case_template_report_language_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_template_report
    ADD CONSTRAINT case_template_report_language_id_fkey FOREIGN KEY (language_id) REFERENCES public.languages(id);


--
-- Name: case_template_report case_template_report_report_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_template_report
    ADD CONSTRAINT case_template_report_report_type_id_fkey FOREIGN KEY (report_type_id) REFERENCES public.report_type(id);


--
-- Name: cases_assets_ext cases_assets_ext_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases_assets_ext
    ADD CONSTRAINT cases_assets_ext_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: cases_assets_ext cases_assets_ext_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases_assets_ext
    ADD CONSTRAINT cases_assets_ext_type_id_fkey FOREIGN KEY (type_id) REFERENCES public.assets_type(asset_id);


--
-- Name: cases cases_classification_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_classification_id_fkey FOREIGN KEY (classification_id) REFERENCES public.case_classification(id);


--
-- Name: cases cases_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: cases_events cases_events_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases_events
    ADD CONSTRAINT cases_events_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: cases_events cases_events_parent_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases_events
    ADD CONSTRAINT cases_events_parent_event_id_fkey FOREIGN KEY (parent_event_id) REFERENCES public.cases_events(event_id);


--
-- Name: cases_events cases_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases_events
    ADD CONSTRAINT cases_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: cases cases_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public."user"(id);


--
-- Name: cases cases_review_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_review_status_id_fkey FOREIGN KEY (review_status_id) REFERENCES public.review_status(id);


--
-- Name: cases cases_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public."user"(id);


--
-- Name: cases cases_severity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_severity_id_fkey FOREIGN KEY (severity_id) REFERENCES public.severities(severity_id);


--
-- Name: cases cases_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_state_id_fkey FOREIGN KEY (state_id) REFERENCES public.case_state(state_id);


--
-- Name: cases cases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: client client_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_created_by_fkey FOREIGN KEY (created_by) REFERENCES public."user"(id);


--
-- Name: comments comments_comment_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_comment_alert_id_fkey FOREIGN KEY (comment_alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: comments comments_comment_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_comment_case_id_fkey FOREIGN KEY (comment_case_id) REFERENCES public.cases(case_id);


--
-- Name: comments comments_comment_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_comment_user_id_fkey FOREIGN KEY (comment_user_id) REFERENCES public."user"(id);


--
-- Name: contact contact_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: data_store_file data_store_file_added_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_store_file
    ADD CONSTRAINT data_store_file_added_by_user_id_fkey FOREIGN KEY (added_by_user_id) REFERENCES public."user"(id);


--
-- Name: data_store_file data_store_file_file_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_store_file
    ADD CONSTRAINT data_store_file_file_case_id_fkey FOREIGN KEY (file_case_id) REFERENCES public.cases(case_id);


--
-- Name: data_store_file data_store_file_file_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_store_file
    ADD CONSTRAINT data_store_file_file_parent_id_fkey FOREIGN KEY (file_parent_id) REFERENCES public.data_store_path(path_id);


--
-- Name: data_store_path data_store_path_path_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_store_path
    ADD CONSTRAINT data_store_path_path_case_id_fkey FOREIGN KEY (path_case_id) REFERENCES public.cases(case_id);


--
-- Name: event_comments event_comments_comment_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_comments
    ADD CONSTRAINT event_comments_comment_event_id_fkey FOREIGN KEY (comment_event_id) REFERENCES public.cases_events(event_id);


--
-- Name: event_comments event_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_comments
    ADD CONSTRAINT event_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: evidence_comments evidence_comments_comment_evidence_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_comments
    ADD CONSTRAINT evidence_comments_comment_evidence_id_fkey FOREIGN KEY (comment_evidence_id) REFERENCES public.case_received_file(id);


--
-- Name: evidence_comments evidence_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_comments
    ADD CONSTRAINT evidence_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: evidence_type evidence_type_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evidence_type
    ADD CONSTRAINT evidence_type_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public."user"(id);


--
-- Name: global_tasks global_tasks_task_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_task_assignee_id_fkey FOREIGN KEY (task_assignee_id) REFERENCES public."user"(id);


--
-- Name: global_tasks global_tasks_task_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_task_status_id_fkey FOREIGN KEY (task_status_id) REFERENCES public.task_status(id);


--
-- Name: global_tasks global_tasks_task_userid_close_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_task_userid_close_fkey FOREIGN KEY (task_userid_close) REFERENCES public."user"(id);


--
-- Name: global_tasks global_tasks_task_userid_open_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_task_userid_open_fkey FOREIGN KEY (task_userid_open) REFERENCES public."user"(id);


--
-- Name: global_tasks global_tasks_task_userid_update_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.global_tasks
    ADD CONSTRAINT global_tasks_task_userid_update_fkey FOREIGN KEY (task_userid_update) REFERENCES public."user"(id);


--
-- Name: group_case_access group_case_access_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_case_access
    ADD CONSTRAINT group_case_access_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: group_case_access group_case_access_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_case_access
    ADD CONSTRAINT group_case_access_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(group_id);


--
-- Name: ioc_asset_link ioc_asset_link_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_asset_link
    ADD CONSTRAINT ioc_asset_link_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.case_assets(asset_id);


--
-- Name: ioc_asset_link ioc_asset_link_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_asset_link
    ADD CONSTRAINT ioc_asset_link_ioc_id_fkey FOREIGN KEY (ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: ioc_comments ioc_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_comments
    ADD CONSTRAINT ioc_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: ioc_comments ioc_comments_comment_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_comments
    ADD CONSTRAINT ioc_comments_comment_ioc_id_fkey FOREIGN KEY (comment_ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: ioc ioc_ioc_tlp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc
    ADD CONSTRAINT ioc_ioc_tlp_id_fkey FOREIGN KEY (ioc_tlp_id) REFERENCES public.tlp(tlp_id);


--
-- Name: ioc ioc_ioc_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc
    ADD CONSTRAINT ioc_ioc_type_id_fkey FOREIGN KEY (ioc_type_id) REFERENCES public.ioc_type(type_id);


--
-- Name: ioc_link ioc_link_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_link
    ADD CONSTRAINT ioc_link_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: ioc_link ioc_link_ioc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc_link
    ADD CONSTRAINT ioc_link_ioc_id_fkey FOREIGN KEY (ioc_id) REFERENCES public.ioc(ioc_id);


--
-- Name: ioc ioc_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ioc
    ADD CONSTRAINT ioc_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: iris_module iris_module_added_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_module
    ADD CONSTRAINT iris_module_added_by_id_fkey FOREIGN KEY (added_by_id) REFERENCES public."user"(id);


--
-- Name: iris_module_hooks iris_module_hooks_hook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_module_hooks
    ADD CONSTRAINT iris_module_hooks_hook_id_fkey FOREIGN KEY (hook_id) REFERENCES public.iris_hooks(id);


--
-- Name: iris_module_hooks iris_module_hooks_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_module_hooks
    ADD CONSTRAINT iris_module_hooks_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.iris_module(id);


--
-- Name: iris_reports iris_reports_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_reports
    ADD CONSTRAINT iris_reports_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: iris_reports iris_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.iris_reports
    ADD CONSTRAINT iris_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: note_comments note_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_comments
    ADD CONSTRAINT note_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: note_comments note_comments_comment_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_comments
    ADD CONSTRAINT note_comments_comment_note_id_fkey FOREIGN KEY (comment_note_id) REFERENCES public.notes(note_id);


--
-- Name: note_directory note_directory_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_directory
    ADD CONSTRAINT note_directory_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: note_directory note_directory_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_directory
    ADD CONSTRAINT note_directory_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.note_directory(id);


--
-- Name: note_revisions note_revisions_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_revisions
    ADD CONSTRAINT note_revisions_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.notes(note_id);


--
-- Name: note_revisions note_revisions_note_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_revisions
    ADD CONSTRAINT note_revisions_note_user_fkey FOREIGN KEY (note_user) REFERENCES public."user"(id);


--
-- Name: notes notes_directory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_directory_id_fkey FOREIGN KEY (directory_id) REFERENCES public.note_directory(id);


--
-- Name: notes_group notes_group_group_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes_group
    ADD CONSTRAINT notes_group_group_case_id_fkey FOREIGN KEY (group_case_id) REFERENCES public.cases(case_id);


--
-- Name: notes_group notes_group_group_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes_group
    ADD CONSTRAINT notes_group_group_user_fkey FOREIGN KEY (group_user) REFERENCES public."user"(id);


--
-- Name: notes_group_link notes_group_link_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes_group_link
    ADD CONSTRAINT notes_group_link_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: notes_group_link notes_group_link_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes_group_link
    ADD CONSTRAINT notes_group_link_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.notes_group(group_id);


--
-- Name: notes_group_link notes_group_link_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes_group_link
    ADD CONSTRAINT notes_group_link_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.notes(note_id);


--
-- Name: notes notes_note_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_note_case_id_fkey FOREIGN KEY (note_case_id) REFERENCES public.cases(case_id);


--
-- Name: notes notes_note_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notes
    ADD CONSTRAINT notes_note_user_fkey FOREIGN KEY (note_user) REFERENCES public."user"(id);


--
-- Name: object_state object_state_object_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.object_state
    ADD CONSTRAINT object_state_object_case_id_fkey FOREIGN KEY (object_case_id) REFERENCES public.cases(case_id);


--
-- Name: object_state object_state_object_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.object_state
    ADD CONSTRAINT object_state_object_updated_by_id_fkey FOREIGN KEY (object_updated_by_id) REFERENCES public."user"(id);


--
-- Name: organisation_case_access organisation_case_access_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisation_case_access
    ADD CONSTRAINT organisation_case_access_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: organisation_case_access organisation_case_access_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.organisation_case_access
    ADD CONSTRAINT organisation_case_access_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organisations(org_id);


--
-- Name: saved_filters saved_filters_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_filters
    ADD CONSTRAINT saved_filters_created_by_fkey FOREIGN KEY (created_by) REFERENCES public."user"(id);


--
-- Name: similar_alerts_cache similar_alerts_cache_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.similar_alerts_cache
    ADD CONSTRAINT similar_alerts_cache_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(alert_id);


--
-- Name: similar_alerts_cache similar_alerts_cache_asset_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.similar_alerts_cache
    ADD CONSTRAINT similar_alerts_cache_asset_type_id_fkey FOREIGN KEY (asset_type_id) REFERENCES public.assets_type(asset_id);


--
-- Name: similar_alerts_cache similar_alerts_cache_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.similar_alerts_cache
    ADD CONSTRAINT similar_alerts_cache_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.client(client_id);


--
-- Name: similar_alerts_cache similar_alerts_cache_ioc_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.similar_alerts_cache
    ADD CONSTRAINT similar_alerts_cache_ioc_type_id_fkey FOREIGN KEY (ioc_type_id) REFERENCES public.ioc_type(type_id);


--
-- Name: task_assignee task_assignee_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_assignee
    ADD CONSTRAINT task_assignee_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.case_tasks(id);


--
-- Name: task_assignee task_assignee_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_assignee
    ADD CONSTRAINT task_assignee_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: task_comments task_comments_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(comment_id);


--
-- Name: task_comments task_comments_comment_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_comment_task_id_fkey FOREIGN KEY (comment_task_id) REFERENCES public.case_tasks(id);


--
-- Name: user_activity user_activity_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activity
    ADD CONSTRAINT user_activity_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: user_activity user_activity_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_activity
    ADD CONSTRAINT user_activity_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_case_access user_case_access_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_case_access
    ADD CONSTRAINT user_case_access_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: user_case_access user_case_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_case_access
    ADD CONSTRAINT user_case_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_case_effective_access user_case_effective_access_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_case_effective_access
    ADD CONSTRAINT user_case_effective_access_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: user_case_effective_access user_case_effective_access_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_case_effective_access
    ADD CONSTRAINT user_case_effective_access_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_client user_client_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_client
    ADD CONSTRAINT user_client_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(client_id);


--
-- Name: user_client user_client_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_client
    ADD CONSTRAINT user_client_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_group user_group_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(group_id);


--
-- Name: user_group user_group_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: user_organisation user_organisation_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_organisation
    ADD CONSTRAINT user_organisation_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organisations(org_id);


--
-- Name: user_organisation user_organisation_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_organisation
    ADD CONSTRAINT user_organisation_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

